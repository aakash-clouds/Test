<?php
// Init vars
$LOCAL_ROOT         = "/var/www/html2";
$LOCAL_REPO_NAME    = "searchstax-corp-site";
$LOCAL_REPO         = "{$LOCAL_ROOT}/{$LOCAL_REPO_NAME}";
$REMOTE_REPO        = "/searchstax/searchstax-corp-site";
$WEB_ROOT           = "/var/www/html";
// Delete local repo if it exists
if (file_exists($LOCAL_REPO)) {
    shell_exec("rm -rf {$LOCAL_REPO}");
}
// Clone fresh repo from github using desired local repo name and checkout the desired branch
echo shell_exec("cd {$LOCAL_ROOT} && git clone -b master git@github-{$LOCAL_REPO_NAME}:{$REMOTE_REPO}.git {$LOCAL_REPO_NAME} && rsync -avh {$LOCAL_REPO}/web/ {$WEB_ROOT} && cp /var/www/html2/searchstax-corp-site/web/htaccess_prod/.htaccess /var/www/html/ && cd /var/www/html2/docs/searchstax && mkdocs build && rsync -avh --delete {$LOCAL_REPO}/searchstax/site/ {$WEB_ROOT}");
die("done " . mktime());
