#!/bin/bash

#script variables
BAK_DATE=`date +%Y-%m-%d`
DB_BAK_FILE=/var/wp-backups/mysqldb-bak
WP_BAK_FILE=/var/wp-backups/wp-filesys-bak
BAK_DB=$DB_BAK_FILE-$BAK_DATE
BAK_WP=$WP_BAK_FILE-$BAK_DATE
BAK_FOLDER=/var/wp-backup

#s3 bucket name that contains backup
S3_BUCKET=measuredsearch-backups-website/corp-site-mysqldump/

#Database backup
cd /var/www/blogtest
./wp-cli.phar db export $BAK_DB.sql

#WP file system backup
cd /var/www
sudo tar -vczf $BAK_WP.gz .

#Putting dump file to s3 bucket
echo 'Copying database backup to S3 ...'
/usr/bin/s3cmd put FILE $BAK_DB.sql s3://$S3_BUCKET
/usr/bin/s3cmd put FILE $BAK_WP.gz s3://$S3_BUCKET

#number of days to keep archives
KEEP_DAYS=3

#DELETE FILES OLDER THAN 3 days from SERVER
echo 'Deleting backup older than $KEEP_DAYS days'
find $BAK_FOLDER -type f -mtime +$KEEP_DAYS -delete

#Cronjob running daily:
0 8 * * * sh /home/ubuntu/wp-corpsite-bak.sh > /home/ubuntu/wp-corpsite.out
