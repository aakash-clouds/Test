<?php

// Init vars
$LOCAL_ROOT         = "/var/www/html2";
$LOCAL_REPO_NAME    = "corp-site";
$LOCAL_REPO         = "{$LOCAL_ROOT}/{$LOCAL_REPO_NAME}";
$REMOTE_REPO        = "/measuredsearch/searchstax-Corp-Site.git";
$WEB_ROOT           = "/var/www/html";

// Delete local repo if it exists
if (file_exists($LOCAL_REPO)) {
    shell_exec("rm -rf {$LOCAL_REPO}");
}

// Clone fresh repo from github using desired local repo name and checkout the desired branch
echo shell_exec("cd {$LOCAL_ROOT} && git clone -b master git@github.com:{$REMOTE_REPO} {$LOCAL_REPO_NAME} && rsync -avh --delete {$LOCAL_REPO}/web/ {$WEB_ROOT}");
echo shell_exec("cp /var/www/html2/corp-site/web/htaccess_qa/.htaccess /var/www/html/.htaccess");

die("done " . mktime());
