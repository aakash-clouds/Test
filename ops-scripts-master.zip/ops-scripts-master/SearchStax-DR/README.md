# Ansible DR scripts to spin-up new configs after AZ failure

Documentation moved to: [https://searchstax.atlassian.net/wiki/spaces/PO/pages/244776963/Disaster+Recovery](https://searchstax.atlassian.net/wiki/spaces/PO/pages/244776963/Disaster+Recovery)
