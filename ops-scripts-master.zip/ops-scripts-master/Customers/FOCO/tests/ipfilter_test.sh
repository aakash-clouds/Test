#!/bin/bash

# Test ipfiltering per domain
# Assumes at least one document in the collection
if [ -z ${1+x} ]; then
  echo "No argument was passed to script, defaulting EXPECT_403 to false"
  EXPECT_403=false
else 
  EXPECT_403=$1
  echo "EXPECT_403=$EXPECT_403"
fi

SCHEME=https
HOST=foco-search.global.ssl.fastly.net
COLLECTION=products

echo "Testing /select..."
cmd="curl $SCHEME://$HOST/solr/$COLLECTION/select?indent=on&q=sku:UNDNHCPRPLGCHNXXL&limit=1&wt=json"
echo "cmd=$cmd"
response=`$cmd`
echo "response is $response"
echo $response|grep "response\":{\"numFound\":1"
if [ $? -eq 1 ]; then
  echo "Test FAILED"
  exit 1
fi
echo "/select is OK"


echo
echo "Testing /update..."
# Insert timestamp into doc
isodate=`date -u +"%Y-%m-%dT%H:%M:%SZ"`
sed "s/\(.*last_modified\":\"\)\(.*\)\(\",\)/\1${isodate}\3/" docs1.json > docs1.json.tmp && mv docs1.json.tmp docs1.json

cmd="curl -X POST -H 'Content-type:application/json' -d @docs1.json $SCHEME://$HOST/solr/$COLLECTION/update?commit=true"
echo "cmd=$cmd"
response=`$cmd`
if [ "$EXPECT_403" = true ]; then
  echo "response===$response"
  echo $response|grep "Error 403 Forbidden"
  if [ $? -eq 0 ]; then
    echo "/update is forbidden - which is expected - OK"
  else 
    echo "Received response when expected forbidden - Test FAILED"
    exit 1
  fi
else
  echo $response|grep "\"status\":0"
  if [ $? -eq 1 ]; then
    echo "response=$response"
    echo "Update doesn't contain status:0 - test FAILED"
    exit 1
  else
    echo "Update post - OK"
  fi
fi

if [ "$EXPECT_403" != true ]; then
  # Try retrieving the doc just inserted
  escaped_isodate=`echo $isodate | sed s/:/\\\\\\\\:/g`
  cmd="curl $SCHEME://$HOST/solr/$COLLECTION/select?indent=on&q=last_modified:${escaped_isodate}&wt=json"
  echo "cmd=$cmd"
  response=`$cmd`

  echo "escaped_isodate=$escaped_isodate"
  echo "response====$response"

  echo $response|grep "response\":{\"numFound\":1"
  if [ $? -eq 0 ]; then
    echo "/update is OK"
    echo "Test PASSED"
    exit 0
  else 
    echo "Test FAILED"
    exit 1
  fi
fi

