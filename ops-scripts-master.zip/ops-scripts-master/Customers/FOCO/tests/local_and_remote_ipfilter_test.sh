#!/bin/bash

# remote (searchstax-prod-2) IP is whitelisted to access all solr endpoints.
# Whitelisting is done in fastly
# Local IP is not whitelisted.
#
# Test locally and remotely.

# Local
./ipfilter_test.sh true
if [ $? -eq 0 ]; then
  echo "Local test PASSED"
else
  echo "Local test FAILED"
  exit 1
fi

# Remote
ssh -i ~/keys/measuredsearch.pem eric@52.201.44.224 'mkdir -p /tmp/ipfilter_test'
scp -i ~/keys/measuredsearch.pem docs1.json eric@52.201.44.224:/tmp/ipfilter_test
scp -i ~/keys/measuredsearch.pem ipfilter_test.sh eric@52.201.44.224:/tmp/ipfilter_test
ssh -i ~/keys/measuredsearch.pem eric@52.201.44.224 'chmod 755 /tmp/ipfilter_test/ipfilter_test.sh'
ssh -i ~/keys/measuredsearch.pem eric@52.201.44.224 'cd /tmp/ipfilter_test/ && ./ipfilter_test.sh'

#scp -i ~/keys/measuredsearch.pem docs1.json eric@52.201.44.224
#ssh -i ~/keys/measuredsearch.pem eric@52.201.44.224 'cd /tmp/ipfilter_test ; bash -s' < ipfilter_test.sh
#scp -i ~/keys/measuredsearch.pem 'rm docs1.json'
if [ $? -eq 0 ]; then
  echo "Remote test PASSED"
else
  echo "Remote test FAILED"
  exit 1
fi
