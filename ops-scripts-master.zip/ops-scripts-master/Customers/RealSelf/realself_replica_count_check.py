import json
import requests

from datadog import statsd

check = 'app.dr_replica_count_status'
host = 'RealSelf-DrSearch-1'

response = requests.get(url='http://localhost:9200/_settings')
response_json = json.loads(response.content)

success = True
index_name = None

for key, value in response_json.iteritems():

    index_name = key
    num_replicas = int(value['settings']['index']['number_of_replicas'])

    # This logic will skip index starting with "." under condition check for
    # replica count ,ie, will return "OK" even if replica count is less than 2
    if not index_name.startswith(".") and num_replicas < 2:
        success = False

if success is False:
    statsd.service_check(check_name=check, status=statsd.CRITICAL,
                         hostname=host, message=index_name)
else:
    statsd.service_check(check_name=check, status=statsd.OK,
                         hostname=host, message=index_name)

print 'Completed sending metric information: Success: %s' % success
