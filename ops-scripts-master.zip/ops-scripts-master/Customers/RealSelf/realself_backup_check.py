import datetime
import json
import requests
import subprocess

from datadog import statsd

check = 'app.dr_backup_status'
host = 'RealSelf-DrSearch-1'

success = True
TODAY = datetime.date.today()

subprocess.call('sudo rm -rf /opt/data/elasticsearch/backups/es2_yesterday/*',
                shell=True)

subprocess.call('sudo mv /opt/data/elasticsearch/backups/es2_snapshot/*'
                ' /opt/data/elasticsearch/backups/es2_yesterday/', shell=True)

response = requests.put(
    url='http://localhost:9200/_snapshot/es2_snapshot/%s/?wait_for_completion=true'
        % TODAY)
response_json = json.loads(response.content)

for key, value in response_json.iteritems():

    status = value['state']

    if status != 'SUCCESS':
        success = False
    else:
        print 'Backup taken Successfully!'

if success is False:
    statsd.service_check(check_name=check, status=statsd.CRITICAL,
                         hostname=host, message='Backup Failed for host: %s'
                                                % host)
else:
    statsd.service_check(check_name=check, status=statsd.OK,
                         hostname=host, message='Backup Successful for host: %s'
                                                % host)
