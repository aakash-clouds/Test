#!/usr/bin/env python3

import json
from urllib.request import urlopen

url = 'https://prod-kazzam-search.searchstax.com/solr/listings/kazzamsearch?location=75204&model=current&q=princess'

def get_top_id_and_title():
  data = json.load(urlopen(url))
  results = data['response']['docs']
  return results[0]['id'], results[0]['listing_name']

first_id_and_title = get_top_id_and_title()

print("First Result: %s" % first_id_and_title[1])

for i in range(0,100):
    id_and_title = get_top_id_and_title()
    same = first_id_and_title == id_and_title
    same_message = "SAME" if same else "DIFFERENT!"
    print("%d %s - %s" % (i, id_and_title[1], same_message))
    if not same:
        break

print()
if same:
    print("%d fetches were the same" % (i + 1))
else:
    print("Detected a different result!")

