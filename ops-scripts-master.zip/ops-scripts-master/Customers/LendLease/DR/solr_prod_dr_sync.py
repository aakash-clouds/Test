"""
1. check if all nodes are green
2. if yes, create collection-level snapshots
3. create zookeeper dump
4. upload snapshots to DR machines
5. stop DR solrs
6. wipe out solr data
7. replace zookeeper data
8. put inside new solr data
9. start solrs
10. send report
"""

from datetime import datetime
import json
import os
from time import sleep, time
from subprocess import call
import sys
import traceback

import boto3
from dateutil.parser import parse
import dns.resolver
import paramiko
import pytz
import requests

KEY_FILE = '/opt/apps/ss_automation/id_rsa'
FROM_EMAIL = 'tech-ops@measuredsearch.com'
TO_EMAIL = 'tech-ops@measuredsearch.com'
PROD_NODES = ['10.100.2.36', '10.100.2.38', '10.100.2.37']
PROD_HA_RR = 'lendlease-prod.measuredsearch.com'
PROD_HA_RR_VALUE = 'ss294845-australia-east-azure.measuredsearch.com.'
DR_LEADER = '10.100.4.36'
DR_NODES = ['10.100.4.36', '10.100.4.37', '10.100.4.38']
BACKUP_LOCATION = '/tmp/backups'
DATA_DIR = '/opt/data/solr/'
COLLECTION_DIR = {}
SYSTEMD = True
CLUSTERSTATUS_URL = '/solr/admin/collections?action=CLUSTERSTATUS&wt=json'
DR_BASE = 'https://ss980382-australia-southeast-azure.measuredsearch.com'



def send_message(level, message):
    """
    Send email using SES
    """
    session = boto3.Session(profile_name='ses', region_name='us-east-1')
    client = session.client('ses')
    client.send_email(
        Source=FROM_EMAIL,
        Destination={'ToAddresses': [TO_EMAIL]},
        Message={
            'Subject': {'Data': '%s LendLease DR data sync' % level},
            'Body': {'Text': {'Data': message}}
        }
    )
    print message


def send_warning(message):
    """
    WARNING message shortcut
    """
    send_message('WARNING', message)


def send_info(message):
    """
    INFO message shortcut
    """
    send_message('INFO', message)


def send_error(message):
    """
    ERROR message shortcut
    """
    send_message('ERROR', message)


def check_endpoint_value():
    """
    Check if dns points to expected value
    """
    answers = dns.resolver.query(PROD_HA_RR, 'CNAME')
    if answers:
        record = answers[0]
        value = record.to_text()
        if value != PROD_HA_RR_VALUE:
            return False
        else:
            return True
    return None


def get_collections_list():
    """
    Read CLUSTERSTATUS and prepare collections list
    """
    response = requests.get('http://localhost:8983{}'.format(CLUSTERSTATUS_URL))

    if response.status_code != 200:
        raise Exception(
            "read_collections() returned incorrect status {}".format(response.status_code))

    cluster_status = json.loads(response.text)
    return cluster_status['cluster']['collections'].keys()


def create_snapshot(collection):
    """
    Create collection snapshot
    """
    backup_start = time()
    base_url = 'http://localhost:8983/solr/{}/replication?'.format(collection)
    start_after = datetime.utcnow().replace(tzinfo=pytz.UTC).replace(microsecond=0)
    solr_backup_location = '{}/solr'.format(BACKUP_LOCATION)
    # drop old snapshot data
    try:
        rmstring = '{}/snapshot.{}'.format(solr_backup_location, collection)
        if 'snapshot' in rmstring:
            os.system("sudo rm -rf {}".format(rmstring))
    except Exception as exc:
        pass
    response = requests.get(
        '{}command=backup&numberToKeep=2&location={}&name={}'.format(
            base_url,
            solr_backup_location,
            collection
        )
    )

    if response.status_code != 200:
        raise Exception(
            "create_snapshot({}) returned incorrect status {}".format(
                collection,
                response.status_code
            )
        )
    sleep(5)
    cycles = 0
    while True:
        response = requests.get('{}command=details&wt=json'.format(base_url))
        if response.status_code != 200:
            raise Exception(
                "create_snapshot({}) returned incorrect status {} while reading details".format(
                    collection,
                    response.status_code
                )
            )
        data = json.loads(response.text)
        if 'details' not in data or 'backup' not in data['details']:
            sleep(10)
            continue
        backup = data['details']['backup']
        parsed = parse(backup[7])
        if parsed >= start_after and backup[5] == 'success':
            break
        sys.stdout.write('.')
        sys.stdout.flush()
        sleep(10)
        cycles += 1
        if cycles == 60:
            send_warning('Backing up {} takes long time'.format(collection))
    total_backup = time() - backup_start
    sys.stdout.write('{} Backup took {}'.format(collection, total_backup))
    return True


def dump_zk():
    """
    Dump Zookeeper collections data
    """
    print "dumping zk"
    try:
        shutil.rmtree('/tmp/zkdump')
    except:
        pass
    zk_nodes = "localhost:2181"
    call(
        "java -jar /opt/apps/guano-0.1a.jar -s '%s' -o '/tmp/zkdump' -d '/'" % zk_nodes,
        shell=True
    )


def update_zk_data():
    """
    Update state.json per collection
    """
    root = '/tmp/zkdump/collections/'
    dirs = os.listdir(root)
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    for cdir in dirs:
        state = open('{}{}/state.json'.format(root, cdir), 'r').read()
        new_state = '{}'.format(state)
        for i, node in enumerate(PROD_NODES):
            new_state = new_state.replace(node, DR_NODES[i])
        new_state = json.loads(new_state)
        for col in new_state.keys():
            print col
            shards = new_state[col]['shards'].keys()
            for shard in shards:
                for replica in new_state[col]['shards'][shard]['replicas'].keys():
                    obj = new_state[col]['shards'][shard]['replicas'][replica]
                    remote_host = obj['base_url'].split('/')[2].split(':')[0]
                    remote_dir = '{}{}'.format(DATA_DIR, obj['core'])
                    remote_core = '\n'.join([
                        'numShards=1',
                        'collection.configName=%s' % cdir,
                        'name=%s' % obj['core'],
                        'shard=%s' % shard,
                        'collection=%s' % col,
                        'coreNodeName=%s' % replica,
                    ])
                    if remote_host not in COLLECTION_DIR:
                        COLLECTION_DIR[remote_host] = {}
                    COLLECTION_DIR[remote_host][col] = remote_dir
                    client.connect(hostname=remote_host, username='ubuntu', key_filename=KEY_FILE)
                    (_, stdout, stderr) = client.exec_command(
                        'sudo rm -rf {}/{}_*'.format(DATA_DIR, col)
                    )
                    stdout.read()
                    stderr.read()
                    (_, stdout, stderr) = client.exec_command(
                        'sudo mkdir -p {}'.format(remote_dir))
                    stdout.read()
                    stderr.read()
                    sleep(0.5)
                    (_, stdout, stderr) = client.exec_command(
                        'sudo chown solr:solr {}'.format(remote_dir))
                    stdout.read()
                    stderr.read()
                    sleep(0.5)
                    (_, stdout, stderr) = client.exec_command(
                        "echo '{}'|sudo tee {}/core.properties".format(remote_core, remote_dir))
                    stdout.read()
                    stderr.read()
                    sleep(0.5)
                    (_, stdout, stderr) = client.exec_command(
                        "sudo chown root:root {}/core.properties".format(remote_dir))
                    stdout.read()
                    stderr.read()

def restore_zk():
    """
    Restore zk in dr environment
    """
    print "restoring zk"
    zk_nodes = ','.join(['%s:2181' % x for x in DR_NODES])
    print "clearing"
    call(
        "/opt/apps/solr/server/scripts/cloud-scripts/zkcli.sh -z '%s' -cmd clear /" % zk_nodes,
        shell=True
    )
    print "uploading"
    call(
        "java -jar /opt/apps/guano-0.1a.jar -s '%s' -i '/tmp/zkdump' -r '/'" % zk_nodes,
        shell=True
    )


def restore_collection(collection, hostname):
    """
    Restore collection from snapshot
    """

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=hostname, username='ubuntu', key_filename=KEY_FILE)
    (_, stdout, stderr) = client.exec_command(
        'sudo mkdir -p {}/data/index'.format(COLLECTION_DIR[hostname][collection]))
    stdout.read()
    stderr.read()
    sleep(0.5)
    (_, stdout, stderr) = client.exec_command(
        'sudo rm -rf {}/data/index/*'.format(COLLECTION_DIR[hostname][collection]))
    stdout.read()
    stderr.read()
    sleep(0.5)
    (_, stdout, stderr) = client.exec_command(
        'sudo chown -R ubuntu:ubuntu {}/'.format(COLLECTION_DIR[hostname][collection])
    )
    stdout.read()
    stderr.read()
    sleep(0.5)
    sftp = client.open_sftp()
    snapshot_dir = '{}/solr/snapshot.{}'.format(BACKUP_LOCATION, collection)
    for _, _, files in os.walk(snapshot_dir):
        for obj in files:
            sftp.put(
                '{}/{}'.format(snapshot_dir, obj),
                '{}/data/index/{}'.format(COLLECTION_DIR[hostname][collection], obj)
            )
    (_, stdout, stderr) = client.exec_command(
        'sudo chown -R solr:solr {}/'.format(COLLECTION_DIR[hostname][collection]))
    stdout.read()
    stderr.read()
    sleep(0.5)


def stop_remote_solr(hostname):
    """
    Stop remote Solr
    """
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=hostname, username='ubuntu', key_filename=KEY_FILE)
    if SYSTEMD:
        (_, stdout, stderr) = client.exec_command(
            'sudo systemctl stop solr'
        )

    else:
        (_, stdout, stderr) = client.exec_command(
            'sudo /etc/init.d/solr stop')
    print stdout.read()
    print stderr.read()

def start_remote_solr(hostname):
    """
    Start remote Solr
    """
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(hostname=hostname, username='ubuntu', key_filename=KEY_FILE)
    if SYSTEMD:
        (_, stdout, stderr) = client.exec_command(
            'sudo systemctl start solr'
        )

    else:
        (_, stdout, stderr) = client.exec_command(
            'sudo /etc/init.d/solr start')
    print stdout.read()
    print stderr.read()


def collection_status(collection, hostname=DR_BASE):
    """
    Read CLUSTERSTATUS and check collection status
    """
    url = '{}{}'.format(hostname, CLUSTERSTATUS_URL)
    response = requests.get(url)
    if response.status_code != 200:
        raise Exception("reading backup cluster status failed")
    status = json.loads(response.text)
    live_nodes = len(status['cluster']['live_nodes'])
    if live_nodes != len(DR_NODES):
        raise Exception("Number of expected live nodes doesn't match")
    for key, val in status['cluster']['collections'].items():
        if key != collection:
            continue
        states = ['active' for x in val['shards']['shard1']['replicas'].values() \
            if x['state'] == 'active']
    if len(states) == len(DR_NODES):
        return True
    else:
        return False


def main():
    """
    Main
    """
    if not check_endpoint_value():
        send_error('Cluster is in DR mode, exiting backup')
        return False
    start_time = time()
    print "read collections list"
    collections = get_collections_list()
    if not collections:
        send_warning('Source cluster has no collections to sync\n')
        return True

    print "check collection states"
    for collection in collections:
        cst = collection_status(collection, 'http://localhost:8983')
        if not cst:
            send_error('Collection {} is not fully operational, aborting sync'.format(collection))
            return False

    print "create local snapshots"
    for collection in collections:
        print collection
        create_snapshot(collection)

    print "dump zookeeper"
    dump_zk()

    print "stop remote solrs"
    for hostname in DR_NODES:
        stop_remote_solr(hostname)

    print "update zookeeper data"
    update_zk_data()

    print "restore zookeeper on remote hosts"
    restore_zk()

    print "restore collections"
    for hostname in DR_NODES:
        for collection in collections:
            restore_collection(collection, hostname)
        start_remote_solr(hostname)
        sleep(30)

    sleep(30)
    collections_output = []
    nok = False
    print "check collection statuses"
    for collection in collections:
        cycles = 0
        while True:
            cst = collection_status(collection)
            if cst:
                collections_output.append('{}: OK'.format(collection))
                break
            sleep(5)
            cycles += 1
            if cycles > 60:
                collections_output.append('{}: NOK'.format(collection))
                nok = True
                break

    time_dist = time() - start_time
    message = 'Backup took {} seconds, follows list of collections:\n\n{}'.format(
        int(time_dist),
        '\n'.join(collections_output)
    )
    if nok:
        send_warning(message)
    else:
        send_info(message)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        send_error(str(traceback.format_exc()))
