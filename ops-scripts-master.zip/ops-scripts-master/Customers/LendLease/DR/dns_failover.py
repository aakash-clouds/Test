"""
1. check zabbix triggers for prod
2. if more than 1 machine unhealthy, check triggers for dr
3. if prod unhealthy and dr unhealthy send alert
4. if prod unhealthy and dr healthy switch to dr and send alert
5. if prod healthy again, send alert
"""

import json
import traceback

import boto3
import requests

FROM_EMAIL = 'tech-ops@measuredsearch.com'
TO_EMAIL = 'tech-ops@measuredsearch.com'

ZABBIX_USER = 'USER'
ZABBIX_PASSWORD = 'PASS'
ZABBIX_URL = 'http://52.4.168.202/zabbix/api_jsonrpc.php'

TRIGGERS_PROD = ['65632', '65633', '65634']
TRIGGERS_DR = ['65629', '65630', '65631']

RECORD_ZONE_ID = 'Z2EQ0AKBFIEM70'
RECORD_SET = 'lendlease-prod.measuredsearch.com'
PROD_VALUE = 'ss294845-australia-east-azure.measuredsearch.com'
DR_VALUE = 'ss980382-australia-east-azure.measuredsearch.com'

STATE_FILE = '/tmp/dnsfailover.state'


def send_message(level, message, subject=''):
    """
    Send email using SES
    """
    session = boto3.Session(profile_name='lendlease', region_name='us-east-1')
    client = session.client('ses')
    client.send_email(
        Source=FROM_EMAIL,
        Destination={'ToAddresses': [TO_EMAIL]},
        Message={
            'Subject': {'Data': '{} LendLease FAILOVER {}'.format(level, subject)},
            'Body': {'Text': {'Data': message}}
        }
    )
    print message


def send_warning(message, subject=''):
    """
    WARNING message shortcut
    """
    send_message('WARNING', message, subject)


def send_info(message, subject=''):
    """
    INFO message shortcut
    """
    send_message('INFO', message, subject)


def send_error(message, subject=''):
    """
    ERROR message shortcut
    """
    send_message('ERROR', message, subject)


def zabbix_triggers():
    """
    Read Zabbix triggers
    """
    headers = {"content-type": "application/json"}

    # perform login
    response = requests.get(
        ZABBIX_URL,
        data=json.dumps({
            'method': 'user.login',
            'params': {'user': ZABBIX_USER, 'password': ZABBIX_PASSWORD},
            'jsonrpc': '2.0',
            'id': 1
        }),
        headers=headers
    ).json()
    if 'result' in response:
        token = response['result']
    else:
        raise Exception("Zabbix Login Failed")

    # read trigger statuses
    payload = {
        'method': 'trigger.get',
        'params': {'triggerids': TRIGGERS_PROD + TRIGGERS_DR},
        'jsonrpc': '2.0',
        'id': 2,
        'auth': token
    }

    response = requests.get(
        ZABBIX_URL,
        data=json.dumps(payload),
        headers=headers
    ).json()
    if 'result' in response:
        return response['result']
    else:
        raise Exception("Zabbix trigger.get failed")


def read_state(key=None):
    """
    Read state from state file
    """
    try:
        data = json.loads(open(STATE_FILE).read())
        if key:
            return data[key]
        else:
            return data
    except IOError:
        return None


def write_state(key, val):
    """
    Write state to state file
    """
    data = read_state()
    if not data:
        data = {}
    data[key] = val
    with open(STATE_FILE, 'w') as fd:
        fd.write(json.dumps(data))
    return True


def perform_failover():
    """
    Change CNAME value
    """
    session = boto3.Session(profile_name='lendlease', region_name='us-east-1')
    client = session.client('route53')
    response = client.list_resource_record_sets(
        HostedZoneId=RECORD_ZONE_ID,
        StartRecordName=RECORD_SET,
        StartRecordType='CNAME'
    )
    record_set = response['ResourceRecordSets'][0]['ResourceRecords'][0]
    if record_set['Value'] == PROD_VALUE:
        response = client.change_resource_record_sets(
            HostedZoneId=RECORD_ZONE_ID,
            ChangeBatch={
                'Changes': [{
                    'Action': 'UPSERT',
                    'ResourceRecordSet': {
                        'Name': RECORD_SET,
                        'Type': 'CNAME',
                        'ResourceRecords': [{'Value': DR_VALUE}],
                        'TTL': 180,
                    }
                }]
            }
        )
        if response['ChangeInfo']['Status'] == 'PENDING':
            send_info(message='Failover performed, DNS record changed to {}'.format(DR_VALUE))
        else:
            send_error(
                message='Modifying DNS record returned {}'.format(response['ChangeInfo']['Status'])
            )


def main():
    """
    Main execution loop
    """
    triggers = zabbix_triggers()
    if len(triggers) != len(TRIGGERS_PROD + TRIGGERS_DR):
        raise Exception("number of retrieved triggers doesn't match number of nodes")

    prods = 0
    drs = 0
    for trigger in triggers:
        if trigger['triggerid'] in TRIGGERS_PROD and trigger['value'] == '0':
            prods += 1
        if trigger['triggerid'] in TRIGGERS_DR and trigger['value'] == '0':
            drs += 1
    # process trigger results
    previous_triggers = read_state('triggers')
    if prods >= 2:
        if not previous_triggers:
            pass
        else:
            if previous_triggers[0] >= 2:
                pass
            else:
                send_warning(
                    message='Primary cluster recovered, proceed with manual switch back',
                    subject='Manual switchback required'
                )
    else:
        if drs >= 2:
            write_state('triggers', [prods, drs])
            perform_failover()
        else:
            send_error(
                message='Both Primary and DR are DOWN. Proceed manually',
                subject='Both Prod and DR are DOWN'
            )
    write_state('triggers', [prods, drs])


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        send_error(traceback.print_exc())
