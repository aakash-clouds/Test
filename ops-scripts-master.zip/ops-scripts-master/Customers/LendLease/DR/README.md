# Lendlease DR scripts

## Solr data sync

To perform Solr data sync, script `solr_prod_dr_sync.py` is used. It is deployed in second machine of the primary deployment (ss98382-2). Executed as a cronjob running under root user.

Installation instructions:

1. source /opt/apps/ss_automation/env/bin/activate
2. pip install boto3 requests pytz paramiko dnspython
3. put guano-0.1a.jar into /opt/apps/guano-0.1a.jar
4. put private key for ubuntu user (not searchstax key!!!) into /opt/apps/ss_automation/id_rsa
5. put public key for ubuntu user to authorized_keys in ubuntu user homedires on each DR node
6. configure awscli for profile called 'ses' for root user (/opt/apps/ss_automation/env/bin/aws configure)
7. edit solr_prod_dr_sync.py (PROD_NODES, DR_LEADER, DR_NODES, DR_BASE)

## DNS failover

DNS failover is provided by executing `dns_failover_py`. This script gathers information from Zabbix, so it is important to preserve all Solr triggers on each primary and DR nodes of respective primary and DR deployments (in this case: 65629, 65630, 65631, 65632, 65633, 65634). This script must run outside of Lendlease environments. It is deployed in searchstax-jobserver-1 under ubuntu user. Holds simple /tmp/dnsfailover.state fail where it stores previous states. This allows the script to understand stateful changes between runs/iterations. Script requires special IAM permissions attached to `lendlease-ses` user in production AWS environment.

Attached permissions are:

- sending emails to tech-ops@measuredsearch.com
- modifying searchstax.com dns zone. *IMPORTANT NOTE*: there is additonal IP address condition for this permission (searchstax-jobserver-1 public IP)

DNS modification permission:

```JSON
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "VisualEditor0",
            "Effect": "Allow",
            "Action": [
                "route53:ChangeResourceRecordSets",
                "route53:ListResourceRecordSets"
            ],
            "Resource": "arn:aws:route53:::hostedzone/ZIYKMMG5AMVVV",
            "Condition": {
                "IpAddress": {
                    "aws:SourceIp": "52.201.44.224/32"
                }
            }
        }
    ]
}
```

Script can only switch from PROD to DR. Once PROD was recovered, manual DNS change is required.

Installation instructions:

1. log in to searchstax-jobserver-1
2. `sudo mkdir /opt/lendlease`
3. `sudo chown ubuntu:ubuntu /opt/lendlease`
4. put dns_failover.py into /opt/lendlease/dns_failover.py
5. edit the file and modify variables `ZABBIX_USER` and `ZABBIX_PASSWORD` (in rare case modify other corresponding variables)
6. add `[lendlease]` profile into /home/ubuntu/.aws/credentials
7. add cron task for ubuntu user `* * * * * /opt/searchstax/env/bin/python /opt/lendlease/dns_failover.py`
