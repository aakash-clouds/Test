echo "Tagging instance $1"

aws ec2 create-tags \
   --resources $1 \
   --tags Key=Name,Value=searchstax-simulator-crawler \
   --profile ms-dev-jenkins
