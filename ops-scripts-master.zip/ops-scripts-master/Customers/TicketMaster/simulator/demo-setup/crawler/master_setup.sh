#!/bin/bash

tmpdir=/tmp/ec2-setup

rm -rf $tmpdir
mkdir $tmpdir

./run_instance.sh > $tmpdir/run_instance-out.json
echo "response from AWS:"
cat $tmpdir/run_instance-out.json
instanceid=`cat $tmpdir/run_instance-out.json|python -c "import sys, json; print(json.load(sys.stdin)['Instances'][0]['InstanceId'])"`
echo "start instance $instanceid"
./tag_instance.sh $instanceid