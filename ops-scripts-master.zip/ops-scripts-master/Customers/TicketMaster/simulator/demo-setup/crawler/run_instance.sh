aws ec2 run-instances \
   --image-id ami-16efb076 \
   --key-name searchstax-dev \
   --user-data file://instance_setup.sh \
   --count 1 \
   --instance-type t2.micro \
   --profile ms-dev-jenkins

