#!/bin/bash

# See https://alestic.com/2010/12/ec2-user-data-output/
exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

sudo apt update
sudo apt install -y emacs24
sudo apt install -y python-minimal
sudo apt install -y python-pip
pip install virtualenv
mkdir -p /home/ubuntu/virtualenvs
virtualenv -p /usr/bin/python2 /home/ubuntu/virtualenvs/env-py2
source /home/ubuntu/virtualenvs/env-py2/bin/activate
pip install -i https://testpypi.python.org/pypi searchstax-simulator-crawler
echo "Executing searchclick_crawler"
searchclick_crawler > /tmp/searchclick_crawler_out.txt
echo "Executing search_crawler"
search_crawler > /tmp/search_crawler_out.txt
