if [ $# -ne 1 ]; then
        echo $0: usage: klsqa-update-script \<release\>
        exit 1
fi
release=$1
cd ~
echo "=================DECOMPRESSING FILES================="
tar -zxvf release-$release.tar.gz
cd release-$release
tar -xvf bodhi_configset-*.tar
tar -xvf pipeline-*.tar
tar -xvf pipeline_input_data-*.tar
tar -xvf users_configset-*.tar
sleep 5
#echo "==============DELETING BODHI COLLECTION=============="
#curl -k "https://ss927466-east-us-azure.measuredsearch.com/solr/admin/collections?action=DELETE&name=bodhi"
#sleep 5
echo "=================BACKING UP PIPELINE================="
sudo mv /opt/data/pipeline /opt/data/pipeline.`date +%F`
sleep 5
echo "==================UPDATING PIPELINE=================="
sudo rsync -avh `ls -d */ | grep ^[0-9]` /opt/data/pipeline
sudo chown -R klsqa:sftponly /opt/data/pipeline
sudo sed -i "s|localhost:2181/solr|10.0.0.4:2181,10.0.0.5:2181,10.0.0.6:2181/solr\n|g" /opt/data/pipeline/configs/kelly-customer.properties
sudo sed -i "s|localhost:2181/solr|10.0.0.4:2181,10.0.0.5:2181,10.0.0.6:2181/solr\n|g" /opt/data/pipeline/configs/kelly-supplier.properties
sleep 5
echo "====================BACKING UP UI===================="
sudo cp -R /opt/apps/apache-tomcat-8.5.4 /opt/apps/apache-tomcat-8.5.4.`date +%F`
sleep 5
echo "=====================UPDATING UI====================="
unzip -d ui ui-*.war
sudo /etc/init.d/tomcat8 stop
sudo rm -fr /opt/apps/apache-tomcat-8.5.4/webapps/ROOT
sudo rsync -avh ui/ /opt/apps/apache-tomcat-8.5.4/webapps/ROOT
sudo chown -R tomcat. /opt/apps/apache-tomcat-8.5.4
sudo /etc/init.d/tomcat8 start
sleep 5
echo "====================COMPRESSING UI==================="
sudo tar -zcvf ~/release-$release/tomcat-$release.tar.gz /opt/apps/apache-tomcat-8.5.4
sleep 5
echo "================UPDATING BODHI CONFIG================"
sh /opt/apps/solr/server/scripts/cloud-scripts/zkcli.sh -cmd upconfig -zkhost 10.0.0.4:2181,10.0.0.5:2181,10.0.0.6:2181/solr -confname bodhi -confdir `ls -d */ | grep bodhi_configset`
sleep 5
echo "================UPDATING USERS CONFIG================"
sh /opt/apps/solr/server/scripts/cloud-scripts/zkcli.sh -cmd upconfig -zkhost 10.0.0.4:2181,10.0.0.5:2181,10.0.0.6:2181/solr -confname users -confdir `ls -d */ | grep users_configset`
sleep 5
#echo "=============RECREATING BODHI COLLECTION=============="
#curl -k "https://ss927466-east-us-azure.measuredsearch.com/solr/admin/collections?action=CREATE&name=bodhi&configname=bodhi&numShards=1&replicationFactor=3"
echo "==============RELOADING USER COLLECTION=============="
curl -k "https://ss927466-east-us-azure.measuredsearch.com/solr/admin/collections?action=RELOAD&name=users"
echo "==============RELOADING BODHI COLLECTION=============="
curl -k "https://ss927466-east-us-azure.measuredsearch.com/solr/admin/collections?action=RELOAD&name=bodhi"
#echo "===============BACKING UP PIPELINE DATA=============="
#sudo mv /opt/data/input_data /opt/data/input_data.`date +%F`
#sleep 5
#echo "================UPDATING PIPELINE DATA==============="
#sudo rm -fr /opt/data/input_data
#sudo rsync -avh pipeline_input_data/ /opt/data/input_data
#sudo chown -R klsqa:sftponly /opt/data/input_data
#sudo /opt/data/cron_pipeline
#sleep 5

