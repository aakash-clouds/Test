if [ $# -ne 1 ]; then
        echo usage: $0 \<release\>
        exit 1
fi
release=$1
scp -i searchstax.pem ms@ftp.measuredsearch.com:release-$release.tar.gz .
sleep 5
scp -i searchstax.pem release-$release.tar.gz ubuntu@ss979816-2-east-us-azure.measuredsearch.com:.
sleep 5
rm release-$release.tar.gz
sleep 5
scp -i searchstax.pem klsprod-update-script.sh ubuntu@ss979816-2-east-us-azure.measuredsearch.com:.
sleep 5
ssh -ti searchstax.pem ubuntu@ss979816-2-east-us-azure.measuredsearch.com sh klsprod-update-script.sh $release
sleep 5
scp -i searchstax.pem ubuntu@ss979816-2-east-us-azure.measuredsearch.com:release-$release/tomcat-$release.tar.gz .
sleep 5
scp -i searchstax.pem tomcat-$release.tar.gz ubuntu@ss979816-1-east-us-azure.measuredsearch.com:.
sleep 5
ssh -ti searchstax.pem ubuntu@ss979816-1-east-us-azure.measuredsearch.com sudo tar -zxvf tomcat-$release.tar.gz -C /
sleep 5
ssh -ti searchstax.pem ubuntu@ss979816-1-east-us-azure.measuredsearch.com sudo -u root -i eval '/etc/init.d/tomcat8 stop; sudo -u root -i /etc/init.d/tomcat8 start'
echo DONE!