# Procedure to be followed prior to the below script: https://searchstax.atlassian.net/wiki/spaces/PO/pages/152272924/One-time+Backup+for+Multi-Shard+Collection

import argparse
from datetime import datetime
import json
import sys
import subprocess
from time import sleep, time
import urllib
import urllib2

def main():
    process = subprocess.Popen(
        "curl -vs 'http://localhost:8983/solr/admin/collections?action=CLUSTERSTATUS&wt=json'",
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=True
    )
    output, err = process.communicate()
    status = json.loads(output)
    sys.stdout.write('Performing collections backups\n')
    sys.stdout.flush()
    for collection in status['cluster']['collections'].keys():
        print collection
        process = subprocess.Popen(
            "curl -vs 'http://localhost:8983/solr/admin/collections?action=BACKUP&name=%s&location=/opt/efs/backups&collection=%s'" % (collection, collection),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=True
        )
        process.communicate()
    sys.stdout.write('Backup complete\n')
    sys.stdout.flush()

if __name__=="__main__":
    main()
