#!/bin/bash

# script to execute the analytics stats ingestor

ingestorDir=/opt/apps/ss_automation/ingestor
log=/logs/ingestor.log
ingestorJar=/search-api-all-1.0.jar

java \
  -Dingestor.log=$log \
  -Dingestor.tenant=Ticketmaster \
  -Dingestor.app=sa971389 \
  -Dingestor.token=7VWpxdQsQn2tghICYBwQ+A \
  -Dingestor.searchclick_count=listing_view_count \
  -Dingestor.transaction_count=listing_sold_count \
  -Dingestor.ctc_rate=listing_conv_rate \
  -jar $ingestorJar
