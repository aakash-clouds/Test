#!/bin/sh

find /Users/eric/Desktop/ForFiling/MModal/data/SearchStax/laheyOutdeid1/721*.out.xml \
-exec sh -c 'f={};echo "uploading $f";./post_data.sh mmodal-playground docs $f' \;