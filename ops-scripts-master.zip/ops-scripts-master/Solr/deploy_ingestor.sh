#!/bin/bash

if [ "$#" -ne 1 ]; then
  echo "Usage: deploy_ingestor.sh <env>"
  exit 1
fi

key=~/keys/searchstax.pem

scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
projectdir="$(dirname $scriptdir)"
code_dir="$(dirname $projectdir)"
searchapi_dir="$code_dir/search-api"

jarfile="$searchapi_dir/build/libs/search-api-all-1.0.jar"

source configs/$1.sh

echo "Building jar..."
pushd $projectdir
gradle clean
gradle fatJar
popd

echo "Creating ingestor script..."
$scriptdir/make_exec_ingestor.sh $1

# push script and jar
scp $scriptdir/exec_ingestor.sh $jarfile $host:/home/ubuntu
# push script only
#scp $scriptdir/exec_ingestor.sh $host:/home/ubuntu
# move script to proper home
ssh $host 'bash -s' < deploy_ingestor_helper.sh
