#!/bin/bash

customer=mmodal
host=ss660178
solrhost="${host}-us-east-1-aws.searchstax.com"
solr="https://$solrhost/solr"
zkhost=$solrhost:2181