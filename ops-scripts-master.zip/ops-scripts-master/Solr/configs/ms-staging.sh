#!/bin/bash

# TODO source kazzam-common

source secrets.sh

customer=kazzam
host=ss715288
tenant=Ticketmaster
app=sa971389
token=$ticketmaster_token_sa971389
solrhost="${host}-us-west-2-aws.measuredsearch.com"
solr="https://$solrhost/solr"
zkhost=$solrhost:2181