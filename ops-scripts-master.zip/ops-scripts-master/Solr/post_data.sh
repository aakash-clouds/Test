#!/bin/bash

# Script which posts data to a collection

if [ "$#" -ne 3 ]; then
  echo "Usage: post_data <env> <collection> <datafile>"
  exit 1
fi

env=$1
collection=$2
datafile=$3

. configs/$env.sh

scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
datadir="$(dirname $scriptdir)/data"

# without latlon processor
#curl -X POST -H 'Content-type:application/json' -d @"$datadir/$datafile" "$solr/$collection/update?commit=true"
curl -X POST -H 'Content-type:application/json' -d @"$datadir/$datafile" "$solr/$collection/update?commit=true&processor=add-latlon-from-zip"
