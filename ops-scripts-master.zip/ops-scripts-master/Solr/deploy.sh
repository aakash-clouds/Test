#!/bin/bash

# Script which deploys the jar file to a solr deployment

if [ "$#" -eq 3 ]; then
  firstdeploy=true
elif [ "$#" -ne 2 ]; then
  echo "Usage: deploy.sh <env> <collection> [<firstdeploy>]"
  exit 1
fi

env=$1
collection=$2

. configs/$env.sh

echo "Going to upload to $solr"
blobname=searchapi
scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ops_scripts_dir="$(dirname $scriptdir)"
code_dir="$(dirname $ops_scripts_dir)"
api_dir="$code_dir/search-api"

jarfile="$api_dir/build/libs/search-api-1.0.jar"

echo "Building jar..."
pushd $api_dir
#gradle build
gradle jar
popd

# Creaete .system collection - one time operation
#echo "Creating system collection..."
#curl "$solr/admin/collections?action=CREATE&name=.system"

# Uplaod jar using blobstore api
echo "Uploading $jarfile..."
curl -X POST -H 'Content-Type: application/octet-stream' --data-binary @$jarfile $solr/.system/blob/$blobname

# Get latest version
curl "$solr/.system/select?indent=on&rows=10000&q=*:*&wt=json" > /tmp/blobs.json
version=$($scriptdir/get_latest_blob_version.py)
echo "Uploaded jar version $version"

# initial upload of blob - first time
if [ $firstdeploy ]; then
  curl $solr/$collection/config -H 'Content-type:application/json' -d "{'add-runtimelib': { 'name':$blobname, 'version':$version }}"
else
  curl $solr/$collection/config -H 'Content-type:application/json' -d "{'update-runtimelib': { 'name':$blobname, 'version':$version }}"
fi


# deregister - not used often
#curl $solr/$collection/config -H 'Content-type:application/json' -d "{'delete-runtimelib': $blobname }"
