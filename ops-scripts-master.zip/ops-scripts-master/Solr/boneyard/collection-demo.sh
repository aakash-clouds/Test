#!/bin/bash

# Set up a collection, upload some data, test it, tear down the collection
# ref: http://measuredsearch.com/docs/#4-upload-a-solr-configuration

if [ $# -ne 2 ]; then
  echo "Usage: $0 <zk_url> <solr_url>"
  #From https://searchstax.measuredsearch.com/admin/deployment/364/servers
  SOLR_URL=https://ss460648-us-west-1-aws.measuredsearch.com/solr/
  ZK_HOST_AND_PORT=ss460648-1-zk-us-west-1-aws.measuredsearch.com:2181
  echo "Using defaults for SOLR_URL and ZK_HOST_AND_PORT"
else 
  SOLR_URL=$1
  ZK_HOST_AND_PORT=$2
fi

COLLECTION_NAME=testcollection

TOOLS_DIR=/tmp/tools
SS_CLIENT_DIR=$TOOLS_DIR/searchstax-client/solr-5
ZK_CLI_DIR=$SS_CLIENT_DIR/scripts
ZK_CLI=$ZK_CLI_DIR/zkcli.sh
DATA_DIR=$SS_CLIENT_DIR/DATA
SEARCHSTAX_CLIENT_ZIP=https://github.com/measuredsearch/searchstax-client/archive/master.zip

CONF_DIR=$SS_CLIENT_DIR/configsets/basic_configs/conf
CONF_NAME=basic_config

HOME_DIR=`pwd`

echo "Ensuring tools exists..."
if [ -e $SS_CLIENT_DIR ]; then
  echo "Tools exist, skipping tools download."
else
  echo "tools not found, installing..."
  mkdir -p $TOOLS_DIR
  cd $TOOLS_DIR
  curl -L -O $SEARCHSTAX_CLIENT_ZIP
  unzip master.zip
  mv searchstax-client-master searchstax-client
  cd HOME_DIR
fi

echo "Uploading config..."
cd $ZK_CLI_DIR
$ZK_CLI -zkhost $ZK_HOST_AND_PORT -cmd upconfig -confdir $CONF_DIR -confname $CONF_NAME
cd $HOME_DIR

echo "Creating collection..."
curl "${SOLR_URL}admin/collections?action=CREATE&name=$COLLECTION_NAME&collection.configName=$CONF_NAME&numShards=1"

echo "Uploading data..."
cd $DATA_DIR
curl -X POST -H 'Content-type:application/json' -d @sample.json "$SOLR_URL$COLLECTION_NAME/update?commit=true"
cd $HOME_DIR

echo "Querying Data..."
RESULTS=`curl "$SOLR_URL$COLLECTION_NAME/select?q=*:*&wt=json&indent=true"`

echo "Testing results..."
echo $RESULTS|grep -q 'TestDoc2'
if [ $? -eq 0 ]
then
  echo "Query Test Succeded"
else 
  echo "Query Test Failed"
fi

echo "Deleting Collection..."
curl "${SOLR_URL}admin/collections?action=DELETE&name=$COLLECTION_NAME"

echo "Deleting config..."
cd $ZK_CLI_DIR
$ZK_CLI -zkhost $ZK_HOST_AND_PORT -cmd clear "/configs/$CONF_NAME"
cd $HOME_DIR

# TODO: Delete the deployment

echo "Finished!"
