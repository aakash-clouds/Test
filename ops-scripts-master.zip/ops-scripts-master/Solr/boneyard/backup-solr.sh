export HOME=/home/ubuntu
CURR_TIME="`date +%F-%H-%M`"

SOLR_URL="https://localhost:8983/solr"
SOLR_COLLECTION="leads"
BACKUP_DIR="/opt/data/snapshot"
BACKUP_NAME="$SOLR_COLLECTION-$CURR_TIME"
BACKUP_BUCKET="oportun-measuredsearch"

curl -k --user "MeasuredSearch:X7AKDTVz8b2bQE9S" "$SOLR_URL/$SOLR_COLLECTION/replication?command=backup&name=$BACKUP_NAME&collection=$SOLR_COLLECTION&location=$BACKUP_DIR&wt=json&indent=true"
cd /opt/data/snapshot
sleep 1800
sudo tar -zcvf $BACKUP_NAME.tar.gz snapshot.$BACKUP_NAME
sudo /usr/local/bin/aws s3 mv $BACKUP_NAME.tar.gz "s3://$BACKUP_BUCKET/$BACKUP_NAME.tar.gz"
echo $? > /var/lib/zabbix/bkup_status
sudo rm $BACKUP_NAME.tar.gz
sudo rm -r snapshot.$BACKUP_NAME
