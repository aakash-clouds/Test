#!/bin/bash

if [ "$#" -ne 1 ]; then
  echo "Usage: make_exec_ingestor.sh <env>"
  exit 1
fi

source configs/$1.sh

cat <<EOF > exec_ingestor.sh
#!/bin/bash

# script to execute the analytics stats ingestor

ingestorDir=/opt/apps/ss_automation/ingestor
log=$ingestorDir/logs/ingestor.log
ingestorJar=$ingestorDir/search-api-all-1.0.jar

java \\
  -Dingestor.log=\$log \\
  -Dingestor.tenant=$tenant \\
  -Dingestor.app=$app \\
  -Dingestor.token=$token \\
  -Dingestor.searchclick_count=listing_view_count \\
  -Dingestor.transaction_count=listing_sold_count \\
  -Dingestor.ctc_rate=listing_conv_rate \\
  -jar \$ingestorJar
EOF
