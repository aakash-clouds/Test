#!/bin/bash

if [ "$#" -ne 2 ]; then
  echo "Usage: upconfig.sh <env> <confname>"
  exit 1
fi

env=$1
confname=$2

. configs/$env.sh

scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ops_scripts_dir="$(dirname $scriptdir)"
code_dir="$(dirname $ops_scripts_dir)"
zkclient_home=$code_dir/searchstax-client/solr-5/scripts

customer_configs=$code_dir/customer-configs/$customer/conf
confdir="$customer_configs/$env/$confname"

pushd $zkclient_home
./zkcli.sh -zkhost $zkhost -cmd upconfig -confdir $confdir -confname $confname
popd
