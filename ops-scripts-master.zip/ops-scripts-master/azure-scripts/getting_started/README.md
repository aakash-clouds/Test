# Getting started with Azure using python SDK
The motive of this sample script is to familiarize the techops team about how things move in Azure. 

## Running your first Azure python script

* Installing `azure`  
```
pip install -r requirements.txt
```
Make sure you have your Azure username, password and subscription ID handy before trying to run any of the operations.

* Let's go!

The underlying examples use subscription id of Searchstax's `DEV-pay-as-you-go` subscription.

1. Getting all resource groups for a given subscription ID
```
$ python getting_started/first_steps.py -u <username> -p <password> -s <subscription-id> --showResourceGroups
Sr 	Name                              	           Location      
======================================================================
1	RahulTestingAutomationAccount     	         centralindia    
2	SearchStax-eastus                 	            eastus       
3	ss202941-eastus                   	            eastus       
4	ss229299-eastus                   	            eastus       
5	ss512864-eastus                   	            eastus  
```
2. Getting all resources within a resource group
```
$ python getting_started/first_steps.py -u <username> -p <password> -s <subscription_id> -rg ss202941-eastus --listResources
Sr 	Name                              	        Resource Type
==========================================================================================
1	ss202941-1-data                   	     Microsoft.Compute/disks
2	ss202941-1-os                     	     Microsoft.Compute/disks
3	ss202941-1                        	     Microsoft.Compute/virtualMachines
4	ss202941-1-nic                    	     Microsoft.Network/networkInterfaces
5	ss202941-nsg                      	     Microsoft.Network/networkSecurityGroups
6	ss202941-1                        	     Microsoft.Network/publicIPAddresses
```

3. Getting all resources in all resource groups under a given subscription
```
$python getting_started/first_steps.py -u <username> -p <password> -s <subscription-id> --showResources
Sr 	Name                                                  	              Resource Type
========================================================================================================================
1	RahulTesting                                          	     Microsoft.Automation/automationAccounts
2	RahulTesting/AzureAutomationTutorial                  	     Microsoft.Automation/automationAccounts/runbooks
3	RahulTesting/AzureAutomationTutorialPython2           	     Microsoft.Automation/automationAccounts/runbooks
4	RahulTesting/AzureAutomationTutorialScript            	     Microsoft.Automation/automationAccounts/runbooks
5	RahulTesting/AzureClassicAutomationTutorial           	     Microsoft.Automation/automationAccounts/runbooks
6	RahulTesting/AzureClassicAutomationTutorialScript     	     Microsoft.Automation/automationAccounts/runbooks
7	RahulTesting/Searchstax-python                        	     Microsoft.Automation/automationAccounts/runbooks
8	VNGateway-ip                                          	     Microsoft.Network/publicIPAddresses
9	eastus                                                	     Microsoft.Network/virtualNetworks
10	ssbackupvault                                         	     Microsoft.RecoveryServices/vaults
11	testsearchstax                                        	     Microsoft.Storage/storageAccounts
12	ss202941-1-data                                       	        Microsoft.Compute/disks    
13	ss202941-1-os                                         	        Microsoft.Compute/disks    
14	ss202941-1                                            	     Microsoft.Compute/virtualMachines
15	ss202941-1-nic                                        	     Microsoft.Network/networkInterfaces
16	ss202941-nsg                                          	     Microsoft.Network/networkSecurityGroups
17	ss202941-1                                            	     Microsoft.Network/publicIPAddresses
18	ss229299-1-data                                       	        Microsoft.Compute/disks    
19	ss229299-1-os                                         	        Microsoft.Compute/disks    
20	ss229299-1                                            	     Microsoft.Compute/virtualMachines
21	ss229299-1-nic                                        	     Microsoft.Network/networkInterfaces
22	ss229299-nsg                                          	     Microsoft.Network/networkSecurityGroups
23	ss229299-1                                            	     Microsoft.Network/publicIPAddresses
24	ss512864-1-data                                       	        Microsoft.Compute/disks    
25	ss512864-1-os                                         	        Microsoft.Compute/disks    
26	ss512864-1                                            	     Microsoft.Compute/virtualMachines
27	ss512864-1-nic                                        	     Microsoft.Network/networkInterfaces
28	ss512864-nsg                                          	     Microsoft.Network/networkSecurityGroups
29	ss512864-1                                            	     Microsoft.Network/publicIPAddresses
```
