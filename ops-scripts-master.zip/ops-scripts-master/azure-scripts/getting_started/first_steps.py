import argparse

from azure.common.credentials import UserPassCredentials
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.resource.resources import ResourceManagementClient
from azure.mgmt.network import NetworkManagementClient


class AzureForOperations(object):
    def __init__(self, username, password, subscription_id):
        self.username = username
        self.password = password
        self.subscription_id = subscription_id

    def _user_credentials(self):
        return UserPassCredentials(username=self.username,
                                   password=self.password)

    def _resource_client(self):
        return ResourceManagementClient(credentials=self._user_credentials(),
                                        subscription_id=self.subscription_id)

    def _compute_client(self):
        return ComputeManagementClient(credentials=self._user_credentials(),
                                       subscription_id=self.subscription_id)

    def _network_client(self):
        return NetworkManagementClient(credentials=self._user_credentials(),
                                       subscription_id=self.subscription_id)

    def get_all_resource_groups(self):
        resource_client = self._resource_client()
        print('{:3}{}{:30}{:^10}{:^20}'.format('Sr', '\t', 'Name', '\t', 'Location'))
        print('{:=<70s}'.format(''))

        for i, j in enumerate(resource_client.resource_groups.list(), 1):
            print('{}{}{:30}{:^10}{:^20}'.format(i, '\t', j.name, '\t', j.location))

    def get_all_resources_within_resource_group(self, resource_group):
        resource_client = self._resource_client()
        print('{:3}{}{:30}{:^10}{:^20}'.format('Sr', '\t', 'Name', '\t', 'Resource Type'))
        print('{:=<90s}'.format(''))

        for i, j in enumerate(resource_client.resources.list_by_resource_group(resource_group), 1):
            print('{}{}{:30}{:^10}{:^20}'.format(i, '\t', j.name, '\t', j.type))

    def get_all_resources(self):
        resource_client = self._resource_client()
        print('{:3}{}{:50}{:^10}{:^30}'.format('Sr', '\t', 'Name', '\t', 'Resource Type'))
        print('{:=<120s}'.format(''))

        for i, j in enumerate(resource_client.resources.list(), 1):
            print('{}{}{:50}{:^10}{:^30}'.format(i, '\t', j.name, '\t', j.type))

    def get_all_info_within_resource(self):
        compute_client = self._compute_client()
        network_client = self._network_client()

        print('{:3}{}{:10}{:^10}{:^10}{:^10}{:^10}{:^10}{:^10}'.format(
            'Sn', '\t', 'Tenant', '\t', 'Deployment', '\t', 'SS_ID', '\t', 'Public IP'))
        print('{:=<90s}'.format(''))

        for i, j in enumerate(compute_client.virtual_machines.list_all(), 1):
            try:
                pub_ip = network_client.public_ip_addresses.get('{}-{}'.format(j.name.split('-')[0], j.location),
                                                       j.name)
                print i, '\t', j.tags.get('Tenant', 'None'), '\t', j.tags.get('Deployment_name', 'None'), '\t',\
                    j.name, '\t', pub_ip.ip_address
            except Exception as ex:
                pass

if __name__ == '__main__':
    # create parser
    parser = argparse.ArgumentParser(description='TechOps Auditing')

    # add arguments
    parser.add_argument(
        '-u', dest='username', action='store', help='Azure Username'
    )
    parser.add_argument(
        '-p', dest='password', action='store', help='Azure Password'
    )
    parser.add_argument(
        '-s', dest='subscription_id', action='store', help='Azure Subscription ID'
    )
    parser.add_argument(
        '-rg', dest='rg', action='store', help='Resource Group'
    )

    # Flags
    parser.add_argument('--showResourceGroups', action='store_true')
    parser.add_argument('--showResources', action='store_true')
    parser.add_argument('--listResources', action='store_true')
    parser.add_argument('--listTags', action='store_true')
    parser.add_argument('--showResourceInfo', action='store_true')

    args = parser.parse_args()

    client = AzureForOperations(args.username, args.password, args.subscription_id)

    if args.showResourceGroups:
        client.get_all_resource_groups()

    if args.showResources:
        client.get_all_resources()

    if args.rg and args.listResources:
        client.get_all_resources_within_resource_group(args.rg)

    if args.showResourceInfo:
        client.get_all_info_within_resource()
