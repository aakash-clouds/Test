import subprocess
import json
import argparse
import logging
import datetime
from termcolor import colored
from django.core.mail import send_mail

logger = logging.getLogger('watcher')

logging.basicConfig(format='%(asctime)s %(message)s',
                    datefmt='%m/%d/%Y %I:%M:%S %p',
                    filename='/tmp/watcher.log',
                    level=logging.DEBUG)


def run(target_resource_group,
        target_name,
        target_type,
        storage_account,
        storage_container):
    try:
        start = datetime.datetime.utcnow()
        logger.debug('Watcher Initiated at %s' % str(start))

        process = subprocess.check_output("az network watcher troubleshooting start \
--resource-group {target_resource_group} \
--resource {target_name} \
--resource-type {target_type} \
--storage-account {storage_account} \
--storage-path https://{storage_account}.blob.core.windows.net/{storage_container}".format(
            target_resource_group=target_resource_group,
            target_name=target_name,
            target_type=target_type,
            storage_account=storage_account,
            storage_container=storage_container,
        ),
            shell=True,
            stderr=subprocess.STDOUT)

        output = json.loads(process)
        result = output['code']
        message = 'The status of %s inside %s is %s' % (
                target_name,
                target_resource_group,
                result)

        if result == 'Healthy':
            logger.debug(msg=colored(message, color='green'))
        else:
            logger.error(msg=colored(message, color='red'))

        time_diff = datetime.datetime.utcnow() - start
        logger.debug('Watcher ran for %s seconds!' % str(time_diff.total_seconds()))

    except subprocess.CalledProcessError as e:
        logger.error(colored(e, color='red'))
        raise e


# create parser
parser = argparse.ArgumentParser(description='VPN Connectivity monitoring')

# add arguments
parser.add_argument(
    '--target-rg', dest='target_resource_group', action='store',
    help='Resource Group of VPN Gateway or VPN Connection'
)
parser.add_argument(
    '--target-name', dest='target_name', action='store',
    help='Name of the target'
)
parser.add_argument(
    '--target-type', dest='target_type', action='store',
    help='vpnConnection OR vpnGateway'
)
parser.add_argument(
    '--storage-account', dest='storage_account', action='store',
    help='Storage Account to store logs, should be in the same Resource group!'
)
parser.add_argument(
    '--storage-container', dest='storage_container', action='store',
    help='Storage Container, should be in the same Resource Group as Target Resource Group'
)

args = parser.parse_args()

if not args.target_resource_group or \
        not args.target_name or \
        not args.target_type or \
        not args.storage_account or \
        not args.storage_container:
    raise AttributeError('Improper supply of Arguments!')
else:
    # only 1 instance of azure network troubleshooting allowed
    try:
        run(
            target_resource_group=args.target_resource_group,
            target_name=args.target_name,
            target_type=args.target_type,
            storage_account=args.storage_account,
            storage_container=args.storage_container,
        )
    except Exception as e:
        html_message = """
        Hi There!<br>

        There was an error detected while running network connectivity over <b>{}</b> running inside the <b>{}</b>
        resource group.<br>

        <br><b>Error</b><br>
        <i>{error}</i>
        <br><br>
        Please investigate immediately.
        <br>
        If you need support from SearchStax, please reach us on our support portal <https://support.searchstax.com/> or via support@searchstax.com <support@searchstax.com>
        Best Regards, <br>
        The SearchStax Bots        
                    """.format(
            args.target_name,
            args.target_resource_group,
            error=e
        )

        send_mail(message="Failure in Network Monitoring",
                  from_email="no-reply@searchstax.co",
                  recipient_list=["tech-ops@searchstax.co"],
                  fail_silently=False,
                  html_message=html_message,
                  subject="Error detected in VPN Monitoring on %s" % (
                      args.target_name)
        )
