"""
Generic DNS Failover Script
---------------------------

Pre-Requisites:
--------------
* Trigger IDs for prod and DR deployment nodes from Zabbix
* Create a role for AWS SES by the name of the customer and attach 2 policies to it
    - ses send mail policy
    - route53 list and write access
* Create a CNAME for the environment, suggested naming convention is customer.searchstax.com
* Get the record zone ID and record set ID for this domain
* Create a role in .aws/credentials file with the following values
[customer]
aws_access_key_id = TBD
aws_secret_access_key = TBD

Logic Followed:
---------------
* check zabbix triggers for prod
* if more than 1 machine unhealthy, check triggers for dr
* if prod unhealthy and dr unhealthy send alert
* if prod unhealthy and dr healthy switch to dr and send alert
*. if prod healthy again, send alert

"""

import json
import traceback

import boto3
import requests

# this needs to be changed to searchstax.com
FROM_EMAIL = 'tech-ops@measuredsearch.com'
TO_EMAIL = 'tech-ops@measuredsearch.com'

ZABBIX_USER = 'USER'
ZABBIX_PASSWORD = 'PASS'
ZABBIX_URL = 'http://52.4.168.202/zabbix/api_jsonrpc.php'

# depends upon the number of deployment nodes
TRIGGERS_PROD = ['TBD']
TRIGGERS_DR = ['TBD']

RECORD_ZONE_ID = 'TBD'
RECORD_SET = 'TBD.searchstax.com'
PROD_VALUE = 'TBD.searchstax.com'
DR_VALUE = 'TBD.searchstax.com'

STATE_FILE = '/tmp/genericdnsfailover.state'


def send_message(level, message, subject=''):
    """
    Send email using SES
    """
    session = boto3.Session(profile_name='TBD', region_name='us-east-1')
    client = session.client('ses')
    client.send_email(
        Source=FROM_EMAIL,
        Destination={'ToAddresses': [TO_EMAIL]},
        Message={
            'Subject': {'Data': '{} TBD FAILOVER {}'.format(level, subject)},
            'Body': {'Text': {'Data': message}}
        }
    )
    print(message)


def send_warning(message, subject=''):
    """
    WARNING message shortcut
    """
    send_message('WARNING', message, subject)


def send_info(message, subject=''):
    """
    INFO message shortcut
    """
    send_message('INFO', message, subject)


def send_error(message, subject=''):
    """
    ERROR message shortcut
    """
    send_message('ERROR', message, subject)


def zabbix_triggers():
    """
    Read Zabbix triggers
    """
    headers = {"content-type": "application/json"}

    # perform login
    response = requests.get(
        ZABBIX_URL,
        data=json.dumps({
            'method': 'user.login',
            'params': {'user': ZABBIX_USER, 'password': ZABBIX_PASSWORD},
            'jsonrpc': '2.0',
            'id': 1
        }),
        headers=headers
    ).json()
    if 'result' in response:
        token = response['result']
    else:
        raise Exception("Zabbix Login Failed")

    # read trigger statuses
    payload = {
        'method': 'trigger.get',
        'params': {'triggerids': TRIGGERS_PROD + TRIGGERS_DR},
        'jsonrpc': '2.0',
        'id': 2,
        'auth': token
    }

    response = requests.get(
        ZABBIX_URL,
        data=json.dumps(payload),
        headers=headers
    ).json()
    if 'result' in response:
        return response['result']
    else:
        raise Exception("Zabbix trigger.get failed")


def read_state(key=None):
    """
    Read state from state file
    """
    try:
        data = json.loads(open(STATE_FILE).read())
        if key:
            return data[key]
        else:
            return data
    except IOError:
        return None


def write_state(key, val):
    """
    Write state to state file
    """
    data = read_state()
    if not data:
        data = {}
    data[key] = val
    with open(STATE_FILE, 'w') as fd:
        fd.write(json.dumps(data))
    return True


def perform_failover():
    """
    Change CNAME value
    """
    session = boto3.Session(profile_name='TBD', region_name='us-east-1')
    client = session.client('route53')
    response = client.list_resource_record_sets(
        HostedZoneId=RECORD_ZONE_ID,
        StartRecordName=RECORD_SET,
        StartRecordType='CNAME'
    )
    record_set = response['ResourceRecordSets'][0]['ResourceRecords'][0]
    if record_set['Value'] == PROD_VALUE:
        response = client.change_resource_record_sets(
            HostedZoneId=RECORD_ZONE_ID,
            ChangeBatch={
                'Changes': [{
                    'Action': 'UPSERT',
                    'ResourceRecordSet': {
                        'Name': RECORD_SET,
                        'Type': 'CNAME',
                        'ResourceRecords': [{'Value': DR_VALUE}],
                        'TTL': 180,
                    }
                }]
            }
        )
        if response['ChangeInfo']['Status'] == 'PENDING':
            send_info(message='Failover performed, DNS record changed to {}'.format(DR_VALUE))
        else:
            send_error(
                message='Modifying DNS record returned {}'.format(response['ChangeInfo']['Status'])
            )


def main():
    """
    Main execution loop
    """
    triggers = zabbix_triggers()
    if len(triggers) != len(TRIGGERS_PROD + TRIGGERS_DR):
        raise Exception("number of retrieved triggers doesn't match number of nodes")

    prods = 0
    drs = 0

    for trigger in triggers:
        if trigger['triggerid'] in TRIGGERS_PROD and trigger['value'] == '0':
            prods += 1
        if trigger['triggerid'] in TRIGGERS_DR and trigger['value'] == '0':
            drs += 1
    # process trigger results
    previous_triggers = read_state('triggers')

    # prod deployment trigger count
    if prods >= int('TBD'):
        if not previous_triggers:
            pass
        else:
            if previous_triggers[0] >= int('TBD'):
                pass
            else:
                send_warning(
                    message='Primary cluster recovered, proceed with manual switch back',
                    subject='Manual switchback required'
                )
    else:

        # dr deployment trigger count
        if drs >= int('TBD'):
            write_state('triggers', [prods, drs])
            perform_failover()
        else:
            send_error(
                message='Both Primary and DR are DOWN. Proceed manually',
                subject='Both Prod and DR are DOWN'
            )
    write_state('triggers', [prods, drs])


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        send_error(traceback.print_exc())
