# List of customer scripts
* Watcher script for VNET Gateway and VPN Connectivity monitoring
* DNS Failover script using DataDog(alpha release)
* DNS failover script using Zabbix(phased out)

## Watcher.py
#### Prerequisistes
* Storage account along with a container in the resource group that has target he gateway or connection
* az cli which is can be downloaded using `curl -L https://aka.ms/InstallAzureCli | bash`
* Please make sure to login into az using `az login --username <username> --password <password>`
* Make sure that a watcher exist in the region you are trying to run this script via
`az network watcher configure --resource-group $RESOURCE_GROUP --locations $REGION --enabled`

#### From where to run?
* Currently it needs django email settings to be able to send mails. This can be achieved via
```
1. Login to QA Jumphost
2. Login to QA Jobserver
3. sudo su - searchstax
4. source /opt/searchstax/env/bin/activate
5. cd /opt/searchstax/app/searchstax
6. export DJANGO_SETTINGS_MODULE=searchstax.settings
```

* if we can have this dependancy removed (ie if we start to use postfix for sending mails from the server), we can basically run this script from anywhere from the server.

#### Testing watcher.py for a `vpnConnection`
```
# run the script
$python watcher.py --target-rg GatewayTestingRG \
--target-name GatewayTestVNET-to-testgateway \
--target-type vpnConnection \
--storage-account gatewaytest2018 \
--storage-container networkwatcher

# check logs!
$ tail -f /tmp/watcher.log 
04/18/2018 08:20:08 PM Watcher Initiated at 2018-04-18 14:50:08.647758
04/18/2018 08:24:00 PM The status of GatewayTestVNET-to-testgateway inside GatewayTestingRG is Healthy
04/18/2018 08:24:00 PM Watcher ran for 231.631242 seconds!

```
#### Testing watcher.py for a `vnetGateway`
```
# run the script
$ python watcher.py --target-rg SearchStax-eastus \
--target-name testgateway \
--target-type vnetGateway \
--storage-account testsearchstax \
--storage-container networkwatcher

# check logs!
# Simulating the event logs for a VPN Gateway Failure, an email would be sent.

$ tail -f /tmp/watcher.log
04/26/2018 07:59:47 AM Watcher Initiated at 2018-04-26 07:59:47.388093
04/26/2018 07:59:48 AM Command 'az network watcher troubleshooting start --resource-group SearchStax-eastus --resource testgateway --resource-type vpnGateway --storage-account testsearchstax --storage-path https://testsearchstax.blob.core.windows.net/networkwatcher' returned non-zero exit status 2
04/26/2018 07:59:49 AM Using access key provided by client.
04/26/2018 07:59:49 AM Using secret key provided by client.
04/26/2018 07:59:49 AM Method: POST
04/26/2018 07:59:49 AM Path: /
04/26/2018 07:59:49 AM Data: Action=GetSendQuota
04/26/2018 07:59:49 AM Headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
04/26/2018 07:59:49 AM Host: email.us-east-1.amazonaws.com
04/26/2018 07:59:49 AM Port: 443
04/26/2018 07:59:49 AM Params: {}
04/26/2018 07:59:49 AM establishing HTTPS connection: host=email.us-east-1.amazonaws.com, kwargs={'port': 443, 'timeout': 70}
04/26/2018 07:59:49 AM Token: None
04/26/2018 07:59:49 AM Final headers: {'Content-Length': '19', 'User-Agent': 'Boto/2.45.0 Python/2.7.12 Linux/4.4.0-1055-aws', 'Host': 'email.us-east-1.amazonaws.com', 'Date': 'Thu, 26 Apr 2018 07:59:49 GMT', 'X-Amzn-Authorization': u'AWS3-HTTPS AWSAccessKeyId=AKIAJNFTRLZ535AHCFSA,Algorithm=HmacSHA256,Signature=3KwvQ1OPn/08d0Jt3AraGQHH+4z6y5Gh+JsCzIbL8xE=', 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
04/26/2018 07:59:49 AM wrapping ssl socket; CA certificate file=/opt/searchstax/env/local/lib/python2.7/site-packages/boto/cacerts/cacerts.txt
04/26/2018 07:59:49 AM validating server certificate: hostname=email.us-east-1.amazonaws.com, certificate hosts=['email.us-east-1.amazonaws.com', 'email.amazonaws.com']
04/26/2018 07:59:49 AM Response headers: [('x-amzn-requestid', 'cb208c19-4927-11e8-b202-d33133dc2148'), ('date', 'Thu, 26 Apr 2018 07:59:49 GMT'), ('content-length', '370'), ('content-type', 'text/xml')]
04/26/2018 07:59:49 AM send_messages.throttle rate_limit='1.0'
04/26/2018 07:59:49 AM Method: POST
04/26/2018 07:59:49 AM Path: /
04/26/2018 07:59:49 AM Data: Action=SendRawEmail&Source=dev%40searchstax.co&Destinations.member.1=tech-ops%40searchstax.co&RawMessage.Data=Q29udGVudC1UeXBlOiBtdWx0aXBhcnQvYWx0ZXJuYXRpdmU7CiBib3VuZGFyeT0iPT09PT09PT09PT09PT09MTYzMTc4MTQwNTgwNTM1NTkyOD09IgpNSU1FLVZlcnNpb246IDEuMApTdWJqZWN0OiBFcnJvciBkZXRlY3RlZCBpbiBOZXR3b3JrIE1vbml0b3Jpbmcgb24gdGVzdGdhdGV3YXkgaW5zaWRlCiBTZWFyY2hTdGF4LWVhc3R1cyByZXNvdXJjZSBncm91cCEKRnJvbTogZGV2QHNlYXJjaHN0YXguY28KVG86IHRlY2gtb3BzQHNlYXJjaHN0YXguY28KRGF0ZTogVGh1LCAyNiBBcHIgMjAxOCAwNzo1OTo0OSAtMDAwMApNZXNzYWdlLUlEOiA8MjAxODA0MjYwNzU5NDkuMjE1NTMuODM0ODZAbG9jYWxob3N0PgoKLS09PT09PT09PT09PT09PT0xNjMxNzgxNDA1ODA1MzU1OTI4PT0KQ29udGVudC1UeXBlOiB0ZXh0L3BsYWluOyBjaGFyc2V0PSJ1dGYtOCIKTUlNRS1WZXJzaW9uOiAxLjAKQ29udGVudC1UcmFuc2Zlci1FbmNvZGluZzogN2JpdAoKRmFpbHVyZSBpbiBOZXR3b3JrIE1vbml0b3JpbmcKLS09PT09PT09PT09PT09PT0xNjMxNzgxNDA1ODA1MzU1OTI4PT0KQ29udGVudC1UeXBlOiB0ZXh0L2h0bWw7IGNoYXJzZXQ9InV0Zi04IgpNSU1FLVZlcnNpb246IDEuMApDb250ZW50LVRyYW5zZmVyLUVuY29kaW5nOiA3Yml0CgoKICAgICAgICBIaSBUaGVyZSE8YnI%2BCgogICAgICAgIFRoZXJlIHdhcyBhbiBlcnJvciBkZXRlY3RlZCBmb3IgYSA8Yj52cG5HYXRld2F5PC9iPiB3aGlsZSBydW5uaW5nIG5ldHdvcmsgdHJvdWJsZXNob290aW5nIG92ZXIgPGI%2BdGVzdGdhdGV3YXk8L2I%2BIHJ1bm5pbmcgaW5zaWRlIHRoZSA8Yj5TZWFyY2hTdGF4LWVhc3R1czwvYj4KICAgICAgICByZXNvdXJjZSBncm91cC48YnI%2BCgogICAgICAgIDxicj48Yj5FcnJvcjwvYj48YnI%2BCiAgICAgICAgPGk%2BQ29tbWFuZCAnYXogbmV0d29yayB3YXRjaGVyIHRyb3VibGVzaG9vdGluZyBzdGFydCAtLXJlc291cmNlLWdyb3VwIFNlYXJjaFN0YXgtZWFzdHVzIC0tcmVzb3VyY2UgdGVzdGdhdGV3YXkgLS1yZXNvdXJjZS10eXBlIHZwbkdhdGV3YXkgLS1zdG9yYWdlLWFjY291bnQgdGVzdHNlYXJjaHN0YXggLS1zdG9yYWdlLXBhdGggaHR0cHM6Ly90ZXN0c2VhcmNoc3RheC5ibG9iLmNvcmUud2luZG93cy5uZXQvbmV0d29ya3dhdGNoZXInIHJldHVybmVkIG5vbi16ZXJvIGV4aXQgc3RhdHVzIDI8L2k%2BCiAgICAgICAgPGJyPjxicj4KICAgICAgICBQbGVhc2UgaW52ZXN0aWdhdGUgaW1tZWRpYXRlbHkuCiAgICAgICAgPGJyPgogICAgICAgIFJlZyw8YnI%2BCiAgICAgICAgTmV0d29yayBNb25pdG9yaW5nIFNjcmlwdCAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgCi0tPT09PT09PT09PT09PT09MTYzMTc4MTQwNTgwNTM1NTkyOD09LS0K
04/26/2018 07:59:49 AM Headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
04/26/2018 07:59:49 AM Host: email.us-east-1.amazonaws.com
04/26/2018 07:59:49 AM Port: 443
04/26/2018 07:59:49 AM Params: {}
04/26/2018 07:59:49 AM Token: None
04/26/2018 07:59:49 AM Final headers: {'Content-Length': '1954', 'User-Agent': 'Boto/2.45.0 Python/2.7.12 Linux/4.4.0-1055-aws', 'Host': 'email.us-east-1.amazonaws.com', 'Date': 'Thu, 26 Apr 2018 07:59:49 GMT', 'X-Amzn-Authorization': u'AWS3-HTTPS AWSAccessKeyId=AKIAJNFTRLZ535AHCFSA,Algorithm=HmacSHA256,Signature=3KwvQ1OPn/08d0Jt3AraGQHH+4z6y5Gh+JsCzIbL8xE=', 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
04/26/2018 07:59:49 AM Response headers: [('x-amzn-requestid', 'cb245cac-4927-11e8-b202-d33133dc2148'), ('date', 'Thu, 26 Apr 2018 07:59:49 GMT'), ('content-length', '338'), ('content-type', 'text/xml')]
04/26/2018 07:59:49 AM send_messages.sent from='dev@searchstax.co' recipients='tech-ops@searchstax.co' message_id='0100016300f72f34-203b80dc-d8dd-4a95-a2c4-f199ccb375cc-000000' request_id='cb245cac-4927-11e8-b202-d33133dc2148'
```

## VPN Connectivity Script(phased out)

```
# Example
$ python vpn_connectivity.py \
--watcherRG ss202941-eastus \
--loc eastus \
--targetRG SearchStax-eastus \
--targetName testgateway
```
