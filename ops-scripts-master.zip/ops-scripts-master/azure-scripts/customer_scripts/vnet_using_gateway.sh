# Script to connect two VNETs sitting in different tenants using VPN Gteway and Connections
# Usage: sh vnet_using_gateway USERNAME PASSWORD
# NOTE: This still needs to be tested anyways!


# Check if azcli exists
AZCLI_VERSION=$(az --version | head -1)
echo $AZCLI_VERSION

if [ "$AZCLI_VERSION" = " " ]; then
# Modify resource list
AZ_REPO=$(lsb_release -cs)
echo "deb [arch=amd64] https://packages.microsoft.com/repos/azure-cli/ $AZ_REPO main" | sudo tee /etc/apt/sources.list.d/azure-cli.list

# Install ms signing key
curl -L https://packages.microsoft.com/keys/microsoft.asc | sudo apt-key add -

# Install the azcli
sudo apt-get install apt-transport-https
sudo apt-get update && sudo apt-get install azure-cli

else
    printf "Azure cli already exists!\n"
fi

printf "Trying to login to azure....\n"
az login -u $1 -p $2

printf "Source ResourceGroup: "
read SOURCE_RG

printf "Source Azure Region: "
read REGION

printf "Source VNET name: "
read SOURCE_VNET

printf "Source VNET Resource ID: "
read SOURCE_VNET_ID

printf "Please provide the gateway subnet IP range (eg 10.52.255.0/27 ): "
read GATEWAY_IP

# Add the gateway subnet.
az network vnet subnet create --vnet-name $SOURCE_VNET -n GatewaySubnet -g $SOURCE_RG --address-prefix $GATEWAY_IP

# Request a public IP address.
az network public-ip create -n VNETGatewayIP -g $SOURCE_RG --allocation-method Dynamic

# Create the gateway
printf "Creating VNET Gateway, please wait as it may take up to 45 mins to provision!\n"
az network vnet-gateway create -n VNETGateway \
-l $REGION \
--public-ip-address VNETGatewayIP \
-g $SOURCE_RG \
--vnet $SOURCE_VNET \
--gateway-type Vpn \
--sku VpnGw1 \
--vpn-type RouteBased

printf "Proceeding to create a Tunnel\n"

printf "Target VNET name: "
read TARGET_VNET

printf "Target VNET resource ID: "
read TARGET_VNET_ID

printf "Specify the shared key, should be same for both the gateways!"
read SHARED_KEY

printf "Please provide the name of the connection: "
read CONNECTION 

# Create the tunnel
az network vpn-connection create -n $CONNECTION \
-g $SOURCE_RG \
--vnet-gateway1 $SOURCE_VNET_ID \
-l $REGION \
--shared-key $SHARED_KEY \
--vnet-gateway2 $TARGET_VNET_ID

# Test connection
az network vpn-connection show --name $CONNECTION --resource-group $SOURCE_RG
