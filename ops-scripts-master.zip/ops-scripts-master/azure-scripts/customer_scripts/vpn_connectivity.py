import argparse

from constants import (
    AZURE_SUBSCRIPTION_ID,
    AZURE_PASSWORD,
    AZURE_USERNAME,
    STORAGE_ACCOUNT,
    CONTAINER
)

from azure.common.credentials import UserPassCredentials
from azure.mgmt.network import NetworkManagementClient

from azure.mgmt.network.v2017_11_01.models import (
    NetworkWatcher,
    TroubleshootingParameters
)

from django.core.mail import send_mail

# create credentials
user_credentials = UserPassCredentials(username=AZURE_USERNAME,
                                       password=AZURE_PASSWORD)

# create network client
network_client = NetworkManagementClient(credentials=user_credentials,
                                         subscription_id=AZURE_SUBSCRIPTION_ID)


def _get_network_watcher(resource_group, location):
    network_watcher = "Watchman-%s" % location

    try:
        return network_client.network_watchers.get(
            network_watcher_name=network_watcher,
            resource_group_name=resource_group
        )
    except Exception:
        return network_client.network_watchers.create_or_update(
            network_watcher_name=network_watcher,
            resource_group_name=resource_group,
            parameters=NetworkWatcher(location=location)
        )


def start_troubleshooting(watcher_resource_group,
                          watcher_location,
                          target_resource_group,
                          target_resource_name):

    watchman = _get_network_watcher(watcher_resource_group,
                                    watcher_location)
    # create network troubleshooting
    return network_client.network_watchers.get_troubleshooting(
        network_watcher_name=watchman.name,
        resource_group_name=watcher_resource_group,
        parameters=TroubleshootingParameters(
            target_resource_id="/subscriptions/%s/resourceGroups/%s/providers/\
            Microsoft.Network/virtualNetworkGateways/%s/" % (AZURE_SUBSCRIPTION_ID,
                                                             target_resource_group,
                                                             target_resource_name),
            storage_id="/subscriptions/%s/%s" % (AZURE_SUBSCRIPTION_ID, STORAGE_ACCOUNT),
            storage_path="https://%s.blob.core.windows.net/%s" % (STORAGE_ACCOUNT, CONTAINER)
        )
    )


if __name__ == "__main__":
    # create parser
    parser = argparse.ArgumentParser(description='VPN Connectivity monitoring')

    # add arguments
    parser.add_argument(
        '--watcherRG', dest='watcher_resource_group', action='store', help='Network Watcher resource group'
    )
    parser.add_argument(
        '--loc', dest='watcher_location', action='store', help='Network Watcher location'
    )
    parser.add_argument(
        '--targetRG', dest='target_resource_group', action='store', help='Target Resource Group'
    )
    parser.add_argument(
        '--targetName', dest='target_resource_name', action='store', help='Target Resource Name'
    )

    args = parser.parse_args()

    if not args.watcher_resource_group or not args.watcher_location or \
            not args.target_resource_group or not args.target_resource_name:
        raise AttributeError("Incomplete supply of Arguments! See help")

    else:
        try:
            start_troubleshooting(watcher_resource_group=args.watcher_resource_group,
                                  watcher_location=args.watcher_location,
                                  target_resource_group=args.target_resource_group,
                                  target_resource_name=args.target_resource_name)
        except Exception as e:
            print(e)
            html_message = """
Hi There!<br>

There was an error detected while running network troubleshooting over <b>{}</b> running inside the <b>{}</b>
resource group.<br>

<br><b>Error</b><br>
<i>{error}</i>
<br><br>
Please investigate immediately.
<br>
Reg,<br>
Network Monitoring Script        
            """.format(args.target_resource_name, args.target_resource_group, error=e)

            send_mail(message="Failure in setting up VPN Monitoring",
                      from_email="dev@searchstax.co",
                      recipient_list=["tech-ops@searchstax.co"],
                      fail_silently=False,
                      html_message=html_message,
                      subject="Error detected in VPN Monitoring on %s inside %s resource group!" % (
                          args.target_resource_name,
                          args.target_resource_group)
                      )
