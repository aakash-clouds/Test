# This is an alpha release of this DNS failover functionality.
# It is currently very similar to the one we have in the LendLease.
# In case of failure , this will open a DataDog request.

import boto3
from datadog import api, initialize, statsd

CHECK = 'solr.can_connect'
HOST = 'changeme'

APP_KEY = 'APP KEY'
API_KEY = 'API KEY'
AWS_ACCESS_KEY_ID = ''
AWS_SECRET_KEY = ''

SOLR_PROD_MONITORS = [5040122, 5040124, 5040125]
SOLR_DR_MONITORS = [5070772, 5070779, 5070786]

RECORD_ZONE_ID = 'Z3JEOOTS4X31YO'
RECORD_SET = 'customer.searchstax.com'
PROD_VALUE = 'prod.searchstax.com'
DR_VALUE = 'dr.searchstax.com'

FROM_EMAIL = 'tech-ops@measuredsearch.com'
TO_EMAIL = 'tech-ops@measuredsearch.com'

options = {
    'api_key': API_KEY,
    'app_key': APP_KEY
}

initialize(**options)

solr_prod_status = [api.Monitor.get(i)['overall_state'] for i in SOLR_PROD_MONITORS]
solr_dr_status = [api.Monitor.get(i)['overall_state'] for i in SOLR_DR_MONITORS]

# switch only when solr status in prod is critical and dr_servers health is OK
if solr_prod_status.count('Alert') >= 2 and \
        solr_dr_status.count('OK') >= 2:

    # perform DNS switching
    client = boto3.client('route53',
                          aws_access_key_id=AWS_ACCESS_KEY_ID,
                          aws_secret_access_key=AWS_SECRET_KEY)
    response = client.list_resource_record_sets(
        HostedZoneId=RECORD_ZONE_ID,
        StartRecordName=RECORD_SET,
        StartRecordType='CNAME'
    )
    record_set = response['ResourceRecordSets'][0]['ResourceRecords'][0]
    if record_set['Value'] == PROD_VALUE:
        response = client.change_resource_record_sets(
            HostedZoneId=RECORD_ZONE_ID,
            ChangeBatch={
                'Changes': [{
                    'Action': 'UPSERT',
                    'ResourceRecordSet': {
                        'Name': RECORD_SET,
                        'Type': 'CNAME',
                        'ResourceRecords': [{'Value': DR_VALUE}],
                        'TTL': 180,
                    }
                }]
            }
        )

        if response['ChangeInfo']['Status'] == 'PENDING':
            statsd.service_check(
                check_name=CHECK, 
                status=statsd.CRITICAL,
                hostname=HOST, 
                message='DNS Failover successfuly done for %s' % RECORD_SET
            )
else:
    statsd.service_check(
        check_name=CHECK, 
        status=statsd.OK,
        hostname=HOST, 
        message='DNS Failover failed for %s' % RECORD_SET
    )

