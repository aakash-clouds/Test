## Azure Disk resize utility
## ========================
##
## Usage:
## -----
##	./resize_disk rg-name vm-name datadisk-size
##
## Note:
## ----
## Volume can ONLY be increased. Downsizing disk volume is NOT allowed!! 

echo Deallocating VM $2 ...
echo 
az vm deallocate --resource-group $1 --name $2
echo
sleep 1

echo Updating disk size to $3 ...
echo 
az disk update --name  $2-data --resource-group $1 --size-gb $3
echo 
sleep 1

echo Reallocating VM ...
echo 
az vm start --resource-group $1 --name $2

RETURN_CODE=$(echo $?)
if [ -z $RETURN_CODE ];then
	echo Command execution Failed!
else
	echo Done!!
	echo Please make sure to run resize2fs on the block volume on target host.
	echo
fi
