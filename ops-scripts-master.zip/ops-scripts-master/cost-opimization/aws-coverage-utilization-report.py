import json
import subprocess
import sys

def getFactor(instanceType):
  idx = instanceType.find(".")
  capacity = instanceType[idx + 1:]
  factor = 0
  if capacity == "small":
    factor = 1
  elif capacity == "micro":
    factor = 0.5
  elif capacity == "nano":
    factor = 0.25
  elif capacity == "medium":
    factor = 2
  elif capacity == "large":
    factor = 4
  elif capacity == "xlarge":
    factor = 8
  elif capacity == "2xlarge":
    factor = 16
  elif capacity == "4xlarge":
    factor = 32
  elif capacity == "8xlarge":
    factor = 64
  return factor

def get_coverage_report(start, end):
  timeperiod = 'Start=' + start + ",End=" + end

  out = subprocess.Popen(
      ['aws', 'ce', 'get-reservation-coverage', '--time-period', timeperiod,
       '--group-by', 'Type=DIMENSION,Key=REGION'
       ],
      stdout=subprocess.PIPE,
      stderr=subprocess.STDOUT)

  stdout, stderr = out.communicate()
  # print(stdout)

  coveragejson = json.loads(stdout)
  json_doc = coveragejson["CoveragesByTime"][0]["Groups"]
  coverage_all = {}

  print("REGION\tCOVERAGE\tUTILIZATION\tComplete Coverage(Annual & Monthly)")
  for group in json_doc:
    region = group["Attributes"]["region"]
    coverage = group["Coverage"]["CoverageHours"]["CoverageHoursPercentage"]

    filter_on_region = '{"Dimensions": {"Key": "REGION", "Values": ["' + region + '"]}}'
    filter_on_tags_and_region = '{"And": [ {"Tags": {"Key": "Payment_type", "Values": ["annually", "annually ", "threeyear"]}}, ' \
                                '{"Dimensions": {"Key": "REGION", "Values": ["' + region + '"]}} ]}'

    out2 = subprocess.Popen(
        ['aws', 'ce', 'get-reservation-coverage', '--time-period', timeperiod,
         '--filter',
         filter_on_tags_and_region
         ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT)
    stdout2, stderr2 = out2.communicate()
    # print(stdout2)
    coverage_contract_json = json.loads(stdout2)
    if len(coverage_contract_json["CoveragesByTime"]) > 0:
      coverage_contract_region = \
        coverage_contract_json["CoveragesByTime"][0]["Total"]["CoverageHours"][
          "CoverageHoursPercentage"]
    else:
      coverage_contract_region = 0

    out2 = subprocess.Popen(
        ['aws', 'ce', 'get-reservation-utilization', '--time-period',
         timeperiod, "--filter", filter_on_region],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT)
    stdout2, stderr2 = out2.communicate()
    # print(stdout2)
    utilization_json = json.loads(stdout2)
    if len(utilization_json["UtilizationsByTime"]) > 0:
      utilization = utilization_json["UtilizationsByTime"][0]["Total"][
        "UtilizationPercentage"]
    else:
      utilization = 0

    print(region + "\t" + str(coverage_contract_region) + "\t" + str(
        utilization) + "\t" + str(coverage))
    coverage_all[region] = str(coverage_contract_region) + "\t" + str(
        utilization) + "\t" + str(coverage)
  return coverage_all


def get_reserved_instances(region):
  out2 = subprocess.Popen(
      ['aws', 'ec2', 'describe-reserved-instances', "--region", region,
       "--filters", "Name=state,Values=active"],
      stdout=subprocess.PIPE,
      stderr=subprocess.STDOUT)
  stdout2, stderr2 = out2.communicate()

  json_data = json.loads(stdout2)
  ris = []
  for reservation in json_data["ReservedInstances"]:
    if reservation["State"] != "active":
      continue

    instanceType = reservation["InstanceType"]
    count = reservation["InstanceCount"]
    convertible = reservation["OfferingClass"]
    scope = reservation["Scope"]
    end = reservation["End"]
    factor = getFactor(instanceType)
    normalized = factor * int(count)

    ri_info = instanceType + "\t" + str(count) + "\t" + str(
      factor) + "\t" + str(
        normalized) + "\t" + str(scope) + "\t" + str(convertible) + "\t" + str(
        end)
    ris.append(ri_info)
  ris.sort()
  return ris

def get_running_contract_instances(region):
  out2 = subprocess.Popen(
      ['aws', 'ec2', 'describe-instances', "--region", region, "--filters",
       "Name=instance-state-code,Values=16",
       "Name=tag:Payment_type,Values=annually,annually ,threeyear"],
      stdout=subprocess.PIPE,
      stderr=subprocess.STDOUT)
  stdout2, stderr2 = out2.communicate()

  # print(stdout2)
  json_data = json.loads(stdout2)
  instances = {}
  for reservation in json_data["Reservations"]:

    if len(reservation["Instances"]) > 0:
      for instance in reservation["Instances"]:
        type = instance["InstanceType"]
        if type in instances:
          instances[type] = instances[type] + 1
        else:
          instances[type] = 1
  return instances

def get_running_instances(region):
  out2 = subprocess.Popen(
      ['aws', 'ec2', 'describe-instances', "--region", region, "--filters",
       "Name=instance-state-code,Values=16"],
      stdout=subprocess.PIPE,
      stderr=subprocess.STDOUT)
  stdout2, stderr2 = out2.communicate()

  json_data = json.loads(stdout2)
  instances = {}
  for reservation in json_data["Reservations"]:

    if len(reservation["Instances"]) > 0:
      for instance in reservation["Instances"]:
        type = instance["InstanceType"]
        if type in instances:
          instances[type] = instances[type] + 1
        else:
          instances[type] = 1
  return instances

if __name__ == '__main__':
  start = sys.argv[1]
  end = sys.argv[2]

  reportType = sys.argv[3]
  print("ReportType:" + reportType)

  # timeperiod = 'Start=2020-03-01,End=2020-03-31'
  if (reportType == "summary"):
    coverage_all = get_coverage_report(start, end)
    sys.exit(0)

  if(reportType == "detail"):
    coverage_all = get_coverage_report(start, end)
    print("\nReserved Instances per Region\t\t\t\t\t\t\t\t\t\tContract Instances per Region")
    print("Region\tInstanceType\tNumber\tFactor\tNormalized\tScope\tType\tEnd Date\t\tInstanceType\tNumber\tFactor\tNormalized")
    region_ris = {}
    for region in coverage_all:
      ris = get_reserved_instances(region)
      ri_len = len(ris)

      instances = get_running_contract_instances(region)
      sorted_instance_types = sorted(instances.keys())
      instances_count = len(sorted_instance_types)

      max_len = max(ri_len, instances_count)
      print("\n" + region + "\t" + coverage_all[region])

      for i in range(0, max_len):
        row = "\t"
        if i < ri_len:
          row = row + ris[i] + "\t\t"
        else:
          row = row + "\t\t\t\t\t\t\t\t"

        if i < instances_count:
          itype = sorted_instance_types[i]
          factor = getFactor(itype)
          count = instances[itype]
          normalized = factor * count
          row = row + itype + "\t" + str(count) + "\t" + str(factor) + "\t" + str(normalized)
        print(row)

    sys.exit(0)

  if reportType == "instances":
    region = sys.argv[4]
    print("\nContract Instances:")
    instances = get_running_contract_instances(region)
    sorted_instance_types = sorted(instances.keys())
    for itype in sorted_instance_types:
      factor = getFactor(itype)
      count = instances[itype]
      normalized = factor * count
      print(itype + "\t" + str(count) + "\t" + str(factor) + "\t" + str(
          normalized))
    print("--------------------------")
    print("\nAll Instances:")
    instances = get_running_instances(region)
    sorted_instance_types = sorted(instances.keys())
    for itype in sorted_instance_types:
      factor = getFactor(itype)
      count = instances[itype]
      normalized = factor * count
      print(itype + "\t" + str(count) + "\t" + str(factor) + "\t" + str(
        normalized))