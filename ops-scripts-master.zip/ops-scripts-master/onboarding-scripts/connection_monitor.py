import requests
import os
import subprocess
import smtplib
from email.mime.text import MIMEText
import argparse
from requests.auth import HTTPBasicAuth
import socket
import time
from timeit import default_timer as timer

class Runner(object):
	def __init__(self, args):
		super(Runner, self).__init__()
		self.smtpserver = 'email-smtp.us-east-1.amazonaws.com'
		self.SMTP_Username = 'AKIAIQUPXUHQPGZKJVGQ'
		self.SMTP_Password = 'AlthjR24pQEMK78pj9wGk0MXsmJdRHyN3MrjuWbkCfeF'
		self.me = 'alert@searchstax.com'
		emails = args.email.split(",")
		if len(emails) > 0 :
			self.to = emails
		else:
			print("Please provide an email address")
			exit()

	def send_email(self,args):
		hostname = self.get_host_name()
		msg = MIMEText("Connectivity failure from " + args.tenant + "/" + hostname + " to "+ args.host)
		msg['Subject'] = "Connectivity failure from " + args.tenant + "/" + hostname + " to "+ args.host
		msg['From'] = self.me
		msg['To'] = ', '.join(self.to)
		s = smtplib.SMTP(self.smtpserver, 587)
		s.ehlo()
		s.starttls()
		s.ehlo()
		s.login(self.SMTP_Username, self.SMTP_Password)
		s.sendmail(self.me, self.to, msg.as_string())
		s.quit()

	def get_host_name(self):
		out = subprocess.check_output(['hostname'])
		out = out.decode("utf-8") 
		out = out.split('-')
		return out[0]

	def start(self, args):
		if args.type == "tcpping":
			if not self.is_tcpping(args.host, args.port):
				self.send_email(args)
		if args.type == "ping":
			if not self.is_icmpping(args.host):
				self.send_email(args)
		if args.type == "curl":
			if not self.is_curlping(args.host, args.username, args.password):
				self.send_email(args)

	def is_curlping(self, host, username="", password=""):
		resp = requests.head(host, auth=HTTPBasicAuth(username, password))
		if resp.status_code == 200:
			return True
		return False

	def is_icmpping(self,host):
		response = os.system("ping -c 1 -W 5 " + host + " > /dev/null")
		if response == 1:
			return True
		return False

	def is_tcpping(self, host, port):
		# This is taken from https://github.com/yantisj/tcpping under GNU Affero General Public License v3.0
		passed = 0
		failed = 0
		count = 0

		while count < 3:
			# Increment Counter
			count += 1

			success = False
			# New Socket
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

			# 1sec Timeout
			s.settimeout(1)

			# Start a timer
			s_start = timer()

			# Try to Connect
			try:
				s.connect((host, int(port)))
				s.shutdown(socket.SHUT_RD)
				success = True

			# Connection Timed Out
			except socket.timeout:
				failed += 1
			except OSError as e:
				failed += 1

			# Stop Timer
			s_stop = timer()
			s_runtime = "%.2f" % (1000 * (s_stop - s_start))

			if success:
				passed += 1

			# Sleep for 1sec
			if count < 3:
				time.sleep(1)

		if passed == 0:
			return False

		return True


if __name__ == '__main__':
    # create parser
    parser = argparse.ArgumentParser(description='Script to monitor the connectivity')

    # add arguments
    parser.add_argument(
        '--tenant', dest='tenant', action='store', help='Tenant ID'
    )
    parser.add_argument(
        '--type', dest='type', action='store', help='tcpping / ping / curl'
    )
    parser.add_argument(
        '--host', dest='host', action='store', help='Host to ping'
    )
    parser.add_argument(
        '--port', dest='port', action='store', help='Port for TCP ping'
    )
    parser.add_argument(
        '--username', dest='username', action='store', help='Username for curl (Optional)'
    )
    parser.add_argument(
        '--password', dest='password', action='store', help='Password for curl (Optional)'
    )
    parser.add_argument(
        '--email', dest='email', action='store', help='TechOps email,Pagerduty Email'
    )
    args = parser.parse_args()
    runner = Runner(args)
    runner.start(args)