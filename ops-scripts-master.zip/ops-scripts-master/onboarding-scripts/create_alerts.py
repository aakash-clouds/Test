#!/usr/bin/python

import requests
import json
import math
import getpass
import sys

class Runner(object):
	"""docstring for Runner"""
	searchstax_url = 'https://app.searchstax.com'
	auth_url = searchstax_url + '/api/rest/v1/obtain-auth-token/'
	deployment_health_url = searchstax_url + '/api/rest/v2/account/{0}/deployment/{1}/deployment-health/'
	create_alerts_url = searchstax_url + '/api/rest/v2/account/{0}/deployment/{1}/alerts/'
	deployment_read_url = searchstax_url + '/api/rest/v2/account/{0}/deployment/{1}/'
	create_heartbeat_alerts_url = searchstax_url + '/api/rest/v2/account/{0}/deployment/{1}/alerts/heartbeat/'

	def __init__(self, arg):
		super(Runner, self).__init__()
		self.username = arg
		password = getpass.getpass("Please enter password : ")
		print "Authenticating user ..."
		headers = {
			'Content-Type': 'application/x-www-form-urlencoded'
		}
		data = "username="+self.username+"&password="+password
		resp = requests.post(self.auth_url, data=data, headers=headers)
		resp_json = resp.json()
		if 'token' in resp_json:
			self.token = resp_json['token']
			print "User authenticated."
		else:
			print "User not authenticated. Program will now exit."
			exit()
		

	def start(self, tenant, deployment_uid):
		self.check_deployment_health(tenant,deployment_uid)
		self.createalerts(tenant, deployment_uid)


	def check_deployment_health(self, tenant, deployment_uid):
		print "Checking if deployment exists ..."
		headers = {
		    'Authorization': "Token "+self.token
		    }
		resp = requests.get(self.deployment_health_url.format(tenant, deployment_uid),headers=headers)
		if resp.status_code == 200:
			print "OK"
		else:
			print resp.text
			exit()

	def getheapmemory(self, tenant, deployment_uid):
		headers = {
		    'Authorization': "Token "+self.token
		    }
		resp = requests.get(self.deployment_read_url.format(tenant, deployment_uid),headers=headers)
		resp_json = resp.json()
		try:
			return int(resp_json['specifications']['jvm_heap_memory'])
		except:
			print "Could not get the value of jvm heap"
			exit() 

	def getdiskspace(self, tenant, deployment_uid):
		headers = {
		    'Authorization': "Token "+self.token
		    }
		resp = requests.get(self.deployment_read_url.format(tenant, deployment_uid),headers=headers)
		resp_json = resp.json()
		try:
			return int(resp_json['specifications']['disk_space'])
		except:
			print "Could not get the value of disk space"
			exit() 

	def createalerts(self, tenant, deployment_uid):
		print "Creating alerts"
		headers = {
		    'Authorization': "Token "+self.token,
		    'Content-Type': "application/json"
		    }
		url = self.create_alerts_url.format(tenant, deployment_uid)
		data = {
			"name" : "",
			"metric": "",
			"threshold": "",
			"unit": "",
			"operator": "",
			"email" : ["tech-ops@searchstax.com"],
			"host" : "*",
			"delay_mins" : "5",
			"max_alerts" : "5",
			"repeat_every" : "15"
		}

		print "system_1_min_5xx_error_rate"
		data['name']="1 Min. 5XX Error Rate"
		data['metric']= "system_1_min_5xx_error_rate"
		data['threshold']="5"
		data['unit']="number"
		data['operator']=">"
		resp = requests.post(url, data=json.dumps(data), headers=headers)
		print resp.text

		print "index_error_count"
		data['name']="Index - Error Count"
		data['metric']= "index_error_count"
		data['threshold']="10"
		data['unit']="number"
		data['operator']=">"
		resp = requests.post(url, data=json.dumps(data), headers=headers)
		print resp.text

		print "system_jvm_memory_used"
		jvmheap = self.getheapmemory(tenant, deployment_uid)
		jvm_val = math.ceil((jvmheap*0.8)/1024)
		data['name']="JVM Heap Memory Used > 80%"
		data['metric']= "system_jvm_memory_used"
		data['threshold']=str(jvm_val)
		data['unit']="KB"
		data['operator']=">"
		resp = requests.post(url, data=json.dumps(data), headers=headers)
		print resp.text

		print "search_timeouts"
		data['name']="Search Timeouts"
		data['metric']= "search_timeouts"
		data['threshold']="5"
		data['unit']="number"
		data['operator']=">"
		resp = requests.post(url, data=json.dumps(data), headers=headers)
		print resp.text

		print "system_disk_space_free"
		diskspace = self.getdiskspace(tenant, deployment_uid)
		disk_space = math.ceil((diskspace*0.2)/1024)
		data['name']="Free Disk Space < 20%"
		data['metric']= "system_disk_space_free"
		data['threshold']=str(disk_space)
		data['unit']="KB"
		data['operator']="<"
		resp = requests.post(url, data=json.dumps(data), headers=headers)
		print resp.text

		print "heartbeat alert"
		url = self.create_heartbeat_alerts_url.format(tenant, deployment_uid)
		data = {
			"name" : "",
			"failures": "",
			"interval": "",
			"email" : ["tech-ops@searchstax.com"],
			"host" : "*",
			"max_alerts" : "1"
		}
		data['name']="Heartbeat Alert"
		data['failures']= "10"
		data['interval']= "10"
		resp = requests.post(url, data=json.dumps(data), headers=headers)
		print resp.text


# print len(sys.argv)
if len(sys.argv) != 4:
	print 'Invalid number of arguments. Proper usage : "python create_alerts.py <username> <tenant name> <deployment uid>" '
	exit()

username = sys.argv[1]
tenant = sys.argv[2]
deployment_uid = sys.argv[3]
runner = Runner(username)
runner.start(tenant, deployment_uid)
