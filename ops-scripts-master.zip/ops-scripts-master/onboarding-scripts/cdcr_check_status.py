'''
Created on May 18, 2020

@author: vignesh
'''

import requests
import json
from email.mime.text import MIMEText
import smtplib
import sys
from datetime import datetime
try:
    import configparser as ConfigParser
except ImportError:
    import ConfigParser

class EmailSender(object):
    
    def sendEmail(self, config, subject, body):
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = config.get('mail', 'me')
        msg["To"] = config.get('mail', 'to')
        s = smtplib.SMTP(config.get('mail', 'smtpserver'), 587)
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login(config.get('mail', 'SMTP_Username'), config.get('mail', 'SMTP_Password'))
        s.sendmail(config.get('mail', 'me'), config.get('mail', 'to').split(","), msg.as_string())
        s.quit()

class CdcrChecker(object):
    
    def get_kv(self, arr, limit = None):
        if limit is not None:
            limit = limit * 2
        if limit is None or limit > len(arr):
            limit = len(arr)
           
        kv = {}
        i=0 
        while i < limit:
            if i+1 < limit:
                kv[arr[i]] = arr[i+1]
            else:
                kv[arr[i]] = None
            i = i+2
        return kv
        
    def get_queue_sizes(self, config, core_name):
        primary = config.get('primary', 'url') + core_name + "/cdcr?action=QUEUES"
        try:
            primary_req = requests.get(primary)
            primary_json = json.loads(primary_req.text)["queues"]
            
            queue_sizes = {}
            queues = self.get_kv(primary_json)
            for queue in queues:
                collections = self.get_kv(queues[queue])
                for collection in collections:
                    data = self.get_kv(collections[collection])
                    queue_sizes[str(queue)] = str(data["queueSize"])
            return queue_sizes
        except:
            return {"unknown":"unknown"}
    
    def get_queue_size(self, config, core_name):
        queue_sizes = self.get_queue_sizes(config, core_name)
        for x in queue_sizes:
            return queue_sizes[x]
    
    def is_queue_initialized(self, queue_size):
        if queue_size in ["unknown", "-1"]:
            return False
        else:
            return True
        
    def get_errors(self, config, core_name):
        primary = config.get('primary', 'url') + core_name + "/cdcr?action=ERRORS"
        try:
            primary_req = requests.get(primary)
            primary_json = json.loads(primary_req.text)["errors"]
            
            error_list = {}
            queues = self.get_kv(primary_json)
            for queue in queues:
                collections = self.get_kv(queues[queue])
                for collection in collections:
                    error = self.get_kv(collections[collection])
                    last_error = self.get_kv(error["last"], 1)
                    
                    #if len(last_error) > 0:
                    for last_error_timestamp in last_error:
                        if self.is_error_latest(last_error_timestamp, 300):
                            error_list[str(queue)] = str(last_error)
            return error_list
        except:
            return {"unknown":"unknown"}
        
    def get_error(self, config, core_name):
        error_list = self.get_errors(config, core_name)
        for x in error_list:
            return error_list[x]
    
    def is_error_latest(self, dt_input, elapsed_seconds):
        dt_format = '%Y-%m-%d %H:%M:%S.%f'
       
        curr = datetime.utcnow().strftime(dt_format)
        curr_time = datetime.strptime(curr, dt_format)
        
        dt_input=dt_input.replace("T"," ").replace("Z", "000")    
        input_time = datetime.strptime(dt_input, dt_format)
        
        diff = (curr_time - input_time)
        if(diff.days < 1 and diff.seconds < elapsed_seconds):
            return True
        else:
            return False
    
    def has_error(self, error):
        if error is None or error == "unknown":
            return False
        else:
            return True
    
    def get_state(self, config, collection_name):
        primary = config.get('primary', 'url') + collection_name + "/cdcr?action=STATUS"
        try:
            primary_req = requests.get(primary)
            primary_json = json.loads(primary_req.text)["status"]
            status = self.get_kv(primary_json)
            return status["process"]
        except:
            return "unknown"
    
    def is_running(self, cdcr_state):
        if cdcr_state == "started":
            return True
        else:
            return False
    
    def get_leader_cores(self, shards):
        leader_cores = []
        for shard in shards:
            replicas = shards[shard]["replicas"]
            for replica in shards[shard]["replicas"]:
                core = replicas[replica]
                if "leader" in core and core["leader"] == "true":
                    leader_cores.append(core["core"])
        return leader_cores
    
    def get_leader_core(self, shards):
        return self.get_leader_cores(shards)[0]
    
    @staticmethod
    def get_alerts(config):        
        cdcr = CdcrChecker()
        primary = config.get('primary', 'url') + "admin/collections?action=clusterstatus&wt=json"
        primary_req = requests.get(primary)        
        primary_json = json.loads(primary_req.text)["cluster"]["collections"]
        
        alerts = []
        failed_collections = []
        
        print("\n\nCDCR Status:")
        for collection_name in primary_json:
            cdcr_state = cdcr.get_state(config, collection_name)
            if cdcr_state != "unknown":                
                shards = primary_json[collection_name]["shards"]
                leader_core = cdcr.get_leader_core(shards)
                queue_size = cdcr.get_queue_size(config, leader_core)
                error = cdcr.get_error(config, leader_core)
                
                stat="Collection=" + str(collection_name) + ", state=" + str(cdcr_state) + ", queue_size=" + str(queue_size) + ", error=" + str(error)
                print(stat)
                
                if not cdcr.is_running(cdcr_state) or not cdcr.is_queue_initialized(queue_size) or cdcr.has_error(error):
                    alerts.append(stat)
                    failed_collections.append(str(collection_name))
        return alerts, failed_collections
    
       
if __name__ == '__main__':
    #configFile="cdcr_alert_test.properties"
    configFile=sys.argv[1]
    
    config = ConfigParser.RawConfigParser()
    config.read(configFile)
    try:
        alerts, failed_collections = CdcrChecker.get_alerts(config)
        
        if len(alerts) > 0:
            subject = "CDCR not running in " + config.get('primary', 'name') + ": " + ",".join(failed_collections)
            message = "CDCR not running in following collections on " + config.get('primary', 'name') + ". Check logs for detail"
            for alert in alerts:
                message = message + "\n" + alert
            
            sender = EmailSender()
            sender.sendEmail(config, subject, message)
    except Exception as e:
        sender = EmailSender()
        subject = "Error running CDCR status checker for " + config.get('primary', 'name')
        sender.sendEmail(config, subject, e)
