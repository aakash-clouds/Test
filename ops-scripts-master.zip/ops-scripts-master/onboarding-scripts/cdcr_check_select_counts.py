import requests
import json
from email.mime.text import MIMEText
import sys
import smtplib
try:
    import configparser as ConfigParser
except ImportError:
    import ConfigParser

class EmailSender(object):

    def sendEmail(self, config, subject, body):
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = config.get('mail', 'me')
        msg["To"] = config.get('mail', 'to')
        s = smtplib.SMTP(config.get('mail', 'smtpserver'), 587)
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login(config.get('mail', 'SMTP_Username'), config.get('mail', 'SMTP_Password'))
        s.sendmail(config.get('mail', 'me'), config.get('mail', 'to').split(","), msg.as_string())
        s.quit()

if __name__ == '__main__':
    #configFile="cdcr_alert.properties"
    configFile=sys.argv[1]
    
    config = ConfigParser.RawConfigParser()
    config.read(configFile)
    try:
        alerts = []
        failed_collections = []
        for p_coll, s_coll in zip(config.get('primary', 'collections').split(","), config.get('secondary', 'collections').split(",")):
            primary = config.get('primary', 'url') + p_coll + "/select?q=*:*&rows=0"
            secondary = config.get('secondary', 'url') + s_coll + "/select?q=*:*&rows=0"
            
            primary_req = requests.get(primary)
            secondary_req = requests.get(secondary)
            primary_json = json.loads(primary_req.text)["response"]
            secondary_json = json.loads(secondary_req.text)["response"]

            count = primary_json["numFound"]
            sec_count = secondary_json["numFound"]
            
            # Uncomment below line if you want to test failure
            # if collection_name.find("custom_web_index") == 0: sec_count = 0
            
            if count != sec_count:
                alerts.append("Collection " + p_coll + " -> " + s_coll + " is out of sync, primary:" + str(count) + ", secondary:" + str(sec_count))
                failed_collections.append(p_coll)

        if(len(alerts)) > 0:
            message = "The following collections in " + config.get('secondary', 'name') + " are out of Sync with " + config.get('primary', 'name')
            subject = "CDCR Sync failure in " + config.get('secondary', 'name') + ": " + ",".join(failed_collections)
            for alert in alerts:
                message = message + "\n" + alert
            sender = EmailSender()
            sender.sendEmail(config, subject, message)
    except:
        sender = EmailSender()
        message = "Error running CDCR count checker for " + config.get('primary', 'name')
        sender.sendEmail(config, message, message)
