import requests
import json
from email.mime.text import MIMEText
import sys
import smtplib
import time
import traceback

try:
  import configparser as ConfigParser
except ImportError:
  import ConfigParser


class EmailSender(object):

    def sendEmail(self, config, subject, body):
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = config.get('mail', 'me')
        msg["To"] = config.get('mail', 'to')
        s = smtplib.SMTP(config.get('mail', 'smtpserver'), 587)
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login(config.get('mail', 'SMTP_Username'),
                config.get('mail', 'SMTP_Password'))
        s.sendmail(config.get('mail', 'me'), config.get('mail', 'to').split(","),
                   msg.as_string())
        s.quit()


def get_collection_counts(url):
    url2 = url + "admin/cores?action=status"
    req = requests.get(url2)
    response_json = json.loads(req.text)["status"]
    collection_counts = {}
    for core in response_json:
        idx = core.find("_shard")
        col_name = core[0:idx]
        doc_count = response_json[core]["index"]["numDocs"]
        collection_counts[col_name] = doc_count
    return collection_counts

def percent_diff(value1, value2):
  if(value1 != 0):
    return abs(float(value2-value1)/float(value1)) * 100
  else:
    return abs(value1-value2)


def print_collection_counts(col_dict):
    for col_name in sorted(col_dict):
        print(col_name, col_dict[col_name])


if __name__ == '__main__':
    configFile = sys.argv[1]

    config = ConfigParser.RawConfigParser()
    print("Reading configuration: ", configFile)
    config.read(configFile)
    primary = config.get('primary', 'url')
    secondary = config.get('secondary', 'url')
    secondary2 = config.get('secondary', 'url2')

    primary_name = config.get('primary', 'name')
    secondary_name = config.get('secondary', 'name')

    try:
        collection_counts_primary = get_collection_counts(primary)
        collection_counts_secondary = get_collection_counts(secondary)
        collection_counts_secondary2 = get_collection_counts(secondary2)

        alerts = []
        failed_collections = []
        print("\nSecondary Counts:")
        print_collection_counts(collection_counts_secondary)

        print("\nSecondary Counts on node2:")
        print_collection_counts(collection_counts_secondary2)

        print("\n\nPrimary Counts:")
        print_collection_counts(collection_counts_primary)

        print("\n\n")

        for collection_name in collection_counts_primary:
          count = collection_counts_primary[collection_name]
          sec_count = 0
          if collection_name in collection_counts_secondary:
            sec_count = collection_counts_secondary[collection_name]
          else:
            continue

          # Uncomment below line if you want to test failure
          # if collection_name.find("custom_web_index") == 0: sec_count = 0
          retries = 1
          while retries < 5:
            if percent_diff(sec_count, count) > 1:
              print("Retry:", retries)
              print("Secondary collection count is mis-matching for:" +
                    collection_name + ", count:", sec_count)
              time.sleep(30)
              sec2 = get_collection_counts(secondary)
              sec_count = sec2[collection_name]
              if percent_diff(sec_count, count) <= 1:
                break
            retries += 1

          if percent_diff(sec_count, count) > 1:
            if collection_name not in failed_collections:
              alerts.append(
                  "Collection " + collection_name + " is out of sync, primary:" + str(
                      count) + ", secondary:" + str(sec_count))
              failed_collections.append(collection_name)

          #Now check with sec2
          sec_count = 0
          if collection_name in collection_counts_secondary:
            sec_count = collection_counts_secondary2[collection_name]

          # Uncomment below line if you want to test failure
          # if collection_name.find("custom_web_index") == 0: sec_count = 0
          retries = 1
          while retries < 5:
            if percent_diff(sec_count, count) > 1:
              print("Retry:", retries)
              print("Secondary collection count is mis-matching for:" +
                    collection_name + ", count:", sec_count)
              time.sleep(30)
              sec2 = get_collection_counts(secondary2)
              sec_count = sec2[collection_name]
              if percent_diff(sec_count, count) <= 1:
                break
            retries += 1

          if percent_diff(sec_count, count) > 1:
            if collection_name not in failed_collections:
              alerts.append(
                  "Collection " + collection_name + " is out of sync, primary:" + str(
                      count) + ", secondary:" + str(sec_count))
              failed_collections.append(collection_name)

        if (len(alerts)) > 0:
            message = "The following collections in " + \
                      secondary_name + " are out of Sync with " + primary_name


            subject = "CDCR Sync failure in " + secondary_name + ": " + \
                      ",".join(failed_collections)
            for alert in alerts:
                message = message + "\n" + alert

            sender = EmailSender()
            sender.sendEmail(config, subject, message)
    except:
        traceback.print_exc()
        sender = EmailSender()
        message = "Error running CDCR count checker for " + config.get('primary',
                                                                     'name')
        sender.sendEmail(config, message, message)
