#!/usr/bin/python

import json
import math
import getpass
import os
import sys
import subprocess
import smtplib
from email.mime.text import MIMEText

class Runner(object):
	def __init__(self, arg):
		super(Runner, self).__init__()
		self.loc = self.findzkCli(arg)
		self.smtpserver = 'email-smtp.us-east-1.amazonaws.com'
		self.SMTP_Username = 'AKIAIQUPXUHQPGZKJVGQ'
		self.SMTP_Password = 'AlthjR24pQEMK78pj9wGk0MXsmJdRHyN3MrjuWbkCfeF'
		self.me = 'alert@searchstax.com'
		self.to = ['tech-ops@searchstax.com', 'pulseemailnotification@searchstax.pagerduty.com']

	def findzkCli(self,loc):
		if os.path.isdir(loc):
			loc = os.path.join(loc,"zkcli.sh")
			if os.path.isfile(loc):
				return loc
			else:
				print "Couldn't find zkcli.sh"
				exit()				
		elif os.path.isfile(loc):
			filename = os.path.basename(loc)
			if filename == 'zkcli.sh':
				return loc
			else:
				print "Couldn't find zkcli.sh"
				exit()
		else:
			print "Couldn't find zkcli.sh"
			exit()

	def start(self,zkhost,replica_count):
		collections = self.get_all_collection_names(zkhost)
		coll_dict = self.get_status_for_collections(zkhost, collections)
		if self.is_collection_degraded(coll_dict, replica_count):
			collection = self.which_collection_degraded(coll_dict, replica_count)
			self.send_email(collection)

	def is_collection_degraded(self, coll_dict, replica_count):
		for collection in coll_dict:
			for shards in coll_dict[collection][collection]["shards"]:
				active_count = 0
				for replica in coll_dict[collection][collection]["shards"][shards]["replicas"]:
					if "active" in coll_dict[collection][collection]["shards"][shards]["replicas"][replica]["state"]:
						active_count = active_count + 1
				if int(active_count) < int(replica_count):
					return True
		return False

	def which_collection_degraded(self, coll_dict, replica_count):
		for collection in coll_dict:
			for shards in coll_dict[collection][collection]["shards"]:
				active_count = 0
				for replica in coll_dict[collection][collection]["shards"][shards]["replicas"]:
					if "active" in coll_dict[collection][collection]["shards"][shards]["replicas"][replica]["state"]:
						active_count = active_count + 1
				if int(active_count) < int(replica_count):
					return collection
		return ""

	def get_status_for_collections(self, zkhost, collections):
		coll_dict = {}
		for collection in collections:
			cmd = ["-cmd", "get", "/collections/"+collection+"/state.json"]
			out = self.query_zkhost(zkhost, cmd)
			coll_dict[collection] = json.loads(out)
		return coll_dict

	def get_all_collection_names(self, zkhost):
		cmd =  ["-cmd", "list"]
		resp = self.query_zkhost(zkhost, cmd)
		resp = resp.splitlines()
		collections = []
		for line in resp:
			if "/state.json" in line:
				line = line.split("/")
				collections.append(line[2])
		return collections

	def query_zkhost(self, zkhost, cmd):
		process_str = [self.loc, "-zkhost", zkhost]
		process_str = process_str + cmd
		output = subprocess.check_output(process_str)
		return output

	def send_email(self, collection):
		hostname = self.get_host_name()
		msg = MIMEText("Collection: \""+ collection+"\" degraded in " + hostname)
		msg['Subject'] = "Collection: \""+ collection+"\" degraded in " + hostname
		msg['From'] = self.me
		msg['To'] = ', '.join(self.to)
		s = smtplib.SMTP(self.smtpserver, 587)
		s.ehlo()
		s.starttls()
		s.ehlo()
		s.login(self.SMTP_Username, self.SMTP_Password)
		s.sendmail(self.me, self.to, msg.as_string())
		s.quit()

	def get_host_name(self):
		out = subprocess.check_output(['hostname'])
		out = out.split('-')
		return out[0]

if len(sys.argv) != 4:
	print 'Invalid number of arguments. Proper usage : "python replication_monitoring.py <location of zkcli.sh> <zkhost> <replica count>" '
	exit()

loc = sys.argv[1]
zkhost = sys.argv[2]
replica_count = sys.argv[3]
runner = Runner(loc)
runner.start(zkhost,replica_count)


###
#*/15 * * * * python /opt/apps/scripts/replication_monitoring.py /opt/apps/solr/server/scripts/cloud-scripts/zkcli.sh 10.61.0.36:2181,10.61.0.34:2181,10.61.0.35:2181 2
###