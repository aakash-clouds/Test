#!/usr/bin/python

import requests
import json
import math
import getpass
import os
import sys
import subprocess
import smtplib
from email.mime.text import MIMEText
import argparse
from requests.auth import HTTPBasicAuth

class Runner(object):
	def __init__(self, args):
		super(Runner, self).__init__()
		self.smtpserver = 'email-smtp.us-east-1.amazonaws.com'
		self.SMTP_Username = 'AKIAIQUPXUHQPGZKJVGQ'
		self.SMTP_Password = 'AlthjR24pQEMK78pj9wGk0MXsmJdRHyN3MrjuWbkCfeF'
		self.me = 'alert@searchstax.com'
		emails = args.email.split(",")
		if len(emails) > 0 :
			self.to = emails
		else:
			print("Please provide an email address")
			exit()

	def send_email(self,args):
		hostname = self.get_host_name()
		msg = MIMEText("Number of documents in collection " + args.collection +" on " + args.tenant + "/" + hostname + " is below "+ args.threshold)
		msg['Subject'] = "Document count on " + args.tenant + "/" + hostname + " is below threshold"
		msg['From'] = self.me
		msg['To'] = ', '.join(self.to)
		s = smtplib.SMTP(self.smtpserver, 587)
		s.ehlo()
		s.starttls()
		s.ehlo()
		s.login(self.SMTP_Username, self.SMTP_Password)
		s.sendmail(self.me, self.to, msg.as_string())
		s.quit()

	def get_host_name(self):
		out = subprocess.check_output(['hostname'])
		out = out.split('-')
		return out[0]

	def start(self, args):
		if not self.is_deployment_exists(args.token, args.solr_url):
			print("Deployment is inacessible.")
			exit()
		if not self.is_collection_exists(args.token, args.solr_url, args.collection):
			print("Collection does not exist")
			exit()
		count = self.get_document_count(args.token, args.solr_url, args.collection, args.query)
		if count < int(args.threshold):
			self.send_email(args)

	def is_deployment_exists(self, token, solr_url):
		resp = requests.head(solr_url, auth=HTTPBasicAuth('solr', token))
		if resp.status_code == 200:
			return True
		return False

	def is_collection_exists(self, token, solr_url, collection):
		resp = requests.head(solr_url + collection + "/select?q=*%3A*&rows=0", auth=HTTPBasicAuth('solr', token))
		if resp.status_code == 200:
			return True
		return False

	def get_document_count(self, token, solr_url, collection, query):
		resp = requests.get(solr_url + collection + "/select?q=" + query + "&rows=0&wt=json", auth=HTTPBasicAuth('solr', token))
		resp_json = resp.json()
		return int(resp_json["response"]["numFound"])

# if len(sys.argv) != 4:
# 	print 'Invalid number of arguments. Proper usage : "python collection_count_monitoring.py " '
# 	exit()

if __name__ == '__main__':
    # create parser
    parser = argparse.ArgumentParser(description='Script to monitor the count of collection')

    # add arguments
    parser.add_argument(
        '--tenant', dest='tenant', action='store', help='Tenant ID'
    )
    parser.add_argument(
        '--solr-url', dest='solr_url', action='store', help='Solr URL'
    )
    parser.add_argument(
        '--token', dest='token', action='store', help='Access token'
    )
    parser.add_argument(
        '--collection', dest='collection', action='store', help='Name of collection to monitor'
    )
    parser.add_argument(
        '--threshold', dest='threshold', action='store', help='Value below which the alert will trigger'
    )
    parser.add_argument(
        '--email', dest='email', action='store', help='TechOps email,Pagerduty Email'
    )
    parser.add_argument(
        '--query', dest='query', action='store', help='The query for which the result needs to be monitored. This defaults to "*:*" if not specified', default="*%3A*"
    )
    args = parser.parse_args()
    runner = Runner(args)
    runner.start(args)


###
#*/15 * * * * python /opt/apps/scripts/collection_count_monitoring.py --tenant SilverQAAccount --solr-url https://ss127402-sq0u0vcz-westus-azure.searchstax.com/solr/ --token <token> --collection sitecore_core_index --threshold 500 --email tech-ops@searchstax.com,pulseemailnotification@searchstax.pagerduty.com
###
