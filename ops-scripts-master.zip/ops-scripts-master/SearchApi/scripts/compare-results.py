# Compare ranking results of 2 models.

# Strategy: compute the sum of ranking where items match a criteria (e.g., listing_category:Magicians)
# If summed-ranks of one model are significantly less than the other, there is an effect of boosting on the criteria.

import json
from pprint import pprint

data_dir = '/Users/eric/Desktop/boopsie'

criteria = ('listing_category', 'Magicians')


def load_model(model):
    with open('%s/%s.json' % (data_dir, model), 'r') as f:
        j = json.load(f)
        return j

def print_title(listing_tuple):
    rank, listing = listing_tuple
    field, value = criteria
    if listing[field] == value:
        print('%s: %s' % (rank, listing['listing_name']))
        return rank
    return 0

def sum_ranks(results):
    print("\n\nRankings for %s:" % results)
    print("=============================")
    j = load_model(results)
    listings = j['response']['docs']
#    print("len=%s" % len(listings))
    sum = 0
    for l in enumerate(listings):
        sum += print_title(l)
    return sum

sum_a = sum_ranks('boopsie_nomodel')
sum_b = sum_ranks('boopsie_current')

print("sumA=%s" % sum_a)
print("sumB=%s" % sum_b)



