#!/bin/sh

# Create a Version.java containing latest git commit, displayable when debug=true in searchapi

blobname=searchapi
scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
opssearchapidir="$(dirname $scriptdir)"
opsscriptdir="$(dirname $opssearchapidir)"
codedir="$(dirname $opsscriptdir)"
searchapidir="$codedir/search-api"
javafile=$searchapidir/src/main/java/com/measuredsearch/searchapi/Version.java

pushd $searchapidir
y=$(git status|grep 'nothing to commit'|wc -l| tr -d '[:space:]')
echo "y=$y"
if [ $y == '0' ]; then
  echo "You must commit everything before creating a version"
  exit 1
fi
popd

version=$(git log -n 1|head -n 1|cut -d' ' -f 2)
echo "version is $version"

cat >$javafile << EOF
package com.measuredsearch.searchapi;

class Version {
    public static String NAME = "git_version";
    public static String VERSION = "$version";
}
EOF

