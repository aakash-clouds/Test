#!/usr/bin/python

import json
import sys

#blobs = sys.argv[1]
#blobs = sys.argv[1]


def get_versions():
    with open ('/tmp/blobs.json') as blobs_file:
      j = json.load(blobs_file)
    resp = j['response']
    docs = resp['docs']
    versions = [doc['version'] for doc in docs]
    return versions

def get_latest_version(versions):
    return max(versions)

print(get_latest_version(get_versions()))
