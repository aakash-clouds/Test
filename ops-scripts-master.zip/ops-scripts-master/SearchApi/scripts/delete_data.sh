#!/bin/bash

# Script which deploys the jar file to a solr deployment

if [ "$#" -ne 2 ]; then
  echo "Usage: delete_data.sh <env> <collection>"
  exit 1
fi

env=$1
collection=$2

. configs/$env.sh

curl "$solr/$collection/update?commit=true" --data-binary '<delete><query>*:*</query></delete>' -H 'Content-Type: text/xml'

