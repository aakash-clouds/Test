#!/bin/bash

# Script which creates a collection

#!/bin/bash

if [ "$#" -ne 3 ]; then
  echo "Usage: upconfig.sh <env> <collection> <config>"
  exit 1
fi

env=$1
collection=$2
config=$3

. configs/$env.sh

curl "$solr/admin/collections?action=CREATE&name=$collection&collection.configName=$config&numShards=1&replicationFactor=1&maxShardsPerNode=1"
