#!/bin/bash

# Script which updates a single field in a document

if [ "$#" -ne 1 ]; then
  echo "Usage: update_doc local|msdev|msstaging|sandbox|staging|dev|prod"
  exit 1
fi

datafile=$2

if [ $1 = 'local' ]; then
   solr="http://localhost:8983/solr"
elif [ $1 = 'msdev' ]; then
  solr=http://34.204.47.121:8983/solr
elif [ $1 = 'msstaging' ]; then
  solr=https://ss715288-us-west-2-aws.measuredsearch.com/solr
elif [ $1 = 'sandbox' ]; then
  solr=http://54.158.25.120:8983/solr
elif [ $1 = 'staging' ]; then
  solr=https://ss892967-us-east-1-aws.measuredsearch.com/solr
elif [ $1 = 'dev' ]; then
  solr=https://ss920563-us-east-1-aws.measuredsearch.com/solr
else 
  echo "Unknown environment: $1"
  exit 1
fi

scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
datadir="$(dirname $scriptdir)/data"

#curl -X POST -H 'Content-type:application/json' -d'[{"id":1,"listing_view_count":{"set":45}}]'  "$solr/listings/update?commit=true"
curl -X POST -H 'Content-type:application/json' -d'[{"id":1,"listing_view_count":{"inc":45}}]'  "$solr/listings/update?commit=true"