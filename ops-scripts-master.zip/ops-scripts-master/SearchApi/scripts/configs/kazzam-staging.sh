#!/bin/bash

# TODO source kazzam-common

. configs/kazzam-staging_private.sh

customer=kazzam
host=staging-kazzam-search.searchstax.com
tenant=Kazzam
app=sa372715
solrhost="${host}"
solr="https://$solrhost/solr"
zkhost=$solrhost:2181