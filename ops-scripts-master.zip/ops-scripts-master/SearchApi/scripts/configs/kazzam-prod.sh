#!/bin/bash

# TODO source kazzam-common

. secrets.sh

customer=kazzam
host=ss125649
tenant=TBD
app=TBD
token=$kazzam_token_TBDsa971389
solrhost="${host}-us-east-1-aws.measuredsearch.com"
solr="https://$solrhost/solr"
zkhost=$solrhost:2181