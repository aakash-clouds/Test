#!/bin/bash

# TODO source kazzam-common

. configs/kazzam-gold-prod_private.sh

customer=kazzam
host=prod-kazzam-search.searchstax.com
tenant=Kazzam
app=sa49265
#token=$kazzam_token_TBDsa971389
solrhost="${host}"
solr="https://$solrhost/solr"
#zkhost=$solrhost:2181
zkhost=ss983818-1-us-east-1-aws.measuredsearch.com:2181,ss983818-2-us-east-1-aws.measuredsearch.com:2181,ss983818-3-us-east-1-aws.measuredsearch.com:2181