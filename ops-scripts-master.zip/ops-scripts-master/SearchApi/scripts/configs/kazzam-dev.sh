#!/bin/bash

customer=kazzam
host=dev-kazzam-search.searchstax.com
solrhost=$host
solr="https://$solrhost/solr"
zkhost=$solrhost:2181