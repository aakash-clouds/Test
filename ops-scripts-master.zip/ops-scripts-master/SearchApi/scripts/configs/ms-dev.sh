#!/bin/bash

# TODO source kazzam-common

. secrets.sh

customer=measuredsearch
host=34.204.47.121
tenant=TBD
app=TBD
token=$kazzam_token_TBDsa971389
solrhost=$host
zkhost=$solrhost:2181
key=~/keys/searchstax-dev42.pem