#!/bin/bash

# TODO source kazzam-common

host=ss920563
tenant=TBD
app=TBD
token=$kazzam_token_TBDsa971389
solrhost=localhost
zkhost=$solrhost:9983