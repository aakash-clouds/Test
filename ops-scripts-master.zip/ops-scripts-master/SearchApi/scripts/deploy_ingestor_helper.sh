#!/bin/bash

sudo mkdir -p /opt/apps/ss_automation/ingestor/logs
sudo mv /home/ubuntu/* /opt/apps/ss_automation/ingestor
ls -l /opt/apps/ss_automation/ingestor

#cronline='4 2 * * * /opt/apps/ss_automation/ingestor/exec_ingestor.sh >> /var/log/ingestor/exec_ingestor_script.log 2>&1   # analytics stats ingestor'
cronline='4 2 * * * /opt/apps/ss_automation/ingestor/exec_ingestor.sh > /dev/null 2>&1   # analytics stats ingestor'
(crontab -l 2>/dev/null|grep -v ingestor; echo $cronline) | crontab -