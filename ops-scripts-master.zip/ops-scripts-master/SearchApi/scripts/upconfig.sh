#!/bin/bash

if [ "$#" -ne 2 ]; then
  echo "Usage: upconfig.sh <env> <confname>"
  exit 1
fi

env=$1
confname=$2

. configs/$env.sh

zkclient_home=/Users/eric/Documents/code/searchstax-client/solr-5/scripts

scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
opssearchapidir="$(dirname $scriptdir)"
opsscriptdir="$(dirname $opssearchapidir)"
codedir="$(dirname $opsscriptdir)"
customerdir="$codedir/customer-configs/$customer"
confdir="$customerdir/conf/$env/$confname"

pushd $zkclient_home
./zkcli.sh -zkhost $zkhost -cmd upconfig -confdir $confdir -confname $confname
popd
