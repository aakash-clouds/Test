#!/bin/bash

if [ "$#" -ne 1 ]; then
  echo "Usage: make_exec_ingestor.sh <env>"
  exit 1
fi

source configs/$1.sh

cat <<EOF > exec_ingestor.sh
#!/bin/bash

# script to execute the analytics stats ingestor

PATH=/opt/apps/jdk/jdk1.8.0_45/bin:/opt/apps/jdk/jdk1.8.0_45/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin

echo "running, yo">/opt/apps/ss_automation/ingestor/logs/andiran.txt

ingestorDir=/opt/apps/ss_automation/ingestor
log=\$ingestorDir/logs/ingestor.log
ingestorJar=\$ingestorDir/search-api-all-1.0.jar

java \\
  -Dingestor.log=\$log \\
  -Dingestor.interval=10 \\
  -Dingestor.token=$token \\
  -Dingestor.tenant=$tenant \\
  -Dingestor.app=$app \\
  -Dingestor.searchclick_count=listing_view_count \\
  -Dingestor.transaction_count=listing_sold_count \\
  -Dingestor.ctc_rate=listing_conv_rate \\
  -Dingestor.search_url=$solr/listings \\
  -jar \$ingestorJar
EOF
