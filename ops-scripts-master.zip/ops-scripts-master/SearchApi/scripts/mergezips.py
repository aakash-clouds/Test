import re

f=open("../conf/listings/zipcodes_joined.csv", "r")

p1=re.compile("(.*),(.*),(.*),(.*),(.*)")
p2=re.compile("(.*),(.*),(.*)")
while True:
  l=f.readline()
  if not l:
    break
  m=p1.match(l)
  if m:
    print("%s,%s,%s" % (m.group(1), m.group(4), m.group(5)))
  else:
    m=p2.match(l.strip())
    if m:
      print("%s,%s,%s" % (m.group(1), m.group(2), m.group(3)))
