#!/bin/bash

# Setup a test collection
# Assume that the name of the config, the name of the data file, and the name of 
# the collection correspond, e.g.:
# collection=kazzamish
# /conf/kaazamish
# /data/kazzamish.json

# Assumes fixed dev solr deployment has already been setup

# Here are some preliminary steps for getting the data in the first place:
# download the config (includes relevance rules)
#   downconfig kazzam-dev listings
#   cp -r /tmp/conf/listings ../conf/kazzamish
# download the data
#   curl "https://ss920563-us-east-1-aws.measuredsearch.com/solr/listings/select?q=*%3A*&wt=json&indent=true&start=0&rows=2000000000&omitHeader=true" > ../data/kazzamish.json
# Hand edit that file to just use the response in square brackets
# Hand edit that file to remove all _version_ fields

if [ "$#" -ne 1 ]; then
  echo "Usage: setup_test_collection.sh <collection>"
  exit 1
fi

collection=$1

# Upload configs
./upconfig.sh ms-staging $collection

# Create the collection
# TODO: Check if the collection exists, if so, skip creation
./create_collection.sh ms-staging $collection $collection

# Upload data
./post_data.sh ms-staging $collection $collection.json

