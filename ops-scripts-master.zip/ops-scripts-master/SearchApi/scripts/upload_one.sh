#!/bin/bash

if [ "$#" -ne 2 ]; then
  echo "Usage: upload-one.sh local|msdev|msstaging|sandbox|dev|test file"
  exit 1
fi

file=$2

if [ $1 = 'local' ]; then
  solrhost=localhost
  zkhost=$solrhost:9983
elif [ $1 = 'msdev' ]; then
  solrhost=34.204.47.121
  key=~/keys/searchstax-dev42.pem
  zkhost=$solrhost:2181
elif [ $1 = 'msstaging' ]; then
  solrhost=ss715288-us-west-2-aws.measuredsearch.com
  zkhost=$solrhost:2181
elif [ $1 = 'dev' ]; then
  solrhost=ss920563-us-east-1-aws.measuredsearch.com
  zkhost=$solrhost:2181
elif [ $1 = 'staging' ]; then
  solrhost=ss892967-us-east-1-aws.measuredsearch.com
  zkhost=$solrhost:2181
elif [ $1 = 'prod' ]; then
  solrhost=ss125649-us-east-1-aws.measuredsearch.com
  zkhost=$solrhost:2181
else 
  echo "Unknown environment: $1"
  exit 1
fi


zkclient_home=/Users/eric/Documents/code/searchstax-client/solr-5/scripts
confname=listings
scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
main_confdir="$(dirname $scriptdir)/conf/$confname"


confdir=/tmp/conf/listings

rm -rf $confdir
mkdir -p $confdir
cp $main_confdir/$file $confdir


pushd $zkclient_home
./zkcli.sh -zkhost $zkhost -cmd upconfig -confdir $confdir -confname $confname
popd
