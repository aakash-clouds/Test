#!/bin/bash

DATA_DIR=../data
DATA_FILE=$DATA_DIR/data.json
SOLR=http://34.204.47.121:8983/solr
COLLECTION=listings


curl -X POST -H 'Content-type:application/json' -d @$DATA_FILE "$SOLR/$COLLECTION/update?commit=true"
#cat $DATA_FILE