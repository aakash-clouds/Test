#!/bin/bash

if [ "$#" -ne 1 ]; then
  echo "Usage: deploy_ingestor.sh <env>"
  exit 1
fi

key=~/keys/searchstax.pem

scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
opssearchapidir="$(dirname $scriptdir)"
opsscriptdir="$(dirname $opssearchapidir)"
codedir="$(dirname $opsscriptdir)"
searchapidir="$codedir/search-api"
jarfile="$searchapidir/build/libs/search-api-all-1.0.jar"

source configs/$1.sh

echo "Building jar..."
pushd $searchapidir
gradle clean
gradle fatJar
popd

echo "Creating ingestor script..."
$scriptdir/make_exec_ingestor.sh $1

# push script and jar
scp $scriptdir/exec_ingestor.sh $jarfile $host:/home/ubuntu
# push script only
#scp $scriptdir/exec_ingestor.sh $host:/home/ubuntu
# move script to proper home
ssh $host 'bash -s' < deploy_ingestor_helper.sh
