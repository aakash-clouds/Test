import requests
import socket
import smtplib
from email.mime.text import MIMEText
import sys
import json

smtpserver = 'email-smtp.us-east-1.amazonaws.com'
SMTP_Username='AKIAIQUPXUHQPGZKJVGQ'
SMTP_Password='AlthjR24pQEMK78pj9wGk0MXsmJdRHyN3MrjuWbkCfeF'

SEARCHSTAX_API = 'https://app.searchstax.com'


class ZabbixUtil:
    def __init__(self):
        #to make a connection with the user
        headers = {
            'Content-Type': 'application/json-rpc',
        }
        data = {
            "jsonrpc": "2.0",
            "method": "user.login",
            "params": {
                "user": "zabbix",
                "password": "zabbix123"
            },
            "id": 1
        }
        response = requests.post('https://zbx-prd.searchstax.com/zabbix/api_jsonrpc.php', headers=headers, json = data)
        if response.status_code == 200:
            auth_id = response.json()['result']
        else:
            raise Exception("Zabbix server is down!")
        #auth_id is the zabbix token authentication for user "zabbix"
        print(auth_id)
        self.auth_id = auth_id

    def get_value_of_trigger_id(self, triggerid):
        headers = {
            'Content-Type': 'application/json-rpc',
        }
        data1 = {
            "jsonrpc": "2.0",
            "method": "trigger.get",
            "params": {
                "triggerids": [ triggerid ],
                "output": "extend",
                "selectFunctions": "extend"
            },
            "auth": self.auth_id,
            "id": 1
        }
        triggerval = -1
        response2 = requests.post('https://zbx-prd.searchstax.com/zabbix/api_jsonrpc.php', headers=headers, json = data1)
        if response2.status_code == 200:
            trigger_value_servers = response2.json()['result']
            for trigger_value in trigger_value_servers:
                print("Api call trigger value", trigger_value['value'])
                triggerval = trigger_value['value']

        return triggerval

class DRFailover:
    def __init__(self, filename):
        self.config = json.load(open(filename))
        self.monitor = ZabbixUtil()

    def send_email(self):
        text = 'A DR failover switch has occurred on ' + socket.gethostname()
        text = text + ". \nYour DNS " + self.config["vanityDNS"] + " has been switched to DR deployment: " + self.config["drDNSValue"]
        text = text + '.\n\nA support ticket has been created and our team will follow up ' \
                      'by sending out the details of the bridge.'
        msg = MIMEText(text, "plain")

        msg['Subject'] = "DNS Failover has occurred for " + self.config["tenant"] + "/" + self.config["deploymentName"] + "(" + self.config["deploymentId"] + ")"
        msg['From'] = self.config["notifications"]["from"]
        toEmail = self.config["notifications"]["to"]
        msg['To'] = ','.join(toEmail)

        s = smtplib.SMTP(smtpserver, 587)
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login(SMTP_Username, SMTP_Password)
        s.sendmail(self.config["notifications"]["from"],
                   toEmail,
                   msg.as_string())
        s.quit()

    def dns_switchover(self):
        #update dns in the searchsax database
        print("Updating DNS in SearchStax DNS Records table")

        data = {'token': self.config["accessToken"],
              'account_name' : self.config["tenant"],
              'deployment' : self.config["drDeploymentId"]}
        try:
            vanityDNS = self.config["vanityDNS"]
            if vanityDNS.endswith(".searchstax.com"):
                vanityDNS = vanityDNS[:-len(".searchstax.com")]
            res = requests.patch(
                '%s/api/rest/v2/account/%s/dns-record/%s/' % (SEARCHSTAX_API,
                                      self.config["tenant"],
                                      vanityDNS),
                data=data
            )
            if res.status_code in [200, 201, 202]:
                print(res.content)
                json_content = json.loads(res.content)

                if "associated" in json_content and json_content["associated"] == True:
                    self.send_email()
            else:
                print ("Could not update DNS in SearchStax DNS Records table. Error code: " + str(res.status_code))
                print(res.content)
        except Exception as e:
            print ("Could not update DNS in SearchStax : %s" % e.message)




    def check_solr_triggers(self):
        count = 0
        numFailures = self.config["triggers"]["numFailures"]
        for triggerid in self.config["triggers"]["solr"]:
            val = self.monitor.get_value_of_trigger_id(triggerid)
            if val == "1":
                count += 1
                print(count)
                if count >= numFailures:
                    self.dns_switchover()
                    exit()

    def check_load_balancer_triggers(self):
        if self.config["triggers"]["loadBalancer"]:
            val = self.monitor.get_value_of_trigger_id(self.config["triggers"]["loadBalancer"])
            if val == "1":
                self.dns_switchover()
                exit()



if __name__ == '__main__':
    configFilename = sys.argv[1]
    drFailover = DRFailover(configFilename)
    drFailover.check_solr_triggers()
    drFailover.check_load_balancer_triggers()