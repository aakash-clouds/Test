# TBD

ansible-playbook ./playbooks/deployment-ss.yml --extra-vars "zookeeper_version=3.4.10 solr_version=5.1.0 solr_heap=1750m log_region=us-east-1 log_aws_access_key_id=AAAAAAAAAA log_aws_secret_access_key=BBBBBBBBBBBBBB tenant_id=362 deployment_id=802 deployment_uid=ss980382 log_bucket=ss-custdata-prod-default tenant_access_token=CCCCCCCCCCCCCCCCCC ssl_key=/home/ubuntu/STAR_measuredsearch_com.key ssl_crt=/home/ubuntu/STAR_measuredsearch_bundle_com.crt pulse_api=https://searchstax.measuredsearch.com/api/v1/metric/record/ zabbix_server=52.4.168.202"
