### SSH to the deploy-box

Before running any of the Ansible Playbooks, it is recommmended to test pinging to the server on which the configuration changes are to be done via:
```
ansible -i hosts --key-file "~/.ssh/searchstax-key.pem" -m ping all                                   # can change the parameter "all" with a specific host
```
For a successful ping(to one host) one must receive the below response:
```
host1 | SUCCESS => {
    "changed": false, 
    "ping": "pong"
}
```
This ensures that the playbook will run successfully on that host. From here one can proceed to executing the playbooks.

Make sure to add the ssh_public_key taken from the new user and copy-paste it in the empty space present between "COPY:CONTENT" module and "DEST" module of the create_user.yml script and save the script before running the playbook command.

Ex: 
```
- name: Accepting ssh public key
      copy:
         content: |

         dest: /home/{{ user }}/.ssh/authorized_keys
```
Also, if one wants to create a new user or lock an old one on one specific host, one must mention that host in the correct .yml file after referencing the host file itself for the right hostname.
Ex: If a new user is to be created on qa-jumphost, create_user.yml file should look like:
```
- hosts: ss-qa-jumphost 
```
and not,
```
- hosts: all
```
Same goes for lock_user.yml

The command for creating symlink in create_user.yml is only to be included while creating user on prod-jumphost. Same goes for the "sskey" group.

### Command for running Ansible Playbook for creating new user's on INFRA-servers:
```
ansible-playbook /etc/ansible/playbooks/create_user.yml --extra-vars "user_name=NAME_OF_THE_USER_TO_CREATE"
```

### Command for running Ansible Playbook for locking a user's account on INFRA-servers:
```
ansible-playbook /etc/ansible/playbooks/lock_user.yml --extra-vars "user_name=NAME_OF_THE_USER_TO_LOCK"
```

### Command for rotating azure password:
```
ansible-playbook /etc/ansible/playbooks/azure_pwd_rotate.yml --extra-vars "new_password=NEW_PASSWORD"
```

### Command for rotating searchstax infra keys: TBA(TO BE ADDED) "Make Sure to take backup of existing cfg file."
```
ansible-playbook rotate_searchstax_keys.yml --extra-vars "new_aws_access_id=TBA new_aws_secret_access_key=TBA new_aws_backup_creds=('TBA','TBA') new_aws_log_storage_access_key=TBA new_aws_log_storage_secret_key=TBA new_automation_pwd=TBA eastus=TBA centralus=TBA northcentralus=TBA southcentralus=TBA westus=TBA canadacentral=TBA northeurope=TBA uksouth=TBA ukwest=TBA southeastasia=TBA australiaeast=TBA australiasoutheast=TBA japaneast=TBA koreacentral=TBA eastus2=TBA westcentralus=TBA westus2=TBA canadaeast=TBA brazilsouth=TBA eastasia=TBA centralindia=TBA westindia=TBA southindia=TBA japanwest=TBA koreasouth=TBA westeurope=TBA francecentral=TBA”
```
