import json
import traceback
from datetime import datetime
from os import listdir
from os.path import isfile, join


class LogExtractor:
  def __init__(self):
    self.number_of_ok_requests = 0
    self.number_of_500_requests = 0
    self.number_of_400_requests = 0
    self.number_of_300_requests = 0
    self.total_number_of_requests = 0

    self.total_processing_time = 0
    self.max_response_time = 0
    self.max_response_size = 0
    self.max_response_size_query = ""
    self.max_response_time_query = ""
    self.client_ips = []

  def parseLine(self, line):
    pass

  def status_ok(self):
    if self.status_code == "200":
      return True
    return False

  def status_category(self):
    if self.status_code.startswith("2"):
      return "200"
    elif self.status_code.startswith("3"):
      return "300"
    elif self.status_code.startswith("4"):
      return "400"
    elif self.status_code.startswith("5"):
      return "500"
    else:
      return self.status_code

  def date_within(self, start_date, end_date):
    if self.date >= start_date and self.date <= end_date:
      return True
    return False

  def print_line(self):
    print(self.date)
    print(self.client, self.backend)
    print(self.request_processing_time, self.backend_processing_time,
          self.response_processing_time)
    print(self.status_code, self.backend_status_code)
    print(self.received_bytes, self.sent_bytes)
    print(self.request)
    print(self.request_method, self.request_collection)

  def print(self):
    print("200 OK: ", self.number_of_ok_requests)
    print("300 Redirects:", self.number_of_300_requests)
    print("400 requests:", self.number_of_400_requests)
    print("500 Errors:", self.number_of_500_requests)
    print("Total Requests:", self.total_number_of_requests)
    print("Total Processing time(msec):", self.total_processing_time)
    print("Max Response time(msec):", self.max_response_time)
    print("Max Response time query:", self.max_response_time_query)
    print("Max Response size (bytes):", self.max_response_size)
    print("Max Response size query:", self.max_response_size_query)
    print("Average Processing time(msec):", '{:.20f}'.format(
        self.total_processing_time / self.total_number_of_requests))
    print("Error Ratio in %:", '{:.20f}'.format(
        (self.number_of_500_requests / self.total_number_of_requests) * 100))
    print("Client IPs:", self.client_ips)

  def parseLogFile(self, filename, start_date=None, end_date=None, method=None,
      printLine=False, rows=0, bytes=0, errorsPrint=False):

    with open(filename, 'r', encoding='utf-8', errors='replace') as f:
      #print(filename)
      while True:
        line = f.readline()
        if not line:
          break

        if len(line) <= 0:
          continue

        self.parseLine(line)

        if method and extractor.request_method != method:
          continue

        if start_date and not extractor.date_within(start_date, end_date):
          continue

        self.total_number_of_requests += 1
        status_category = self.status_category()
        if status_category == "200":
          self.number_of_ok_requests += 1
        elif status_category == "300":
          self.number_of_300_requests += 1
        elif status_category == "400":
          self.number_of_300_requests += 1
        elif status_category == "500":
          self.number_of_500_requests += 1
        else:
          print("Got back status:", self.status_code, line)

        if not self.clientIP in self.client_ips:
          self.client_ips.append(self.clientIP)

        printLogLine = False
        if errorsPrint and self.status_category() != "200" and self.status_category() != "300":
          printLogLine = False
          print(line)

        if printLine:
          if (
              self.rows_requested > rows or self.rows_requested == -1) and self.received_bytes > bytes:
            printLogLine = True

        if printLogLine:
          print(self.date, self.backend, self.request_method, self.request,
                self.status_code,
                '{:.3f}'.format(self.response_processing_time),
                self.received_bytes, self.client)

        self.total_processing_time += self.response_processing_time
        if self.received_bytes > self.max_response_size:
          self.max_response_size = self.received_bytes
          self.max_response_size_query = line
        if self.response_processing_time > self.max_response_time:
          self.max_response_time = self.response_processing_time
          self.max_response_time_query = line


class AzureLogExtractor(LogExtractor):
  def parseDate(self, datetimeString):
    try:
      datetimeString = datetimeString.strip()
      x = datetime.strptime(datetimeString, "%Y-%m-%dT%H:%M:%SZ")
      return x
    except:
      try:
        x = datetime.strptime(datetimeString, "%Y-%m-%dT%H:%M:%S.%fZ")
        return x
      except:
        x = datetime.strptime(datetimeString, "%Y-%m-%dT%H:%M:%S.0%fZ")
        return x
    return None

  def parseLine(self, line):
    try:
      line_json = json.loads(line)
      self.date = self.parseDate(line_json["time"])
      props = line_json["properties"]
      self.client = props["clientIP"] + ":" + str(props["clientPort"])
      self.clientIP = props["clientIP"]
      request = props["requestQuery"]
      # if(request == "..."):
      #   print(line)

      idx = request.find("SERVER-ROUTED=") + len("SERVER-ROUTED=")
      end = request.find("&", idx)

      self.backend = request[idx: end]

      idx = request.find("&X-AzureApplicationGateway")
      request = request[0: idx]

      self.response_processing_time = props["timeTaken"]
      self.status_code = str(props["httpStatus"])
      self.received_bytes = props["receivedBytes"]
      self.sent_bytes = props["sentBytes"]

      self.request = props["requestUri"] + "?" + request
      self.request_method = props["httpMethod"]

      idx = request.find("rows=")
      if idx != -1:
        end = request.find("&", idx + 1)
        rows = int(request[idx + 5: end])
        self.rows_requested = rows
      else:
        self.rows_requested = -1

    except:
      print("Error parsing line")
      print(line)
      traceback.print_exc()


class AWSLogExtractor(LogExtractor):

  def parseLine(self, line):
    try:
      line_parts = line.split(" ")
      date_time = line_parts[0]
      self.date = datetime.strptime(date_time, "%Y-%m-%dT%H:%M:%S.%fZ")
      self.client = line_parts[2]
      self.clientIP = self.client.split(":")[0]
      self.backend = line_parts[3]

      self.response_processing_time = 0

      if (line_parts[4]) != "-":
        self.response_processing_time += float(line_parts[4]) * 1000

      if (line_parts[5]) != "-":
        self.response_processing_time += float(line_parts[5]) * 1000

      if (line_parts[6] != "-"):
        self.response_processing_time += float(line_parts[6]) * 1000

      self.status_code = line_parts[7]
      self.backend_status_code = line_parts[8]
      self.received_bytes = float(line_parts[9])
      self.sent_bytes = float(line_parts[10])
      self.request_method = line_parts[11][1:]
      self.request = line_parts[12]
      start = self.request.find(("/solr/")) + 6
      end = self.request.find("/", start)
      self.request_collection = self.request[start:end]

      idx = self.request.find("rows=")
      if idx != -1:
        end = self.request.find("&", idx + 1)
        rows = int(self.request[idx + 5: end])
        self.rows_requested = rows
      else:
        self.rows_requested = -1

    except:
      print("Error parsing line")
      print(line)


if __name__ == '__main__':

  # extractor = AWSLogExtractor()
  # start_date = datetime.strptime("2020-05-04T11:45:00Z", "%Y-%m-%dT%H:%M:%SZ")
  # end_date = datetime.strptime("2020-05-04T12:45:00Z", "%Y-%m-%dT%H:%M:%SZ")
  #
  # number_of_requests = 0
  # total_processing_time = 0
  #
  # number_of_obit_requests = 0
  # total_obit_processing_time = 0
  #
  # logpath = "/Users/dipsykapoor/Downloads/Legacy/May4"
  #
  # onlyfiles = [f for f in listdir(logpath) if isfile(join(logpath, f))]
  # for filename in onlyfiles:
  #   filename = logpath + "/" + filename
  #   with open(filename, 'r', encoding='utf-8', errors='replace') as f:
  #     print(filename)
  #     extractor.parseLogFile(filename, start_date, end_date, "GET", False)
  #     total_processing_time += extractor.total_processing_time
  #     number_of_requests += extractor.total_number_of_requests
  #
  # print("Total Processing time:")
  # print("Total time:", total_processing_time)
  # print("Number of requests:", number_of_requests)
  # print("Average:", '{:.20f}'.format(total_processing_time/number_of_requests))
  extractor = AzureLogExtractor()
  extractor = AWSLogExtractor()
  logpath = "/Users/dipsykapoor/Downloads/ware2go-prod"

  onlyfiles = [f for f in listdir(logpath) if isfile(join(logpath, f))]
  start_date = datetime.strptime("2020-05-21T11:30:00Z", "%Y-%m-%dT%H:%M:%SZ")
  end_date = datetime.strptime("2020-05-21T14:30:00Z", "%Y-%m-%dT%H:%M:%SZ")

  for filename in onlyfiles:
    if filename.endswith(".log") or filename.endswith(".json"):
      filename = logpath + "/" + filename
      # extractor.parseLogFile(filename, start_date=start_date, end_date=end_date, printLine=False, errorsPrint=False)
      extractor.parseLogFile(filename,
                             printLine=False, errorsPrint=True)

  print("========================================")
  print("          SUMMARY ")
  print("========================================")
  extractor.print()
