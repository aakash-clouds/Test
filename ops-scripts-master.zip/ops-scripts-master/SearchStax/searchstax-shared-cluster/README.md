# Provision Shared Cluster

## Ansible configuration

Ansible configuration is quite straight forward. You need ssh config file and modified /etc/ansible/ansible.cfg where you will modify this line:

```sh
ssh_args = -F /home/jsu/.ssh/config-ansible -C
```

The config file is like this:

```AsciiDoc
Host 18.195.85.248
    User ubuntu
    HostName 18.195.85.248
    IdentitiesOnly yes
    IdentityFile home/jsu/.ssh/crunchroot_rsa
    ControlMaster auto
    ControlPath /home/jsu/.ssh/mux-%r@%h:%p
    ControlPersist 15m

Host 10.77.*
    User jozef
    UserKnownHostsFile /dev/null
    StrictHostKeyChecking no
    ProxyCommand ssh -W %h:%p ubuntu@18.195.85.248
    IdentitiesOnly yes
    IdentityFile /home/jsu/.ssh/crunchroot_rsa

```

Always edit the config. `18.195.85.248` in this example is a jumphost to be used to access the provisioned machines. `10.77.*` is the address prefix you will use in your new vpc. Also change `IdentityFile` accordingly.

If you have direct access to the machines and you don't need bastion/jumphost, comment out the ProxyCommand in the second host config.

## First run (First cluster + VPC creation)

First step in each region is creating VPC. To do this, please follow next steps:

```sh
cd clusters
cp -a ../templates/region-template ./[my-region-id]
cd ./[my-region-id]
mv ./terraform.tfvars-tpl ./terraform.tfvars
```

Edit `terraform.tfvars` accordingly. *Make sure* you have unique CIDR per region and you *don't* use that CIDR anywhere else.

Edit `main.tf` and rename cluster_rename to your needs. Also change `name_prefix` inside that module.

```sh
terraform init
terraform plan -target=module.vpc
```

If everything looks fine, execute:

```sh
terraform apply -target=module.vpc
```

Wait until finished and once done, create VPC peering between the newly created VPC and the VPC where your bastion/jump host sits. Also create required routes in route tables between sharedclusters private route table and the route table where bastion is present.

Once done, continue:

```sh
terraform plan -target=module.[my-cluster-name]
terraform apply -target=module.[my-cluster-name]
```

**DO NOT RUN terraform without `-target`**

When done, you need to execute ansible script by following:

```sh
TF_MODULE=[tf-module-name-of-my-cluster] ansible-playbook --inventory-fil
e=../../ansible/tf_inventory.py ../../ansible/shared-cluster.yml --extra-vars "solr_version=[solr-version] zookeeper_version=[zookeeper-version] solr_heap=[solr-heap-size]"
```

## More clusters

for more clusters. edit `main.tf` and copy the cluster module, rename the module and modify name_prefix. perform

```sh
terraform plan -target=module.[my-second-cluster-name]
terraform apply -target=module.[my-second-cluster-name]
```

After done, just modify `TF_MODULE` in the ansible-playbook call to fit your [my-second-cluster-name]

## Next Steps

Go to SearchStax ssadmin, create new SharedCluster and don't forget to fill up all instances by roles

## Additional information

### Instance Tags

Each EC2 instance has multiple tags configured:

- Cluster
- Environment
- Group
- Name
- Node
- Role

Example for cluster with name cluster1 and one of haproxy nodes:
tag:Cluster = cluster1
tag:Environment = dev
tag:Group = sharedclusters
tag:Name = cluster1-haproxy-0
tag:Node = 0
tag:Role = haproxy

### Used Apps

- Ansible version 2.4.1.0 was used, so it's suggested to use this or higher
- Terraform 0.11.0 was used, so it's suggested to use this or higher
- Python 2.7 is required for ts_inventory.py file