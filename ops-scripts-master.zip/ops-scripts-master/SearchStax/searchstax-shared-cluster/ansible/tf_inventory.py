#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import os

def get_input():
    """
    Take state file path and module to be filtered
    """
    try:
        tf_state = os.environ['TF_STATE']
    except:
        tf_state = './terraform.tfstate'
    try:
        tf_module = os.environ['TF_MODULE']
    except:
        raise Exception("use TF_MODULE, you can process up to one module at a time")

    return (tf_state, tf_module)

def process_resources(resources):
    """
    Generate inventory dictionary, convert to string and return
    """
    inventory = {'_meta': {'hostvars': {}}}
    # all
    # group_sharedclusters
    # role_zookeeper
    # role_solr
    # role_haproxy
    for key, val in resources.iteritems():
        if val['type'] == 'aws_instance':
            private_ip = val['primary']['attributes']['private_ip']
            host_vars = {}
            if val['primary']['attributes']['tags.Group']:
                group_tag = 'group_%s' % val['primary']['attributes']['tags.Group']
                if group_tag not in inventory:
                    inventory[group_tag] = []
                inventory[group_tag].append(private_ip)
                host_vars['group'] = val['primary']['attributes']['tags.Group']
            if val['primary']['attributes']['tags.Node']:
                node_tag = 'node_%s' % val['primary']['attributes']['tags.Node']
                if node_tag not in inventory:
                    inventory[node_tag] = []
                inventory[node_tag].append(private_ip)
                host_vars['node'] = val['primary']['attributes']['tags.Node']
            if val['primary']['attributes']['tags.Role']:
                role_tag = 'role_%s' % val['primary']['attributes']['tags.Role']
                if role_tag not in inventory:
                    inventory[role_tag] = []
                inventory[role_tag].append(private_ip)
                host_vars['role'] = val['primary']['attributes']['tags.Role']
            if val['primary']['attributes']['tags.Name']:
                name_tag = 'name_%s' % val['primary']['attributes']['tags.Name']
                if name_tag not in inventory:
                    inventory[name_tag] = []
                inventory[name_tag].append(private_ip)
                host_vars['name'] = val['primary']['attributes']['tags.Name']
            if host_vars:
                inventory['_meta']['hostvars'][private_ip] = host_vars

    return json.dumps(inventory)


def parse_json(tf_state, tf_module):
    """
    Load file, convert to dictionary
    """
    try:
        data = json.loads(open(tf_state).read())
    except Exception as exc:
        raise Exception("loading tfstate file failed: %s", exc)

    for module in data['modules']:
        if tf_module in module['path']:
            return process_resources(module['resources'])


def main():
    """
    Execute inventory generator
    """
    (tf_state, tf_module) = get_input()
    if not os.path.isfile(tf_state):
        raise Exception("tfstate file is invalid")

    inventory = parse_json(tf_state, tf_module)
    print inventory

if __name__ == '__main__':
    main()
