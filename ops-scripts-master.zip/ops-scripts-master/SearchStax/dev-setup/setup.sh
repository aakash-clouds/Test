#!/bin/bash

# Setup dev environment
# Assumes mac
# Assumes code is checked out and a dev branch has been created
# Arguments:
#   profile of a setup
# The profile of a setup corresponds to a directory of the form configs/<profile>
# That directory has 2 files
# public-config.sh
# private-config.sh

if [ "$#" -ne 1 ]; then
  echo "Usage: setup.sh <profile>"
  exit 1
fi

profile=$1

scriptdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
confdir="$scriptdir/configs/$profile"

source $confdir/public-config.sh
source $confdir/private-config.sh
echo "ssdir is $ssdir"

pushd $ssdir
branch=$(git branch|grep '*'|cut -d ' ' -f2)
popd

echo "branch is $branch"

# wipe out sqlite and mongo
rm -f $ssdir/$branch.sqlite3
sed s/BRANCH_NAME/$branch/ clean_mongo.in > clean_mongo
mongo < clean_mongo

#virtualenv -p /Library/Frameworks/Python.framework/Versions/2.7/bin/python2 $envdir/$branch
#source $envdir/$branch/bin/activate
#pip install -r $ssdir/requirements.txt

mv ~/.searchstax-settings.cfg ~/.searchstax-settings.cfg.bak
sudo cp $ssdir/deploy/searchstax-settings.cfg.dev ~/.searchstax-settings.cfg
cp $ssdir/deploy/automation_settings_dev.py $ssdir/searchstax/automation_settings.py
cp $ssdir/deploy/local_settings_dev.py $ssdir/searchstax/local_settings.py

sed -i.bak "s#PATH_TO_SS_PK_TBD#$path_to_ss_pk#" $ssdir/searchstax/automation_settings.py
sed -i.bak "s/AWS_KEY_NAME_TBD/$aws_key_name/" $ssdir/searchstax/automation_settings.py
sed -i.bak "s/AWS_ANALYTICS_SG_TBD/$aws_analytics_sg/" $ssdir/searchstax/automation_settings.py
sed -i.bak "s/AWS_ANALYTICS_SUBNET_TBD/$aws_analytics_subnet/" $ssdir/searchstax/automation_settings.py

sed -i.bak s/BRANCH-TBD/$branch/ $ssdir/searchstax/local_settings.py

sudo sed -i.bak s/AWS_ACCESS_KEY_ID_TBD/$aws_access_key_id/ ~/.searchstax-settings.cfg
sudo sed -i.bak s/AWS_SECRET_ACCESS_KEY_TBD/$aws_secret_access_key/ ~/.searchstax-settings.cfg

pushd $ssdir
./manage.py makemigrations
./manage.py migrate
./manage.py loaddata searchstax/application/fixtures/initial_data.json
./manage.py loaddata searchstax/application/fixtures/cloud_provider.json
./manage.py loaddata searchstax/application/fixtures/metrics.json
./manage.py loaddata searchstax/application/fixtures/regions.json
./manage.py loaddata searchstax/application/fixtures/plans.json
./manage.py loaddata searchstax/application/fixtures/solr_versions.json

./manage.py createsuperuser
# e.g., use eric@measuredsearch.com/admin
popd
