aws_access_key_id="AKIAJSM2TXI6YXUYIKGA" # ms dev
ssdir=~/Documents/code/searchstax
envdir=~/Documents/virtualenvs
aws_key_name=searchstax-dev
path_to_ss_pk=~/keys/searchstax-dev.pem
aws_analytics_sg=sg-03b65d64 # wide open
aws_analytics_subnet=subnet-509c6708