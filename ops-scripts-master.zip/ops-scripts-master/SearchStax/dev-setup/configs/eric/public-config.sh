aws_access_key_id="AKIAJBUKDXENSBC7X6DQ" # ms prod
ssdir=~/Documents/code/searchstax
envdir=~/virtualenvs
aws_key_name=searchstax
path_to_ss_pk=/Users/eric/keys/searchstax.pem
aws_analytics_sg=sg-c89bc4ad
aws_analytics_subnet=subnet-d3b0a7fb