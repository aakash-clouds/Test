aws ec2 run-instances \
   --image-id ami-80861296 \
   --key-name searchstax \
   --user-data file://instance_setup.sh \
   --count 1 \
   --instance-type t2.small \
   --profile ms-prod-jenkins \
   --subnet-id=subnet-b404f3ed
#   --security-group-ids ms-staging \
#   --network-interfaces NetworkInterfaceId=eni-5bd34480,DeviceId=NetworkInterfaceId,SubnetId=subnet-b404f3ed

