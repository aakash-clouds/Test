#!/bin/bash

GIT_KEYFILE=~/keys/id_ssprod_rsa
SS_KEYFILE=~/keys/searchstax.pem

cat instance_setup.sh.in.1 $GIT_KEYFILE instance_setup.sh.in.2 $SS_KEYFILE instance_setup.sh.in.3 > instance_setup.sh
chmod 755 instance_setup.sh
