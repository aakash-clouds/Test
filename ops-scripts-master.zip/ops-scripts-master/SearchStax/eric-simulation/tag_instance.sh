echo "Tagging instance $1"

aws ec2 create-tags \
   --resources $1 \
   --tags Key=Name,Value=eric-simulation-searchstax \
   --profile ms-prod-jenkins
