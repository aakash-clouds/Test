#!/bin/bash

branch=$1

echo "installing SearchStax for $branch..."

bin=/var/lib/jenkins/.local/bin
source ~/virtualenvs/env-py3/bin/activate
./make_instance_setup.sh $branch
./master_setup.sh $branch
