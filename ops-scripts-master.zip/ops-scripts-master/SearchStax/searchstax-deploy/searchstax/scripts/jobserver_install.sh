#!/bin/bash

until ping -c1 www.google.com &>/dev/null; do :; done
sudo dpkg -l|grep -i nginx
sudo apt-get -qq update
sudo DEBIAN_FRONTEND=noninteractive apt-get upgrade -qq -y
sudo apt-get -qq -y install git