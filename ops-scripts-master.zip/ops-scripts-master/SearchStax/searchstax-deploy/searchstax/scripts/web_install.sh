#!/bin/bash

until ping -c1 www.google.com &>/dev/null; do :; done
sudo dpkg -l|grep -i nginx
sudo apt-get -qq update
sudo DEBIAN_FRONTEND=noninteractive apt-get upgrade -qq -y
sudo apt-get -qq -y install nginx nginx-common nginx-core uwsgi git
sudo mv /tmp/nginx.conf /etc/nginx/nginx.conf
sudo chown www-data:www-data /etc/nginx/nginx.conf
sudo ls /etc/nginx/sites-available/
sudo mv /tmp/searchstax /etc/nginx/sites-available/
sudo ln -s /etc/nginx/sites-available/searchstax /etc/nginx/sites-enabled/searchstax
sudo mv /tmp/searchstax.service /etc/systemd/system/searchstax.service
sudo mv /tmp/searchstax.ini /opt/searchstax/
sudo chown searchstax:searchstax /opt/searchstax/searchstax.ini