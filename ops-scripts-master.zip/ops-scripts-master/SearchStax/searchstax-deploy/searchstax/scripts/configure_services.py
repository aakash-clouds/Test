#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Once terraform finished, this script will take IPs as input to configure
- Analytics MongoDB
- Pulse MongoDB
- local_settings.py for SearchStax
"""

import hashlib
import json
import os
from os.path import isfile
import yaml
import random
import string
import subprocess

CONFIG_STATE = './postconfig.json'
CONFIG_FILE = './settings.yml'
TF_STATE = './terraform.tfstate'
ENVIRONMENT = None

HOSTS_MONGODBS = []
BASTION_HOST = ''
SSH_USER = None
SSH_PRIVATE_KEY = None
SEARCHSTAX_BASE_DIR = None
HIGH_AVAILABILITY = None
DEPLOYMENT_DNS_ZONE = None

DJANGO_USERMAIL = None
DJANGO_USERPASS = None


CFG_KEYS = [
    'AWS_ACCESS_KEY_ID',
    'AWS_SECRET_ACCESS_KEY',
    'AWS_BACKUP_CREDENTIALS',
    'LOG_STORAGE_ACCESS_KEY',
    'LOG_STORAGE_SECRET_KEY',
    'BRAINTREE_MERCHANT_ID',
    'BRAINTREE_PUBLIC_KEY',
    'BRAINTREE_PRIVATE_KEY',
    'ZABBIX_USER',
    'ZABBIX_PASSWORD',
    'DATABASES',
    'MONGODB_URL',
    'MONGO_BACKUP_DBUSER',
    'MONGO_BACKUP_DBPASS',
    'PULSEDB_URL',
    'PULSEDB_BACKUP_DBUSER',
    'PULSEDB_BACKUP_DBPASS',
    'ENCAWS_KEY'
]

FNULL = open(os.devnull, 'w')


def read_state(key):
    """
    Read value from state file
    """
    if isfile(CONFIG_STATE):
        data = json.loads(open(CONFIG_STATE).read())
        if key in data:
            return data[key]
    return None


def manage_state(key, val):
    """
    Manage state file where database passwords are stored
    """
    if isfile(CONFIG_STATE):
        try:
            data = json.loads(open(CONFIG_STATE).read())
        except ValueError:
            data = {}
    else:
        data = {}
    data[key] = val
    with open(CONFIG_STATE, 'w') as outfile:
        outfile.write(json.dumps(data))


def generate_password(pwdlen=10):
    """
    Generate and return random string for password use
    """
    return ''.join(random.SystemRandom().choice(
        string.ascii_uppercase + string.digits) for _ in range(pwdlen))


def generate_enc_key():
    """
    Generate 32 bytes long encryption key
    """
    return hashlib.sha256(generate_password(pwdlen=20)).hexdigest()[:32].encode('hex')


def remote_exec(host, command=None, inputs=[]):
    """
    Execute remote commands
    """
    ssh_cmd = "/usr/bin/ssh -o ServerAliveInterval=600 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o GlobalKnownHostsFile=/dev/null -t -i %s -o ProxyCommand='/usr/bin/ssh -o ServerAliveInterval=600 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o GlobalKnownHostsFile=/dev/null -i %s -W %%h:%%p %s@%s' %s@%s" % (
        SSH_PRIVATE_KEY, SSH_PRIVATE_KEY, SSH_USER, BASTION_HOST, SSH_USER, host)
    proc = subprocess.Popen(
        '%s %s' % (ssh_cmd, command) if command else ssh_cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=True
    )
    if inputs:
        for line in inputs:
            proc.stdin.write(line)
            proc.stdin.flush()
    stdout, stderr = proc.communicate()
    return (proc.returncode, stdout, stderr)


def init_etc_hosts(nodes):
    """
    Init HOSTS_MONGODBS list of /etc/hosts records
    """
    global HOSTS_MONGODBS
    for node in nodes:
        host_record = '%s %s' % node
        HOSTS_MONGODBS.append(host_record)


def read_rds():
    """
    Read RDS settings from terraform tfstate file
    """
    data = json.loads(open(TF_STATE).read())
    modules = data['modules']
    for module in modules:
        if 'path' in module and len(module['path']) > 1 and module['path'][1] == 'data-storages':
            resource = module['resources']['aws_db_instance.searchstax-rds']['primary']['attributes']
            manage_state('db_address', resource['address'])
            manage_state('db_user', resource['username'])
            manage_state('db_password', resource['password'])
            manage_state('db_name', resource['name'])
            return True
    raise Exception("RDS state not found in terraform.tfstate")


def read_ips():
    """
    Read terraform state and prepare list of ip addresses required for configuration
    """
    ips = {}
    data = json.loads(open(TF_STATE).read())
    modules = data['modules']
    # data_storages_outputs = [
    #     'rds_endpoint',
    #     'analytics_data_nodes',
    #     'analytics_arb_nodes',
    #     'pulse_data_nodes',
    #     'pulse_arb_nodes'
    # ]
    services_outputs = ['web_nodes', 'jobserver_nodes']
    for module in modules:
        path = module['path']
        if len(path) > 1 and path[0] == 'root':
            if path[1] == 'vpc':
                if 'bastion_host' in module['outputs']:
                    ips['bastion_host'] = module['outputs']['bastion_host']['value']
                else:
                    raise Exception("No bastion_host found in %s", TF_STATE)
                nat_gw = module['resources']['aws_nat_gateway.searchstax-nat']['primary']['attributes']['public_ip']
                manage_state('nat_ip', nat_gw)
                global HIGH_AVAILABILITY
                HIGH_AVAILABILITY = True if module['outputs']['high_availability']['value'] == "1" else False
            elif path[1] == 'data-storages':
                analyticsdb_data_prefix = 'aws_instance.searchstax-analyticsdb-data'
                analyticsdb_arb_prefix = 'aws_instance.searchstax-analyticsdb-arb'
                pulsedb_data_prefix = 'aws_instance.searchstax-pulsedb-data'
                pulsedb_arb_prefix = 'aws_instance.searchstax-pulsedb-arb'
                keys = module['resources'].keys()
                ips['analytics_data_nodes'] = []
                ips['analytics_arb_nodes'] = []
                ips['pulse_data_nodes'] = []
                ips['pulse_arb_nodes'] = []
                for key in keys:
                    module_shortcut = module['resources'][key]['primary']['attributes']
                    if analyticsdb_data_prefix in key:
                        ips['analytics_data_nodes'].append((
                            module_shortcut['private_ip'],
                            module_shortcut['tags.Name']
                        ))
                    elif analyticsdb_arb_prefix in key:
                        ips['analytics_arb_nodes'].append((
                            module_shortcut['private_ip'],
                            module_shortcut['tags.Name']
                        ))
                    elif pulsedb_data_prefix in key:
                        ips['pulse_data_nodes'].append((
                            module_shortcut['private_ip'],
                            module_shortcut['tags.Name']
                        ))
                    elif pulsedb_arb_prefix in key:
                        ips['pulse_arb_nodes'].append((
                            module_shortcut['private_ip'],
                            module_shortcut['tags.Name']
                        ))
                # for output in data_storages_outputs:
                #     if output not in module['outputs']:
                #         raise Exception("No %s found in %s", output, TF_STATE)
                #     ips[output] = module['outputs'][output]['value']
            elif path[1] == 'services':
                for output in services_outputs:
                    if output not in module['outputs']:
                        raise Exception("No %s found in %s", output, TF_STATE)
                    ips[output] = module['outputs'][output]['value']
            elif path[1] == 'dns':
                pass
            else:
                raise Exception("Unknown path %s found, you need to update the code", path)
    return ips


def add_etc_hosts(node):
    # /etc/hosts
    add_hosts = False
    inputs = []
    for host in HOSTS_MONGODBS:
        inputs.append("grep '%s' /etc/hosts\n" % host)
    returncode, stdout, stderr = remote_exec(node, command='bash', inputs=inputs)
    if returncode == 0:
        found = 0
        splitout = stdout.splitlines()
        for line in splitout:
            if line in HOSTS_MONGODBS:
                found += 1
        if found >= len(HOSTS_MONGODBS):
            pass
        else:
            add_hosts = True
    else:
        add_hosts = True
    if add_hosts:
        returncode, stdout, stderr = remote_exec(
            node,
            command="sudo tee -a /etc/hosts",
            inputs=[
                '%s\n' % '\n'.join(HOSTS_MONGODBS)
            ]
        )
        print "Adding /etc/hosts records to %s returned %s" % (node, returncode)


def configure_mongodb(data_nodes, arbiter_nodes, rs_type='analytics'):
    """
    Configure MongoDB replica set for Analytics or Pulse
    """
    if rs_type not in ['analytics', 'pulse']:
        raise Exception("Unknown MongoDB type %s", rs_type)
    print "Configuring MongoDB for %s" % rs_type
    host_record = ''
    local_mongodbs = []
    for node in data_nodes + arbiter_nodes:
        host_record = '%s %s' % node
        local_mongodbs.append(host_record)
    # update /etc/hosts, create keyfile
    keyfile = subprocess.check_output(['openssl', 'rand', '-base64', '756'])
    print "Updating hosts"
    for node in data_nodes + arbiter_nodes:
        # /etc/hosts
        add_hosts = False
        inputs = []
        for host in local_mongodbs:
            inputs.append("grep '%s' /etc/hosts\n" % host)
        returncode, stdout, stderr = remote_exec(node[0], command='bash', inputs=inputs)
        if returncode == 0:
            found = 0
            splitout = stdout.splitlines()
            for line in splitout:
                if line in local_mongodbs:
                    found += 1
            if found >= len(local_mongodbs):
                pass
            else:
                add_hosts = True
        else:
            add_hosts = True
        if add_hosts:
            returncode, stdout, stderr = remote_exec(
                node[0],
                command="sudo tee -a /etc/hosts",
                inputs=[
                    '%s' % '\n'.join(local_mongodbs)
                ]
            )
            print "Adding /etc/hosts records returned %s" % returncode

        # cloud-init is unreliable, check if mongodb was installed
        returncode, stdout, stderr = remote_exec(node[0], command="ls /usr/bin/mongod")
        if returncode != 0:
            print stdout
            print stderr
            raise Exception("MongoDB is not installed on %s", node[0])
        # keyfile
        returncode, stdout, stderr = remote_exec(node[0], command="sudo ls -l /etc/mongod.k")
        if returncode != 0:
            returncode, stdout, stderr = remote_exec(
                node[0],
                command="\"echo '%s' | sudo tee /etc/mongod.k\"" % keyfile
            )
            if returncode != 0:
                raise Exception("Creating /etc/mongod.k failed on %s", node[0])
        returncode, stdout, stderr = remote_exec(
            node[0],
            command=None,
            inputs=[
                "sudo chown mongodb:mongodb /etc/mongod.k\n"
                "sudo chmod 400 /etc/mongod.k\n"
            ]
        )
        if returncode != 0:
            raise Exception("Changing ownership of /etc/mongod.k failed on %s", node[0])
        returncode, stdout, stderr = remote_exec(
            node[0],
            command="sudo service mongod restart"
        )
        if returncode != 0:
            print stdout
            print stderr
            raise Exception("Restarting mongod failed on %s", node[0])


    # configure replica set
    # execute rs.initiate() on first data node
    # check if mongo is running and accessible without auth
    first_node = data_nodes[0][0]
    returncode, stdout, stderr = remote_exec(
        first_node,
        command="mongo --quiet",
        inputs=[
            "rs.status()\n"
        ]
    )
    configure_users = True
    configure_replicaset = False
    try:
        response_data = json.loads(stdout)
    except ValueError:
        response_data = {}
        configure_replicaset = True
    if returncode == 0 and 'codeName' in response_data and response_data['codeName'] == 'Unauthorized':
        print "Seems like %s replica set is already configured, skipping" % rs_type
        configure_users = False
    elif returncode == 0 and 'codeName' in response_data and response_data['codeName'] == 'NotYetInitialized':
        configure_replicaset = True
    if HIGH_AVAILABILITY:
        print "Configuring replicaset"
        if configure_replicaset:
            print "Configuration of replica set %s started" % rs_type
            # if it's accessible without auth, check if replica set is configured
            # if it's not configured, initiate
            config_obj = {
                '_id': 'rs0',
                'members': []
            }
            member_id = 0
            for node in data_nodes:
                config_obj['members'].append({
                    '_id': member_id,
                    'host': '%s:27017' % node[1]
                })
                member_id += 1
            for node in arbiter_nodes:
                config_obj['members'].append({
                    '_id': member_id,
                    'host': '%s:27017' % node[1],
                    'arbiterOnly': True
                })
            config_string = json.dumps(config_obj)

            returncode, stdout, stderr = remote_exec(
                first_node,
                command="mongo --quiet",
                inputs=[
                    "use admin\n",
                    "rs.initiate(%s)\n" % config_string
                ]
            )
            response = json.loads(''.join(stdout.splitlines()[1:]))
            if response['ok'] == 0 and response['codeName'] != 'AlreadyInitialized':
                print response

            returncode, stdout, stderr = remote_exec(
                node[0],
                command="\"sudo sed -i \'s/#replication/replication/\' /etc/mongod.conf\""
            )
            if returncode != 0:
                raise Exception("Uncommenting replication failed on %s", node[0])

            returncode, stdout, stderr = remote_exec(
                node[0],
                command="\"sudo sed -i \'s/# replSetName/  replSetName/\' /etc/mongod.conf\""
            )
            if returncode != 0:
                raise Exception("Uncommenting replSetName failed on %s", node[0])

    if configure_users:
        if HIGH_AVAILABILITY:
            mongo_opts = '?replicaSet=rs0'
        else:
            mongo_opts = ''
        connection_string = ','.join(['%s:27017' % x[1] for x in data_nodes])
        root_user_pwd = read_state('%s-%s-password' % (rs_type, 'root'))
        if not root_user_pwd:
            root_user_pwd = generate_password()
            manage_state('%s-%s-password' % (rs_type, 'root'), root_user_pwd)
        user_root = {
            'user': 'root',
            'pwd': root_user_pwd,
            'roles': ['root']
        }
        db_name = 'analytics' if rs_type == 'analytics' else 'pulse'
        db_name += '-%s' % ENVIRONMENT
        db_user = 'analytics' if rs_type == 'analytics' else 'pulse'
        db_user_pwd = read_state('%s-%s-password' % (rs_type, db_user))
        if not db_user_pwd:
            db_user_pwd = generate_password()
            manage_state('%s-%s-password' % (rs_type, db_user), db_user_pwd)
        user_db = {
            'user': db_user,
            'pwd': db_user_pwd,
            'roles': [{'role': 'readWrite', 'db': db_name}],
        }
        # check if users exist
        find_user_tpl = 'db.system.users.find({"user": "%s"}).count()'
        returncode, stdout, stderr = remote_exec(
            first_node,
            command="mongo --quiet 'mongodb://%s/admin%s'" % (connection_string, mongo_opts),
            inputs=[
                "use admin\n",
                find_user_tpl % "root"
            ]
        )
        if returncode != 0:
            print returncode
            print stdout
            print stderr
            raise Exception("Looking for user %s failed", "root")
        user_found = True if stdout.splitlines()[-1] == '1' else False
        if user_found:
            print "User root found"
        else:
            returncode, stdout, stderr = remote_exec(
                first_node,
                command="mongo --quiet 'mongodb://%s/admin%s'" % (connection_string, mongo_opts),
                inputs=[
                    "use admin\n",
                    "db.createUser(%s)\n" % json.dumps(user_root)
                ]
            )
            if returncode != 0:
                raise Exception("Creating user root failed")

        returncode, stdout, stderr = remote_exec(
            first_node,
            command="mongo --quiet 'mongodb://%s/admin%s'" % (connection_string, mongo_opts),
            inputs=[
                "use admin\n",
                find_user_tpl % db_user
            ]
        )
        if returncode != 0:
            raise Exception("Looking for user %s failed", db_user)
        user_found = True if stdout.splitlines()[-1] == '1' else False
        if user_found:
            print "User %s found" % db_user
        else:
            returncode, stdout, stderr = remote_exec(
                first_node,
                command="mongo --quiet 'mongodb://%s/admin%s'" % (connection_string, mongo_opts),
                inputs=[
                    "use %s\n" % db_name,
                    "db.createUser(%s)\n" % json.dumps(user_db)
                ]
            )
            if returncode != 0:
                print stdout
                print stderr
                raise Exception("Creating user %s failed", user_db)
            returncode, stdout, stderr = remote_exec(
                first_node,
            )
        returncode, stdout, stderr = remote_exec(
            first_node,
            command="mongo --quiet 'mongodb://%s/admin%s'" % (connection_string, mongo_opts),
            inputs=[
                "use %s\n" % db_name,
                "db.auth('%s', '%s')\n" % (db_user, db_user_pwd)
            ]
        )
        if returncode != 0:
            print stdout
            print stderr
            raise Exception("User creation failed on %s\n", first_node)

        # enable mongodb authentication
        for node in data_nodes + arbiter_nodes:
            returncode, stdout, stderr = remote_exec(
                node[0],
                command="\"sudo sed -i \'s/#security/security/\' /etc/mongod.conf\""
            )
            if returncode != 0:
                raise Exception("enabling security in mongod.conf failed for %s", node[0])
            returncode, stdout, stderr = remote_exec(
                node[0],
                command="\"sudo sed -i \'s/#  keyFile/  keyFile/\' /etc/mongod.conf\""
            )
            if returncode != 0:
                raise Exception("enabling security in mongod.conf failed for %s", node[0])
            # reload service
            returncode, stdout, stderr = remote_exec(node[0], command="sudo service mongod restart")
            if returncode != 0:
                raise Exception("Restarting MongoDB on %s failed" % node[0])


def configure_git(node, user='searchstax'):
    """
    Upload file and set ownership and permissions
    """
    dest_key_file = '/home/%s/.ssh/id_rsa' % user
    dest_config_file = '/home/%s/.ssh/config' % user
    ssh_config = "Host github.com\n  User git\n  IdentityFile %s\n\n" % dest_key_file

    key = open(read_state('git_keyfile')).read()
    returncode, stdout, stderr = remote_exec(
        node,
        command='sudo ls /home/%s/.ssh' % user
    )
    if returncode != 0:
        returncode, stdout, stderr = remote_exec(
            node,
            command="bash",
            inputs=[
                "sudo mkdir -p /home/%s/.ssh\n" % user,
                "sudo touch %s\n" % dest_key_file,
                "sudo chown -R %s /home/%s/.ssh\n" % (user, user),
                "sudo chmod 700 /home/%s/.ssh\n" % user
            ]
        )

    returncode, stdout, stderr = remote_exec(
        node,
        command="\"echo '%s' | sudo tee %s\"" % (key, dest_key_file)
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("uploading keyfile to %s failed on %s", dest_key_file, node)
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo chmod 400 %s\n" % dest_key_file,
            "sudo chown %s %s\n" % (user, dest_key_file)
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("changing ownership/permissions on %s failed %s", dest_key_file, node)
    returncode, stdout, stderr = remote_exec(
        node,
        command="\" echo '%s' | sudo tee %s\"" % (ssh_config, dest_config_file)
    )
    if returncode != 0:
        raise Exception("uploading ssh config to %s failed on %s", dest_config_file, node)
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo chmod 600 %s\n" % dest_config_file,
            "sudo chown %s %s\n" % (user, dest_config_file)
        ]
    )
    if returncode != 0:
        raise Exception("changing ownership/permissions on %s failed %s", dest_config_file, node)


def configure_git_repo(node, user='searchstax'):
    """
    Do initial pull
    """
    git_base_dir = '%s/app' % SEARCHSTAX_BASE_DIR
    returncode, stdout, stderr = remote_exec(
        node,
        command="ls -l %s" % git_base_dir
    )
    if returncode != 0:
        returncode, stdout, stderr = remote_exec(
            node,
            command="bash",
            inputs=[
                "sudo mkdir -p %s\n" % git_base_dir,
                "sudo chown %s %s\n" % (user, git_base_dir)
            ]
        )
        if returncode != 0:
            raise Exception("creating %s failed on %s", git_base_dir, node)
    returncode, stdout, stderr = remote_exec(
        node,
        command="ls -l %s/searchstax" % git_base_dir
    )
    if returncode == 0:
        print "searchstax repo directory already exist on %s" % node
    else:
        returncode, stdout, stderr = remote_exec(
            node,
            command="bash",
            inputs=[
                "sudo su - %s\n" % user,
                "cd %s\n" % git_base_dir,
                "GIT_SSH_COMMAND=\"ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=~/.ssh/known_hosts -o GlobalKnownHostsFile=~/.ssh/known_hosts\" git clone %s\n" % read_state('git_repo'),
            ]
        )
        if returncode != 0:
            print stdout
            print stderr
            raise Exception("searchstax git clone failed on %s", node)
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo su - %s\n" % user,
            "cd %s/searchstax\n" % git_base_dir,
            "git reset --hard\n",
            "git checkout %s\n" % read_state('git_branch'),
            "git pull"
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("Changing branch failed on %s\n", node)
    # searchstax-client
    returncode, stdout, stderr = remote_exec(
        node,
        command="ls -l %s/searchstax-client" % git_base_dir
    )
    if returncode == 0:
        print "searchstax-client repo directory already exist on %s" % node
    else:
        returncode, stdout, stderr = remote_exec(
            node,
            command="bash",
            inputs=[
                "sudo su - %s\n" % user,
                "cd %s\n" % git_base_dir,
                "git clone %s\n" % read_state('git_searchstax_client_repo'),
                "cd searchstax-client\n"
            ]
        )
        if returncode != 0:
            print stdout
            print stderr
            raise Exception("searchstax-client git clone failed on %s", node)



def copy_searchstax_settings(node, user='searchstax'):
    """
    Copy automation and local setting
    """
    ss_base_dir = '%s/app/searchstax' % SEARCHSTAX_BASE_DIR
    returncode, stdout, stderr = remote_exec(
        node,
        command='sudo cp -rf %s/deploy/automation_settings_autodeploy.py %s/searchstax/automation_settings.py' % (
            ss_base_dir,
            ss_base_dir
        )
    )
    if returncode != 0:
        raise Exception("copying automation_settings failed on %s", node)
    returncode, stdout, stderr = remote_exec(
        node,
        command='sudo chown %s %s/searchstax/automation_settings.py' % (
            user, ss_base_dir)
    )
    if returncode != 0:
        raise Exception("changing ownership of automation_settings failed on %s", node)

    returncode, stdout, stderr = remote_exec(
        node,
        command='sudo cp -rf %s/deploy/local_settings_autodeploy.py %s/searchstax/local_settings.py' % (
            ss_base_dir,
            ss_base_dir
        )
    )
    if returncode != 0:
        raise Exception("copying local_settings failed on %s", node)
    returncode, stdout, stderr = remote_exec(
        node,
        command="sudo chown %s %s/searchstax/local_settings.py" % (
            user, ss_base_dir)
    )
    if returncode != 0:
        raise Exception("changing ownership of local_settings failed on %s", node)

    # change settings
    replace_to = "config_file\ \=\ \\\'%s/.searchstax-settings.cfg\\\'" % SEARCHSTAX_BASE_DIR
    returncode, stdout, stderr = remote_exec(
        node,
        command="sudo sed -i \"s@^config_file\ \=.*@%s@\" %s/searchstax/local_settings.py" % (
            replace_to, ss_base_dir)
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("failed modifying local_settings on %s", node)
    returncode, stdout, stderr = remote_exec(
        node,
        command="sudo sed -i \"s@REPLACE_ENVIRONMENT@%s@\" %s/searchstax/local_settings.py" % (
            ENVIRONMENT, ss_base_dir
        )
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("Failed on %s", node)

    returncode, stdout, stderr = remote_exec(
        node,
        command="sudo sed -i \"s@REPLACE_DOMAIN@%s@\" %s/searchstax/local_settings.py" % (
            DEPLOYMENT_DNS_ZONE,
            ss_base_dir,
        )
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("replacing domain failed on %s", node)

    # searchstax pem
    priv_key = open(read_state('ss_pk_source')).read()
    returncode, stdout, stderr = remote_exec(
        node,
        command="\"echo '%s' | sudo tee %s\"" % (priv_key, read_state('ss_pk_destination')),
        inputs=[
            "sudo chown %s %s" % (user, read_state('ss_pk_destination'))
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("uploading private key failed on %s", node)

    # searchstax pem pub
    priv_key = open(read_state('ss_pk_source') + '.pub').read()
    returncode, stdout, stderr = remote_exec(
        node,
        command="\"echo '%s' | sudo tee %s\"" % (priv_key, read_state('ss_pk_destination') + '.pub'),
        inputs=[
            "sudo chown %s %s" % (user, read_state('ss_pk_destination') + '.pub')
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("uploading public key failed on %s", node)


def postprocess_searchstax_settings(node, automation_settings_cust_file, user='searchstax'):
    """
    Change values in local_settings and automation_settings
    """
    echoes = ['%s\n' % x for x in automation_settings_cust_file]
    echoes.insert(
        0,
        "cat << EOF | sudo tee -a %s/app/searchstax/searchstax/automation_settings.py\n" % SEARCHSTAX_BASE_DIR
    )
    echoes.append('EOF\n')
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=echoes
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("Modifying automation_settings failed on %s", node)

    # create secret.py
    django_secret_key = read_state('django_secret_key')
    if not django_secret_key:
        django_secret_key = ''.join([random.SystemRandom().choice('abcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*(-_=+)') for i in range(50)])
        manage_state('django_secret_key', django_secret_key)
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "echo 'DJANGO_SECRET_KEY=\"%s\"' | sudo tee %s/app/searchstax/searchstax/secret.py\n" % (
                django_secret_key, SEARCHSTAX_BASE_DIR)
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("secret.py creation failed on %s", node)


def configure_virtualenv(node, user='searchstax'):
    """
    Configure virtualenv
    """
    requirements_file = '%s/app/searchstax/requirements-u16.txt' % SEARCHSTAX_BASE_DIR
    print "Doing apt update"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo chown -R %s %s\n" % (user, SEARCHSTAX_BASE_DIR),
            "sudo LC_ALL='en_us.UTF-8' apt update\n"
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("apt update failed")
    print "Installing system dependencies"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "export LC_ALL='en_US.UTF-8'\n"
            "export DEBIAN_FRONTEND=noninteractive\n"
            "sudo  -E apt -y install libmysqlclient-dev python-pip python-virtualenv python-dev libffi-dev libssl-dev libxml2-dev libxslt1-dev\n",
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("installing virtualenv system dependencies failed")
    print "Building virtualenv (takes time)"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo su - %s\n" % user,
            "cd %s\n" % SEARCHSTAX_BASE_DIR,
            "export LC_ALL='en_US.UTF-8'\n",
            "virtualenv --no-site-packages env\n",
            "source env/bin/activate\n",
            "pip install --upgrade pip\n",
            "pip install -r %s\n" % requirements_file,
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("Setting-up virtualenv failed on %s", node)
    print "Complling and installing uwsgi (takes time)"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo su - %s\n" % user,
            "cd %s\n" % SEARCHSTAX_BASE_DIR,
            "export LC_ALL='en_US.UTF-8'\n",
            "source env/bin/activate\n",
            "pip install uwsgi\n"
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("Installing uwsgi failed on %s", node)


def generate_cfg_file(analytics_nodes, pulse_nodes):
    """
    Generate .searchstax-settings.cfg
    """
    print "Generating cfg file"
    if HIGH_AVAILABILITY:
        mongo_opts = '?replicaSet=rs0'
    else:
        mongo_opts = ''
    mongo_conn_template = "mongodb://%s/%s%s"
    cfg_file = []
    data = yaml.load(open(CONFIG_FILE))
    databases = {
        'default': {
            'ENGINE': 'django.db.backends.mysql',
            'NAME': read_state('db_name'),
            'USER': read_state('db_user'),
            'PASSWORD': read_state('db_password'),
            'HOST': read_state('db_address'),
            'PORT': '',
        }
    }
    # aws master
    cfg_file.append("AWS_ACCESS_KEY_ID = '%s'" % data['aws']['master']['key'])
    cfg_file.append("AWS_SECRET_ACCESS_KEY = '%s'" % data['aws']['master']['secret'])
    # aws backup creds
    cfg_file.append("AWS_BACKUP_CREDENTIALS = ('%s', '%s')" % (
        data['aws']['backup']['key'], data['aws']['backup']['secret']))
    # aws log creds
    cfg_file.append("LOG_STORAGE_ACCESS_KEY = '%s'" % data['aws']['log']['key'])
    cfg_file.append("LOG_STORAGE_SECRET_KEY = '%s'" % data['aws']['log']['secret'])
    # braintree settings
    cfg_file.append("BRAINTREE_MERCHANT_ID = '%s'" % data['braintree']['merchant_id'])
    cfg_file.append("BRAINTREE_PUBLIC_KEY = '%s'" % data['braintree']['public_key'])
    cfg_file.append("BRAINTREE_PRIVATE_KEY = '%s'" % data['braintree']['private_key'])
    # zabbix settings
    cfg_file.append("ZABBIX_USER = '%s'" % data['zabbix']['user'])
    cfg_file.append("ZABBIX_PASSWORD = '%s'" % data['zabbix']['password'])
    # db settings
    cfg_file.append("DATABASES = %s" % str(databases))
    # mongodb analytics settings
    connstring = '%s' % ','.join(['%s:27017' % x[1] for x in analytics_nodes])
    authstring = 'analytics:%s' % read_state('analytics-analytics-password')
    db_name = 'analytics-%s' % ENVIRONMENT
    cfg_file.append("MONGODB_URL = 'mongodb://%s@%s/%s%s'" % (
        authstring, connstring, db_name, mongo_opts))
    cfg_file.append("MONGO_BACKUP_DBUSER = 'root'")
    cfg_file.append("MONGO_BACKUP_DBPASS = '%s'" % read_state('analytics-root-password'))
    # mongodb pulse settings
    connstring = '%s' % ','.join(['%s:27017' % x[1] for x in pulse_nodes])
    authstring = 'pulse:%s' % read_state('pulse-pulse-password')
    db_name = 'pulse-%s' % ENVIRONMENT
    cfg_file.append("PULSEDB_URL = 'mongodb://%s@%s/%s%s'" % (
        authstring, connstring, db_name, mongo_opts))
    cfg_file.append("PULSEDB_BACKUP_DBUSER = 'root'")
    cfg_file.append("PULSEDB_BACKUP_DBPASS = '%s'" % read_state('pulse-root-password'))
    # in-db encryption
    cfg_file.append("ENCAWS_KEY = '%s'" % read_state('awsenc_key').decode('hex'))
    with open('./searchstax-settings.cfg', 'w') as fd:
        for line in cfg_file:
            fd.write('%s\n' % line)
    return cfg_file


def customize_automation_settings_file():
    """
    Customize automation_settings.py
    """
    # TODO: this can be improved, but requires changes in SearchStax
    file = []
    data = yaml.load(open(CONFIG_FILE))
    aws_initial_sg = {
        'name': 'measuredsearch',
        'ips': [],
        'global_ports': [('tcp', 28778)],
        'zabbix_ips': [data['zabbix']['cidr']],
        'zabbix_ports': ['tcp', 10050]
    }
    aws_initial_sg['ips'].append('%s/32' % read_state('nat_ip'))
    aws_initial_sg['ips'].append('%s/32' % BASTION_HOST)

    # TODO(sandeep): Add more S3 regions if required.
    aws_bucket_map = {
        'us-east-1': ('%s' % data['aws']['log']['default_bucket'], (
            'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
        ))
    }
    aws_backupbucket_map = {
        'us-east-1': ('%s' % data['aws']['backup']['default_bucket'], (
            'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
        ))
    }
    file.append("CUSTOMER_VPC = '%s'" % data['searchstax']['customer_vpc'])
    file.append("VPC_BLOCK = '%s'" % data['searchstax']['vpc_block'])
    file.append("DEPLOYMENT_DNS_ZONE = '%s'" % data['searchstax']['deployment_dns_zone'])
    file.append("LEGACY_DEPLOYMENT_DNS_ZONE = '%s'" % data['searchstax']['legacy_deployment_dns_zone'])
    file.append("SSH_PK = '%s'" % data['searchstax']['ssh_pk_destination'])
    file.append("SSH_USERNAME = 'ubuntu'")
    file.append("SOLR_AGENT_API = '%s/api/v1/metric/record/'" % data['provision']['searchstax_url'])
    file.append("AWS_INITIAL_SG = %s" % str(aws_initial_sg))
    file.append("AWS_KEY_NAME = '%s'" % data['aws']['key_name'])
    file.append("AWS_BUCKET_MAP = %s" % str(aws_bucket_map))
    file.append("AWS_BACKUPBUCKET_MAP = %s" % str(aws_backupbucket_map))
    file.append("AWS_LB_CERT_ID = '%s'" % data['aws']['lb_cert_id'])
    file.append("SSL_PATH = '%s'" % data['searchstax']['ssl_path'])
    file.append("SSL_PKEY = '%s'" % data['searchstax']['ssl_pkey'])
    file.append("SSL_CRT = '%s'" % data['searchstax']['ssl_crt'])
    file.append("NGINX_SSL_PATH = SSL_PATH")
    file.append("NGINX_SSL_PKEY = SSL_PKEY")
    file.append("NGINX_SSL_CRT = SSL_CRT")
    file.append("ZABBIX_URL = '%s'" % data['zabbix']['api'])
    return file

def upload_cfg_file(node, cfg_file):
    """
    Upload cfg file
    """
    echoes = ['%s\n' % x for x in cfg_file]
    echoes.insert(0, "cat << EOF | sudo tee /opt/searchstax/.searchstax-settings.cfg\n")
    echoes.append('EOF\n')
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=echoes
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("Uploading cfg file failed on %s", node)


def upload_ssl(node, user='searchstax'):
    """
    Upload a SSL certificate/key
    """
    data = yaml.load(open(CONFIG_FILE))
    source_path = data['searchstax']['ssl_local_path']
    dst_path = data['searchstax']['ssl_path']
    crt_file = data['searchstax']['ssl_crt']
    pkey_file = data['searchstax']['ssl_pkey']
    crt_source = open('%s/%s' % (source_path, crt_file)).read()
    pkey_source = open('%s/%s' % (source_path, pkey_file)).read()
    crt_dst = '%s/%s' % (dst_path, crt_file)
    pkey_dst = '%s/%s' % (dst_path, pkey_file)
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo mkdir %s\n" % dst_path,
            "sudo touch %s\n" % crt_dst,
            "sudo touch %s\n" % pkey_dst,
            "echo '%s' | sudo tee %s\n" % (crt_source, crt_dst),
            "echo '%s' | sudo tee %s\n" % (pkey_source, pkey_dst),
            "sudo chown -R %s %s\n" % (user, dst_path)
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("uploading SSL cert/key to %s failed", node)


def configure_searchstax_common(nodes, cfg_file, automation_settings_cust_file):
    """
    Upload github SSH key and SSH config file,
    configure searchstax repo, virtualenv and
    generic settings
    """
    print "Configuring SearchStax"
    for node in nodes:
        print "Node %s" % node
        print "/etc/hosts"
        add_etc_hosts(node)
        # upload ssh keys and ssh config
        print "Git"
        configure_git(node)
        # pull repository
        print "Git repo"
        configure_git_repo(node)
        # copy automation_settings.py and local_settings.py
        print "SearchStax settings"
        copy_searchstax_settings(node)
        postprocess_searchstax_settings(node, automation_settings_cust_file)
        # configure virtualenv
        print "virtualenv"
        configure_virtualenv(node)
        # upload settings
        print "Uploading cfg file"
        upload_cfg_file(node, cfg_file)


def django_migrate(node, user='searchstax'):
    """
    Perform database migration
    """
    print "database migrations"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo su - %s\n" % user,
            "cd %s\n" % SEARCHSTAX_BASE_DIR,
            "source env/bin/activate\n",
            "cd app/searchstax\n",
            "./manage.py migrate\n"
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("migrate failed on", node)


def django_collectstatic(node, user='searchstax'):
    """
    Perform collectstatic
    """
    print "collectstatic"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo rm -rf /tmp/searchstax.*\n",
            "sudo rm -rf /tmp/create_depl*\n",
            "sudo chmod 666 %s/app/searchstax/logs/*\n" % SEARCHSTAX_BASE_DIR,
            "sudo chmod 777 %s/app/searchstax/logs\n" % SEARCHSTAX_BASE_DIR,
            "sudo su - %s\n" % user,
            "cd %s\n" % SEARCHSTAX_BASE_DIR,
            "source env/bin/activate\n",
            "cd app/searchstax\n",
            "./manage.py collectstatic --noinput\n"
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("collectstatic failed on", node)


def django_init(node, user='searchstax'):
    """
    load fixtures
    create initial user
    """
    print "fixtures"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo su - %s\n" % user,
            "cd %s\n" % SEARCHSTAX_BASE_DIR,
            "source env/bin/activate\n",
            "cd app/searchstax\n",
            "./manage.py loaddata ./searchstax/application/fixtures/metrics.json\n",
            "./manage.py loaddata ./searchstax/application/fixtures/cloud_provider.json\n",
            "./manage.py loaddata ./searchstax/application/fixtures/regions.json\n",
            "./manage.py loaddata ./searchstax/application/fixtures/plans.json\n",
            "./manage.py loaddata ./searchstax/application/fixtures/solr_versions.json\n",
            "./manage.py loaddata ./searchstax/plan/fixtures/initial.json\n"
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("django loading fixtures failed on", node)


    print "initial user"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo su - %s\n" % user,
            "cd %s\n" % SEARCHSTAX_BASE_DIR,
            "source env/bin/activate\n",
            "cd app/searchstax\n",
            "./manage.py shell -c \"from searchstax.useraccount.models import SearchStaxUser; SearchStaxUser.objects.create_superuser('%s', '%s')\"\n" % (
                DJANGO_USERMAIL,
                DJANGO_USERPASS
            )

        ]
    )

    if returncode != 0:
        print stdout
        print stderr
        print("Failed to create superuser.  Perhaps user already exists?")



def logs_directory(node, username='www-data'):
    """
    Change logs dir permissions and owner
    do this only for web servers
    """
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo mkdir %s/app/searchstax/logs\n" % SEARCHSTAX_BASE_DIR,
            "sudo chown -R %s:%s %s/app/searchstax/logs\n" % (
                username, username, SEARCHSTAX_BASE_DIR)

        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("changing logs permissions failed on %s", node)


def restart_web_services(node):
    """
    Restart uwsgi and nginx
    """
    print "restarting web services"
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo service searchstax stop\n",
            "sudo rm -rf /tmp/searchstax.*\n",
            "sudo rm -rf /tmp/create_depl*\n",
            #"sudo chown %s:%s /tmp/create_deployment.log\n" % (username, username),
            "sudo service searchstax start\n",
            "sudo service nginx restart\n"
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exeption("Restarting web services failed on %s", node)


def configure_jobserver_crontab(node, user='searchstax'):
    """
    Replace whole crontab
    """
    crontab_path = '%s/app/searchstax/deploy/crontab-u16' % SEARCHSTAX_BASE_DIR
    returncode, stdout, stderr = remote_exec(
        node,
        command="bash",
        inputs=[
            "sudo su - %s\n" % user,
            "crontab < %s\n" % crontab_path,
        ]
    )
    if returncode != 0:
        print stdout
        print stderr
        raise Exception("setting-up jobserver crontab failed on %s", node)


def configure_searchstax_jobserver(nodes):
    print "modifying jobservers"
    django_migrate(nodes[0])
    django_init(nodes[0])
    configure_jobserver_crontab(nodes[0])
    for node in nodes:
        print "Uploading SSL certificate/key pair"
        upload_ssl(node)


def configure_searchstax_web(nodes):
    print "modifying webservers"
    for node in nodes:
        # collect static files
        django_collectstatic(node)
         # change logs dir permissions
        logs_directory(node)
        # (re)start uwsgi and nginx
        restart_web_services(node)


def process_settings_yml():
    """
    Validate settings.yml file contents
    """
    data = yaml.load(open(CONFIG_FILE))
    if 'git' in data and 'repo' in data['git'] and 'keyfile' in data['git']:
        # check rsa key
        cmd = 'openssl rsa -in %s -modulus -noout' % data['git']['keyfile']
        out = subprocess.check_call(cmd, stdout=FNULL, shell=True)
        if out != 0:
            raise Exception("%s is not a valid private RSA key", data['git']['keyfile'])
        manage_state('git_repo', data['git']['repo'])
        manage_state('git_keyfile', data['git']['keyfile'])
        manage_state('git_branch', data['git']['branch'])
        manage_state('git_searchstax_client_repo', data['git']['searchstax_client_repo'])

    else:
        raise Exception("git repo and/or keyfile are missing")
    manage_state('ss_pk_source', data['searchstax']['ssh_pk_source'])
    manage_state('ss_pk_destination', data['searchstax']['ssh_pk_destination'])
    global SSH_PRIVATE_KEY
    global SSH_USER
    global ENVIRONMENT
    global SEARCHSTAX_BASE_DIR
    global HIGH_AVAILABILITY
    global DEPLOYMENT_DNS_ZONE
    DEPLOYMENT_DNS_ZONE = data['searchstax']['deployment_dns_zone']
    SEARCHSTAX_BASE_DIR = data['searchstax']['base_dir']
    SSH_PRIVATE_KEY = data['provision']['ssh_key']
    SSH_USER = data['provision']['ssh_user']
    ENVIRONMENT = data['provision']['environment']
    global DJANGO_USERMAIL
    DJANGO_USERMAIL = data['django']['usermail']
    global DJANGO_USERPASS
    DJANGO_USERPASS = data['django']['userpass']


def main():
    """
    Main
    """
    # read terraform state to obtain all required IP addresses
    process_settings_yml()
    read_rds()
    ips = read_ips()
    enc_key = read_state('awsenc_key')
    if not enc_key:
        key = generate_enc_key()
        manage_state('awsenc_key', generate_enc_key())
    global BASTION_HOST
    BASTION_HOST = ips['bastion_host']

    init_etc_hosts(
        ips['analytics_data_nodes'] +\
        ips['analytics_arb_nodes'] +\
        ips['pulse_data_nodes'] +\
        ips['pulse_arb_nodes']
    )
    # configure MongoDB for Analytics
    configure_mongodb(ips['analytics_data_nodes'], ips['analytics_arb_nodes'], 'analytics')
    # # configure MongoDB for Pulse
    configure_mongodb(ips['pulse_data_nodes'], ips['pulse_arb_nodes'], 'pulse')
    # generate cfg file for searchstax
    cfg_file = generate_cfg_file(ips['analytics_data_nodes'], ips['pulse_data_nodes'])
    # setup common attributes for webservers and jobserver
    automation_settings_cust_file = customize_automation_settings_file()
    configure_searchstax_common(
        ips['jobserver_nodes'] + ips['web_nodes'],
        cfg_file,
        automation_settings_cust_file
    )
    # setup jobserver specific attributes
    configure_searchstax_jobserver(ips['jobserver_nodes'])
    # setup webserver specific attributes
    configure_searchstax_web(ips['web_nodes'])


if __name__ == '__main__':
    main()
