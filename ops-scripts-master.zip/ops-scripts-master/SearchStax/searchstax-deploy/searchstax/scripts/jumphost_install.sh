#!/bin/bash

until ping -c1 www.google.com &>/dev/null; do :; done
sudo apt-get -qq update
sudo DEBIAN_FRONTEND=noninteractive apt-get upgrade -qq -y
sudo apt-get -qq -y install python-pip
sudo pip install virtualenv
sudo chown -R jenkins:jenkins /home/jenkins/deploy
sudo su -c 'virtualenv /home/jenkins/deploy/env' jenkins
sudo su -c 'source /home/jenkins/deploy/env/bin/activate && pip install fabric' jenkins
sudo su -c 'cd /home/jenkins/deploy && git clone git@github.com:measuredsearch/searchstax.git ' jenkins
