# SearchStax Deployment tools
This is a set of tools, mostly Terraform based, to start whole SearchStax from scratch. 

## Getting started
Terraform is an infrastructure management tool using the "infrastructure as code" approach. It helps you define infrastructure using it's own language. 

Some special limitations are, terraform has immutable approach. So any change, like upgrading instance to a different plan, changing instance config requires reprovisioning of the affected resources. However there are approaches, how to handle this without the need of reprovision, so read the following text carefully. 

### What does this code in detail: 
1. Creates VPC
2. Creates Internet GW
3. Creates NAT GW
4. Creates 1x internet facing subnet
5. Creates 3x private subnets
6. Starts Jumphost/Bastion instance in internet facing subnet
7. Starts 1-3 webserver instances in private subnets (depends on high_availability variable)
8. Starts single jobserver instance in private subnet
9. Starts Single-AZ or Multi-AZ RDS instance in private subnets (depends on high_availability variable)
10. Starts Single MongoDB or MongoDB replica set for Pulse (depends on high_availability variable)
11. Starts single MongoDB or MongoDB replica set for Analytics (depends on high_availability variable)
12. Upgrades systems
13. Creates users
14. Installs dependencies
15. Configures services
16. Configures ELB with webservers as backends

### Prerequisites
- You need to have [Terraform](https://www.terraform.io/) installed. 
- You need to have full access to AWS account, where you plan to deploy the SearchStax, 
you will need to have AWS access key id and AWS secret access key. 
- You need to have SSH key which has read permissions on [SearchStax repository](https://github.com/measuredsearch/searchstax). 
- Bonus points for being familiar with Terraform.

### File structure and configurations
There are 3 different environments, which can be used and have different configuration sets. It is `dev`, `staging` and `prod`. Each environment sits in it's own subdirectory with the same name. In each environment directory, there is `main.tf` wile containing the terraform setup itself, `variables.tf` which provides variable defaults and you need to craft `terraform.tfvars` out of `terraform-environment.tfvars` stored in the parent directory. 

```
consul
searchstax
- dev/
- staging/
- prod/
- modules/
 -- data-storages/
 -- services/
 -- vpc/
- templates_configs
 -- cloudinit/
 -- services/
- terraform-dev.tfvars
- terraform-staging.tfvars
- terraform-prod.tfvars
```

### Environment specifics
Only `prod` environment will start fully featured EC2 instances. Any other environment will start only `t2.micro` instances and `db.t2.micro` for RDS. 

### High-Availability
High-Availability is supported by `high_availability` variable. This variable is by default `true` for prod, `false` for dev and staging. To change this behaviour, change the value in terraform.tfvars or using --var high_availability=`true|false` on the terraform runtime

### Configuration file
Following is example terraform.tfvars file for a dev environment. 

```
access_key = "YOUR_AWS_ACCESS_KEY_ID"
secret_key = "YOUR_AWS_SECRET_ACCESS_KEY"
region = "eu-central-1"
aws_availability_zones = {
    eu-central-1 = ["eu-central-1a", "eu-central-1b", "eu-central-1c"]
}
environment = "dev"
ssl_crt_arn = "arn:aws:iam::293871530150:server-certificate/SearchStaxLbCert"

ssh_user = "jozef"
ssh_private_key = "/home/jsu/.ssh/crunchroot_rsa"
high_availability = true
dns_zone = "0th.place"
name_prefix = "searchstax"
cidr_prefix = "172.31."
```

Each of the variables can be provided in command line by adding `-var 'key=value'`. 

#### access_key, secret_key
Valid AWS access key id and AWS secret access key. These variables can be read from the default aws local settings as well. 

#### region
Is the region where SearchStax will be deployed. 

#### environment
can be dev, staging, prod or anything, you create

#### ssl_crt_arn
Is the AWS ARN pointing to a valid SSL Certificate, which will be used in ELB. 

#### ssh_user and ssh_private_key 
Remote useraccount created during the provisioning and valid private SSH key part. This is important, since remote actions, as configuring instance systems are performed using `remote-exec` provisioner. 

#### high_availability
If true, will start multiple webservers, will start MongoDB replica set for Pulse and another MongoDB replica set for Analytics. Will start Multi-AZ RDS. 

If false, will start one webserver, one MongoDB instance for Pulse, one MongoDB instance for Analytics and Single-AZ RDS. 

#### dns_zone
Is the domain name to be used while performing required actions. This domain should exist in your AWS account and your AWS credentials should have permissions to modify it's Route53 configuration. 

#### name_prefix
Is the prefix used for each AWS resource, hostnames and DNS records. For example, prefix `searchstax` will produce machines like `searchstax-dev-web-0`, prefix `ss` will produce `ss-dev-web-0` etc. 

#### cidr_prefix
This is the prefix to be used for SearchStax VPC. Try to avoid any CIDRs which are used by services/VPCs/subnets which need to interfer with the SearchStax. 

### Templates
There are two types of templates. First are cloud-init/cloud-config templates used at the moment of provisioning. Second are services templates, which contain template files for specific system services (like Nginx, uWSGI, ...)

Cloudinit templates contain also users, groups and public keys which will be deployed to machines. 

## Working with environments
Once you finished configuring the variables, you need to initialize the environment. Please note, you do this only the first time or if terraform asks you to reinit (in case of changes in modules/resources/...). For example, using dev environment, perform the following actions:

```
cd dev
./terraform get
./terraform init
```

## Planning terraform/preparing execution plan
This step prepares the execution plan consisting of all actions terraform will perform. To prepare it, execute `terraform plan`. To save the execution plan, use `terraform plan --out path/to/file`. 

## Executing plan
!!! NEVER EVER !!!! _EVER_ *EVER* **EVER** execute plan without seeing it before. So NEVER EVER execute `terraform apply` before you have seen what it will do to your current environment. Before each apply, execute `terraform plan` and examine, what changes will be performed. **ALWAYS**.  

## Modifying environment
TODO 

### Updating local state from remote
In some situations, it is better or even required to start machines or change configurations in the running environment instead of reprovisioning the whole environment using terraform.

TODO


## Destroying plan
TODO
