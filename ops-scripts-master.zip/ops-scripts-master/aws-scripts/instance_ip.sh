#!/bin/bash
echo "hello!"
echo "Getting All regions where we have resources"

aws ec2 describe-regions --query 'Regions[].{Name:RegionName}' --output text >regions.txt

echo "Getting Resources in all regions"

filename="regions.txt"
while read -r line
do
    name="$line"
    aws ec2 describe-instances  --query 'Reservations[].Instances[].[Tags[?Key==`Name`].Value,PublicIpAddress]' --output json --region $name > $name.json

done < "$filename"

python <<END_OF_PYTHON
# Read all regions
with open("regions.txt") as f:
    lines = f.read().splitlines()
files_for_regions=[]
for line in lines:
    files_for_regions.append(line+".json")
# Print as Required:
import json
for file in files_for_regions:
    with open(file) as json_data:
        output = json.load(json_data)
END_OF_PYTHON

echo "goodbye!";
