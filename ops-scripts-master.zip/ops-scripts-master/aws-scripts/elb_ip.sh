for region in `aws ec2 describe-regions --output text | cut -f3`
do
     echo -e "\nListing Instances in region:'$region'..."
     aws elb describe-load-balancers --output json --region $region > $region.json
done

cat *.json|grep -i dns|awk '{print $2}'| tr -d '"'|tr -d ',' > dns.txt
for dns in `cat dns.txt`; do nslookup $dns |grep -i address|awk '{print $2}'| grep -v '75.75.75.75'; done > dns-ip.txt
