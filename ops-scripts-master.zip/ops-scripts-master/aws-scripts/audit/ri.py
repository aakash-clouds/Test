import boto3
import pprint

def get_reserved_instances(region_name):
    resp = {}
    client = boto3.client('ec2', region_name=region_name)
    ris = client.describe_reserved_instances(
        Filters=[{'Name': 'state', 'Values': ['active', ]}])

    for ri in ris['ReservedInstances']:
        k = ri['InstanceType']
        try:
            resp[k] += ri['InstanceCount']
        except:
            resp[k] = ri['InstanceCount']

    return resp


