import boto3 
import pprint
from ec2 import count_instances_without_blessed_tags, get_running_instances_annual_payment
from elastic_ip import count_unused_elastic_ips
from ebs import count_available_volumes
from ri import get_reserved_instances
from ami import get_deletable_ami_snapshots, get_ami_older_than

ec2 = boto3.client('ec2')
response = ec2.describe_regions()
regions = response['Regions']

print "\n\n*************************************"
print "The following performs an audit on EC2 resources"
print "Please follow the directions given under 'Instruction:' in each section"
print "*************************************"

print '\n\n===== Region RI vs Annual EC2 instances ===='
print 'Instruction: Please report where RI count is not the same as EC2 count. Those can be cost-optimized'
print "=================================="
for region in regions:
    ris = get_reserved_instances(region['RegionName'])
    #pprint.pprint(ris)
    annual_ec2 = get_running_instances_annual_payment(region['RegionName'])
    #pprint.pprint(annual_ec2)
    ri_ec2 = {}
    for key, value in annual_ec2.items():
        if key in ris:
            if ris[key] != value:
	            ri_ec2[key] = {'RI': ris[key], 'EC2': value}
        else:
            ri_ec2[key] = {'RI': 0, 'EC2': value}

    print 'Region: %s' % region['RegionName']
    pprint.pprint(ri_ec2)
    


print '\n\n==== Untagged EC2 Instances  ===='
print "Instruction: The following EC2 instances have no assocaiated tags. Please review. \nIf they are associated with a deployment, please add the tags"
print "If they are associated with Infra, add MS-Infra tag. "
print "If they are not assocaited with infra or deployments, please delete them."
print "=================================="
total_count = count_instances_without_blessed_tags(regions)
print 'Total untagged ec2 instances: %s' % total_count


print '\n\n==== EBS Volumes ===='
print "Instruction: If there are unassociated volumes below, please delete them from AWS console "
print "=================================="
total_count = count_available_volumes(regions)
print 'Total available un-associated volumes: %s' % total_count

print '\n\n==== Elastic IPs ===='
print "Instruction: If there are any ununsed Elastic IPs below, please delete them from AWS console"
print "=================================="
total_count = count_unused_elastic_ips(regions)
print 'Total unused Elastic IPs: %s' % total_count

print '\n\n==== AMIs older than 90 days ===='
print "The following AMI are usued for 90 days. Please delete them from the AWS console"
print "=================================="
for region in regions:
   amis = get_ami_older_than(region['RegionName'], 90)
   if len(amis) > 0:
       print 'Region: %s' % region['RegionName']
       pprint.pprint(amis)



print '\n\n==== Snapshots to be deleted ===='
print "Instruction: If there are any snapshots mentioned below, they are unused. Please delete them"
print "=================================="
for region in regions:
    snapshots = get_deletable_ami_snapshots(region['RegionName'])
    if len(snapshots) > 0:
        print 'Region: %s' % region['RegionName']
        pprint.pprint(snapshots)
