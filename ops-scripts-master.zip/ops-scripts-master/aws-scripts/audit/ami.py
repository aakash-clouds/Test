import boto3
import re
from datetime import datetime, timedelta 

def get_ami_older_than(region_name, days):
    images_to_be_deregistered = []
    today = datetime.now() + timedelta(days=1) # today + 1 because we want all of today
    two_weeks = timedelta(days=days)
    x_days_ago = today - two_weeks
    ec2 = boto3.resource("ec2", region_name=region_name)
    instances = ec2.instances.all()  
    # BAD, Account ID should not be hard coded
    my_images = ec2.images.filter(Owners=["894198002080"])  
    # anything that's running or stopped we want to keep the AMI
    good_images = set([instance.image_id for instance in ec2.instances.all()])  
    # build a dictionary of all the images that aren't in good_images
    my_images_dict = {image.id: image for image in my_images if image.id not in good_images}  
    # now lets deregister all the AMIs older than two weeks
    for image in my_images_dict.values():  
        created_date = datetime.strptime(
            image.creation_date, "%Y-%m-%dT%H:%M:%S.000Z")
        if created_date < x_days_ago:
	    images_to_be_deregistered.append(image.id)
    return images_to_be_deregistered


def get_deletable_ami_snapshots(region_name):
    snapshots = []
    ec2 = boto3.resource("ec2", region_name=region_name) 
    images = ec2.images.all()  
    images = [image.id for image in images]  
    for snapshot in ec2.snapshots.filter(OwnerIds=["894198002080"]):  
        r = re.match(r".*for (ami-.*) from.*", snapshot.description)
        if r:
            if r.groups()[0] not in images:
		snapshots.append(snapshot.id)
    return snapshots
