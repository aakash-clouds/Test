import boto3

def count_unused_elastic_ips_for_region(region_name):
    """ Count elastic IPs that are not being used """
    client = boto3.client('ec2', region_name=region_name)
    addresses_dict = client.describe_addresses()
    count = 0
    for eip_dict in addresses_dict['Addresses']:
        if "NetworkInterfaceId" not in eip_dict:
            print(eip_dict['PublicIp'])
            count = count + 1
    return count

def count_unused_elastic_ips(regions):
    total_count = 0
    for region in regions:
	count = count_unused_elastic_ips_for_region(region['RegionName'])
        if count > 0:
	    print 'Unuesd EIP for Region: %s: %s' % (region['RegionName'], count)
        total_count = total_count + count
    return total_count
