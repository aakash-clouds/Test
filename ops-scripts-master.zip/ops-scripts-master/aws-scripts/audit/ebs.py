import boto3
import pprint

def count_available_volumes_for_region(region_name):
    """ Count EBS volumes that are not in-use """
    client = boto3.client('ec2', region_name=region_name)
    filters = [{'Name':'status', 'Values':['available']}]
    available_volumes = client.describe_volumes(Filters=filters)
    return len(available_volumes['Volumes'])


def count_available_volumes(regions):
    total_count = 0
    for region in regions:
        count = count_available_volumes_for_region(region['RegionName'])
        if count > 0:
            print 'Available Volumes for Region: %s: %s' % (region['RegionName'], count)
	total_count = total_count + count
    return total_count
