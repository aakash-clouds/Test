import boto3
import pprint

approved_servicecategory_tags = ['ms-infra','ms-deployment','trials']


def get_running_instances_annual_payment(region_name):
    ins = {}
    nt = None
    client = boto3.client('ec2', region_name=region_name)
    _args = {
        "Filters": [{'Name': 'instance-state-name', 'Values': ['running']},{'Name':'tag:Payment_type', 'Values': ['annually']}]
    }

    while True:
        if nt:
            _args['NextToken'] = nt

        resp = client.describe_instances(**_args)

        for r in resp['Reservations']:
            for i in r['Instances']:
                if 'SpotInstanceRequestId' in i:
                    continue

                try:
                    ins[i['InstanceType']] += 1
                except:
                    ins[i['InstanceType']] = 1

        try:
            nt = resp['NextToken']
        except:
            break

    client = boto3.client('ec2', region_name=region_name)
    _args = {
        "Filters": [{'Name': 'instance-state-name', 'Values': ['running']},{'Name':'tag:ServiceCategory', 'Values': ['ms-infra']}]
    }

    while True:
        if nt:
            _args['NextToken'] = nt

        resp = client.describe_instances(**_args)

        for r in resp['Reservations']:
            for i in r['Instances']:
                if 'SpotInstanceRequestId' in i:
                    continue

                try:
                    ins[i['InstanceType']] += 1
                except:
                    ins[i['InstanceType']] = 1

        try:
            nt = resp['NextToken']
        except:
            break


    return ins

def count_instances_without_blessed_tags_in_region(region_name):
    """ Count instances that don't have an approved ServiceCategory """
    flagged_instances = []
    client = boto3.client('ec2', region_name=region_name)
    response = client.describe_instances()
    for reservation in response["Reservations"]:
        for instance in reservation["Instances"]:
	    #pprint.pprint(instance)
	    if "Tags" in instance:
	        for tag in instance["Tags"]:
		    if 'ServiceCategory' == tag['Key']:
			#lets make sure the value is one of the approved
			if tag['Value'] in approved_servicecategory_tags:
				#noop
				continue
			else:
				#audit issue
				flagged_instance = {}
				flagged_instance['id'] = instance['InstanceId']
				flagged_instances.append(flagged_instance)
    	    else:
	        # Tags are not even there, flag it
		flagged_instance = {}
                flagged_instance['id'] = instance['InstanceId']
                flagged_instances.append(flagged_instance)

    if(len(flagged_instances) > 0):    
        print 'Instances without Approved Tags in Region: %s: %s' % (region_name, len(flagged_instances))
        print '[%s]' % ', '.join(map(str, flagged_instances)) 
    return len(flagged_instances)


def count_instances_without_blessed_tags(regions):
    total_count = 0
    for region in regions:
        count = count_instances_without_blessed_tags_in_region(region['RegionName'])
	total_count = total_count + count
    return total_count
