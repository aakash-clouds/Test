#!/bin/bash

echo "Security Groups Audit"
for region in aws ec2 describe-regions --output text | cut -f3
do
  comm -23  <(aws ec2 describe-security-groups --region $region --query 'SecurityGroups[*].GroupId'  --output text | tr '\t' '\n'| sort) <(aws ec2 describe-instances --query 'Reservations[*].Instances[*].SecurityGroups[*].GroupId' --output text | tr '\t' '\n' | sort | uniq)
done
